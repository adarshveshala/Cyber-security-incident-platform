import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Globe2,
  Search,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Fingerprint,
  ExternalLink,
  Activity,
  Layers,
  Database,
  Radio,
  CheckCircle2,
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { api } from '../../services/api';
import { ThreatIndicator } from '../../types';

export const ThreatIntelligence: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [indicators, setIndicators] = useState<ThreatIndicator[]>([]);
  const [activeResult, setActiveResult] = useState<ThreatIndicator | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedType, setSelectedType] = useState('all');

  useEffect(() => {
    const load = async () => {
      const data = await api.getAllThreatIndicators();
      setIndicators(data);
      if (searchParams.get('q')) {
        handleLookup(searchParams.get('q')!);
      }
    };
    load();
  }, []);

  const handleLookup = async (lookupTerm?: string) => {
    const term = lookupTerm || query;
    if (!term.trim()) return;
    setIsSearching(true);
    try {
      const res = await api.queryThreatIntel(term.trim());
      setActiveResult(res);
      // Refresh list
      const refreshed = await api.getAllThreatIndicators();
      setIndicators(refreshed);
    } finally {
      setIsSearching(false);
    }
  };

  const filtered = indicators.filter((i) => {
    const matchesQuery = i.indicator.toLowerCase().includes(query.toLowerCase());
    const matchesType = selectedType === 'all' || i.type === selectedType;
    return matchesQuery && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
            Threat Intelligence & IOC Enrichment
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Query IPs, domain names, file hashes, and URLs across VirusTotal, AbuseIPDB, and STIX/TAXII threat feeds.
          </p>
        </div>
      </div>

      {/* Indicator Query Bar */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleLookup();
          }}
          className="flex flex-col sm:flex-row gap-3"
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Enter IP (e.g. 194.26.29.112), Domain (pay-secure-corporate.net), SHA-256 Hash..."
              className="w-full pl-10 pr-4 py-2.5 text-xs font-mono border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
              required
            />
          </div>
          <Button type="submit" variant="primary" isLoading={isSearching} leftIcon={<Globe2 className="w-4 h-4" />}>
            Enrich Indicator
          </Button>
        </form>

        <div className="flex flex-wrap items-center gap-2 pt-2 text-xs">
          <span className="text-slate-400 font-semibold text-[11px] uppercase tracking-wider">Quick Inquiries:</span>
          {[
            '194.26.29.112',
            'pay-secure-corporate.net',
            'api.enterprise-auth-gateway.com',
            '8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4',
          ].map((sample) => (
            <button
              key={sample}
              type="button"
              onClick={() => {
                setQuery(sample);
                handleLookup(sample);
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-mono text-[11px] transition-colors"
            >
              {sample.length > 24 ? `${sample.slice(0, 18)}...` : sample}
            </button>
          ))}
        </div>
      </div>

      {/* Active Lookup Details Banner (When an Indicator is active) */}
      {activeResult && (
        <div className="bg-white rounded-2xl p-6 border-2 border-blue-200 shadow-md space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-base font-extrabold text-slate-900">{activeResult.indicator}</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700">
                  {activeResult.type}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">Category: {activeResult.category || 'General Telemetry'}</p>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-[10px] font-bold uppercase text-slate-400">Risk Score</span>
                <div className={`text-2xl font-black ${
                  activeResult.risk_score >= 80 ? 'text-red-600' :
                  activeResult.risk_score >= 50 ? 'text-amber-500' :
                  'text-emerald-600'
                }`}>
                  {activeResult.risk_score}/100
                </div>
              </div>

              <span className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider border ${
                activeResult.reputation === 'malicious' ? 'bg-red-50 text-red-700 border-red-200' :
                activeResult.reputation === 'suspicious' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                'bg-emerald-50 text-emerald-700 border-emerald-200'
              }`}>
                {activeResult.reputation}
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-700 leading-relaxed font-normal">{activeResult.details}</p>

          <div className="flex flex-wrap items-center gap-2 pt-2">
            <span className="text-[11px] font-semibold text-slate-400">Threat Tags:</span>
            {activeResult.tags.map((tag) => (
              <span key={tag} className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 font-mono text-[10px] border border-blue-200/60">
                #{tag}
              </span>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-100">
            <span>Primary Feed Source: <strong>{activeResult.source}</strong></span>
            <span>Last Evaluated: {new Date(activeResult.last_checked).toLocaleString()}</span>
          </div>
        </div>
      )}

      {/* Indicators Database Registry */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Active Indicators of Compromise (IOC) Catalog
          </h2>
          <div className="flex items-center gap-2">
            {['all', 'ip', 'domain', 'file_hash', 'url'].map((t) => (
              <button
                key={t}
                onClick={() => setSelectedType(t)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg capitalize transition-colors ${
                  selectedType === t
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {t.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-bold text-[10px]">
                <th className="py-3 px-4">Indicator</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Reputation</th>
                <th className="py-3 px-4">Risk Rating</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Intelligence Source</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {filtered.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-800 max-w-xs truncate">
                    {item.indicator}
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-slate-500 uppercase text-[10px]">
                    {item.type}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      item.reputation === 'malicious' ? 'bg-red-50 text-red-700 border border-red-200' :
                      item.reputation === 'suspicious' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                      'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    }`}>
                      {item.reputation}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold">
                    <span className={item.risk_score >= 80 ? 'text-red-600' : item.risk_score >= 50 ? 'text-amber-600' : 'text-emerald-600'}>
                      {item.risk_score}/100
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 font-medium">
                    {item.category}
                  </td>
                  <td className="py-3.5 px-4 text-slate-500">
                    {item.source}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => {
                        setActiveResult(item);
                        setQuery(item.indicator);
                      }}
                      className="text-xs font-semibold text-blue-600 hover:text-blue-800"
                    >
                      Examine &rarr;
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
