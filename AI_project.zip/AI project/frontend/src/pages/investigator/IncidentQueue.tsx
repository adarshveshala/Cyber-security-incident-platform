import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  ListFilter,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  UserCheck,
  ArrowRight,
  ShieldAlert,
  Clock,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { api } from '../../services/api';
import { Incident, IncidentSeverity, IncidentStatus } from '../../types';
import { getDefaultAvatar } from '../../utils/avatars';

export const IncidentQueue: React.FC = () => {
  const { user } = useAuth();
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [assignModalIncident, setAssignModalIncident] = useState<Incident | null>(null);
  const [assignedSuccess, setAssignedSuccess] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      const data = await api.getIncidents();
      setIncidents(data);
    };
    load();
  }, []);

  const handleClaim = async (inc: Incident) => {
    try {
      await api.assignIncident(
        inc.id,
        user?.id || 'usr-inv-101',
        user?.full_name || 'Special Agent Marcus Vance'
      );
      setAssignedSuccess(`Claimed incident ${inc.complaint_id}. Assigned to your active caseload.`);
      const updated = await api.getIncidents();
      setIncidents(updated);
      setTimeout(() => setAssignedSuccess(''), 4000);
    } catch (e: any) {
      console.error(e);
    }
  };

  const filtered = incidents.filter((inc) => {
    const matchesSearch =
      inc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.complaint_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.civilian_name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSev = severityFilter === 'all' || inc.severity === severityFilter;
    const matchesCat = categoryFilter === 'all' || inc.category === categoryFilter;
    return matchesSearch && matchesSev && matchesCat;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
            Triage & Ingestion Queue
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Review incoming cybercrime complaints, verify reported indicators, and assign to forensic investigators.
          </p>
        </div>
      </div>

      {assignedSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{assignedSuccess}</span>
        </div>
      )}

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Complaint ID, Complainant..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none"
          >
            <option value="all">All Severities</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none"
          >
            <option value="all">All Categories</option>
            <option value="financial_fraud">Financial Fraud</option>
            <option value="phishing">Phishing</option>
            <option value="account_hacking">Account Hacking</option>
            <option value="malware">Malware</option>
            <option value="impersonation">Impersonation</option>
            <option value="data_breach">Data Breach</option>
          </select>
        </div>
      </div>

      {/* Queue Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-bold text-[10px]">
                <th className="py-3.5 px-4">Complaint ID</th>
                <th className="py-3.5 px-4">Title & Category</th>
                <th className="py-3.5 px-4">Severity</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Reported By</th>
                <th className="py-3.5 px-4">Assigned To</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((inc) => (
                <tr key={inc.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-blue-700">
                    <Link to={`/investigator/incidents/${inc.id}`} className="hover:underline">
                      {inc.complaint_id}
                    </Link>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-slate-900 max-w-xs truncate">{inc.title}</div>
                    <div className="text-[11px] text-slate-500 capitalize">{inc.category.replace(/_/g, ' ')}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <Badge severity={inc.severity} size="sm" />
                  </td>
                  <td className="py-3.5 px-4">
                    <Badge status={inc.status} size="sm" />
                  </td>
                  <td className="py-3.5 px-4 text-slate-700 font-medium">
                    <div className="flex items-center gap-2">
                      <img
                        src={getDefaultAvatar('female', 'civilian')}
                        alt={inc.civilian_name}
                        className="w-5 h-5 rounded-md object-cover border border-slate-200"
                      />
                      <span>{inc.civilian_name}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    {inc.assigned_investigator_name ? (
                      <div className="flex items-center gap-2">
                        <img
                          src={getDefaultAvatar('male', 'investigator')}
                          alt="Investigator"
                          className="w-5 h-5 rounded-md object-cover border border-slate-200"
                        />
                        <span className="font-semibold text-slate-800">{inc.assigned_investigator_name}</span>
                      </div>
                    ) : (
                      <span className="text-amber-700 font-semibold bg-amber-50 px-2 py-0.5 rounded border border-amber-200 inline-flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                        Unassigned (Triage)
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {!inc.assigned_investigator_name && (
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => handleClaim(inc)}
                          leftIcon={<UserCheck className="w-3.5 h-3.5 text-blue-600" />}
                        >
                          Accept
                        </Button>
                      )}
                      <Link to={`/investigator/incidents/${inc.id}`}>
                        <Button variant="outline" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
                          Workspace
                        </Button>
                      </Link>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
