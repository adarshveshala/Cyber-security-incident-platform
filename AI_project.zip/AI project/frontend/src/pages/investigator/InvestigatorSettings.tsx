import React, { useState } from 'react';
import { Settings, ShieldCheck, KeyRound, Radio, Database, CheckCircle2, UserCheck, Shield } from 'lucide-react';
import { Button } from '../../components/common/Button';
import { AvatarSelector } from '../../components/common/AvatarSelector';
import { useAuth } from '../../context/AuthContext';
import { getDefaultAvatar } from '../../utils/avatars';

export const InvestigatorSettings: React.FC = () => {
  const { user } = useAuth();
  const [vtApiKey, setVtApiKey] = useState('vt_live_948270149028401924');
  const [abuseDbKey, setAbuseDbKey] = useState('abuse_live_1092840912840918');
  const [stixFeedUrl, setStixFeedUrl] = useState('https://threat-feeds.sentinelgrid.io/taxii2/poll');
  const [autoEnrich, setAutoEnrich] = useState(true);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const activeAvatar = user?.avatar_url || getDefaultAvatar(user?.gender, user?.role);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
          SOC Configuration & Investigator Settings
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Manage your investigator operational avatar, live threat intelligence feeds, and incident automation.
        </p>
      </div>

      {/* Investigator Avatar Selector */}
      <AvatarSelector />

      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-sm space-y-6">
        {saved && (
          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>SOC configuration and intelligence keys committed.</span>
          </div>
        )}

        {/* Investigator Credentials Header */}
        <div className="flex items-center gap-4 pb-6 border-b border-slate-100">
          <img
            src={activeAvatar}
            alt={user?.full_name || 'Investigator'}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-slate-800 shadow-sm"
          />
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-slate-900">{user?.full_name || 'Special Agent Marcus Vance'}</h3>
              <span className="text-[10px] font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                {user?.badge_number || 'SG-INV-8492'}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">{user?.department || 'Cyber Fraud & Ransomware Unit'}</p>
            <div className="flex items-center gap-1.5 mt-1 text-[11px] font-semibold text-emerald-700">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Authorized SOC Access &bull; Role: {user?.role?.replace('_', ' ').toUpperCase()}</span>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            External Threat Intelligence Feed Adapters
          </h2>

          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">VirusTotal v3 API Key</label>
                <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded">CONNECTED</span>
              </div>
              <input
                type="password"
                value={vtApiKey}
                onChange={(e) => setVtApiKey(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">AbuseIPDB Commercial Key</label>
                <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded">CONNECTED</span>
              </div>
              <input
                type="password"
                value={abuseDbKey}
                onChange={(e) => setAbuseDbKey(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">STIX 2.1 / TAXII Polling Endpoint</label>
              <input
                type="url"
                value={stixFeedUrl}
                onChange={(e) => setStixFeedUrl(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        <div className="space-y-4 pt-4 border-t border-slate-100">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Automated Forensic Automation
          </h2>

          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200/80">
            <div>
              <p className="text-xs font-bold text-slate-800">Auto-Enrich Incoming IOCs</p>
              <p className="text-[11px] text-slate-500">
                Automatically query extracted domains and IPs against threat feeds upon complaint submission.
              </p>
            </div>
            <input
              type="checkbox"
              checked={autoEnrich}
              onChange={(e) => setAutoEnrich(e.target.checked)}
              className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
            />
          </div>
        </div>

        <div className="pt-4 flex justify-end">
          <Button variant="primary" onClick={handleSave}>
            Save SOC Configurations
          </Button>
        </div>
      </div>
    </div>
  );
};
