import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Send,
  MessageSquare,
  ShieldAlert,
  AlertCircle,
  FileCheck,
  CheckCircle2,
  Lock,
  ArrowRight,
  User,
  RefreshCw,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import { Button } from '../../components/common/Button';
import { api } from '../../services/api';
import { Incident, Message } from '../../types';

export const InvestigatorMessages: React.FC = () => {
  const { user } = useAuth();
  const { addMessage, recentMessages } = useSocket();
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isEvidenceRequest, setIsEvidenceRequest] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Dedicated container ref for internal chat scrolling (NEVER scroll the whole window)
  const chatFeedRef = useRef<HTMLDivElement>(null);
  const prevMsgCountRef = useRef(0);
  const activeIncidentIdRef = useRef<string | null>(null);

  const scrollChatToBottom = useCallback((smooth = false) => {
    const el = chatFeedRef.current;
    if (!el) return;
    el.scrollTo({
      top: el.scrollHeight,
      behavior: smooth ? 'smooth' : 'auto',
    });
  }, []);

  // Load all incidents for investigator triage
  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      try {
        const data = await api.getIncidents();
        if (!isMounted) return;
        setIncidents(data);
        if (data.length > 0) {
          setSelectedIncident((prev) => {
            if (prev) {
              const stillExists = data.find((i) => i.id === prev.id || i.complaint_id === prev.complaint_id);
              return stillExists || data[0];
            }
            return data[0];
          });
        }
      } catch (err) {
        console.error('Failed to load investigator incidents:', err);
      }
    };
    load();
    return () => {
      isMounted = false;
    };
  }, []);

  // Fetch messages when selected incident changes or on interval
  useEffect(() => {
    if (!selectedIncident) return;
    let isMounted = true;
    const incId = selectedIncident.id;

    // Reset message count baseline on incident switch
    if (activeIncidentIdRef.current !== incId) {
      activeIncidentIdRef.current = incId;
      prevMsgCountRef.current = 0;
    }

    const fetchMsgs = async () => {
      try {
        const msgs = await api.getMessagesByIncident(incId);
        if (!isMounted) return;

        setMessages((prev) => {
          // Check if messages list actually changed to prevent unnecessary re-renders
          if (
            prev.length === msgs.length &&
            (prev.length === 0 || prev[prev.length - 1]?.id === msgs[msgs.length - 1]?.id)
          ) {
            return prev;
          }
          return msgs;
        });
      } catch (err) {
        console.warn('Error fetching messages for incident:', err);
      }
    };

    fetchMsgs();
    const interval = setInterval(fetchMsgs, 4000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [selectedIncident?.id, selectedIncident?.complaint_id]);

  // Handle internal chat scrolling safely (never touches window scroll)
  useEffect(() => {
    const el = chatFeedRef.current;
    if (!el) return;

    if (prevMsgCountRef.current === 0 && messages.length > 0) {
      // First load for this conversation: snap to bottom instantly
      el.scrollTop = el.scrollHeight;
    } else if (messages.length > prevMsgCountRef.current) {
      // Only smooth-scroll if user is already near bottom (within 140px)
      const isNearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 140;
      if (isNearBottom) {
        scrollChatToBottom(true);
      }
    }
    prevMsgCountRef.current = messages.length;
  }, [messages, scrollChatToBottom]);

  // Merge socket messages if relevant to currently active thread
  useEffect(() => {
    if (!selectedIncident || recentMessages.length === 0) return;
    const latest = recentMessages[recentMessages.length - 1];
    if (
      latest &&
      (latest.incident_id === selectedIncident.id || latest.incident_id === selectedIncident.complaint_id)
    ) {
      setMessages((prev) => {
        if (prev.some((m) => m.id === latest.id)) return prev;
        return [...prev, latest];
      });
      // Scroll down for own new message
      setTimeout(() => scrollChatToBottom(true), 50);
    }
  }, [recentMessages, selectedIncident, scrollChatToBottom]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !selectedIncident) return;
    const text = inputText.trim();
    setIsSending(true);
    try {
      const sent = await api.sendMessage(
        selectedIncident.id,
        {
          id: user?.id || 'usr-inv-101',
          name: user?.full_name || 'Special Agent Marcus Vance',
          role: user?.role || 'investigator',
        },
        text,
        isEvidenceRequest
      );
      setMessages((prev) => [...prev, sent]);
      addMessage(sent);
      setInputText('');
      setIsEvidenceRequest(false);
      setTimeout(() => scrollChatToBottom(true), 50);
    } catch (err) {
      console.error('Error dispatching message:', err);
    } finally {
      setIsSending(false);
    }
  };

  const handleManualRefresh = async () => {
    if (!selectedIncident) return;
    setIsRefreshing(true);
    try {
      const msgs = await api.getMessagesByIncident(selectedIncident.id);
      setMessages(msgs);
      setTimeout(() => scrollChatToBottom(false), 50);
    } finally {
      setTimeout(() => setIsRefreshing(false), 400);
    }
  };

  const civilianDisplayName = selectedIncident?.civilian_name || 'Civilian Complainant';
  const civilianInitial = (civilianDisplayName.trim().charAt(0) || 'C').toUpperCase();
  const caseReference = selectedIncident?.complaint_id || selectedIncident?.id?.slice(0, 8) || 'SG-CASE';

  return (
    <div className="space-y-4">
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
            Civilian Communications Hub
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Compliant, complaint-scoped messaging channel with civilians. All communications are logged in the audit trail.
          </p>
        </div>

        {selectedIncident && (
          <button
            type="button"
            onClick={handleManualRefresh}
            className="self-start sm:self-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-600 hover:bg-slate-50 shadow-xs transition-colors cursor-pointer"
            title="Refresh message feed"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-blue-600' : ''}`} />
            <span>Sync Messages</span>
          </button>
        )}
      </div>

      {/* Main Grid Workspace */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden grid grid-cols-1 md:grid-cols-12 h-[calc(100vh-210px)] min-h-[560px] max-h-[850px]">
        {/* Thread Selector (Left Column) */}
        <div className="md:col-span-4 border-r border-slate-200 flex flex-col h-full min-h-0 bg-slate-50/40">
          <div className="p-4 border-b border-slate-200 bg-white flex items-center justify-between shrink-0">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Assigned Complaint Threads ({incidents.length})
            </h2>
            <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-100">
              Live SOC Feed
            </span>
          </div>

          {/* Scrollable Cases List with Internal Scrolling */}
          <div className="divide-y divide-slate-100 overflow-y-auto flex-1 min-h-0 overscroll-contain">
            {incidents.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No complaint threads currently registered in database.
              </div>
            ) : (
              incidents.map((inc) => {
                const isSelected =
                  selectedIncident?.id === inc.id || selectedIncident?.complaint_id === inc.complaint_id;
                const complainantName = inc.civilian_name || 'Civilian Complainant';
                const createdDate = inc.created_at ? new Date(inc.created_at).toLocaleDateString() : 'Active';

                return (
                  <button
                    type="button"
                    key={inc.id}
                    onClick={() => {
                      setSelectedIncident(inc);
                    }}
                    className={`w-full text-left p-4 cursor-pointer transition-colors block border-l-4 select-none ${
                      isSelected
                        ? 'bg-blue-50/90 border-blue-600 shadow-xs'
                        : 'hover:bg-slate-100/70 border-transparent bg-transparent'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-[11px] font-bold text-blue-700 bg-white px-2 py-0.5 rounded border border-blue-200 shadow-2xs">
                        {inc.complaint_id || inc.id.slice(0, 8)}
                      </span>
                      <span className="text-[10px] text-slate-400 font-medium">
                        {createdDate}
                      </span>
                    </div>

                    <h3 className="text-xs font-bold text-slate-900 mt-1.5 truncate">
                      {inc.title || 'Untitled Incident'}
                    </h3>
                    <div className="flex items-center justify-between mt-1 text-[11px]">
                      <span className="text-slate-500 truncate">Complainant: {complainantName}</span>
                      {inc.severity && (
                        <span
                          className={`text-[9px] uppercase font-bold px-1.5 py-0.2 rounded shrink-0 ${
                            inc.severity === 'critical'
                              ? 'bg-red-100 text-red-700'
                              : inc.severity === 'high'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {inc.severity}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Message Thread (Right Column) */}
        <div className="md:col-span-8 flex flex-col h-full min-h-0 bg-white">
          {selectedIncident ? (
            <>
              {/* Header */}
              <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-white shrink-0">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-sm shrink-0 border border-blue-200 shadow-2xs">
                    {civilianInitial}
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-bold text-slate-900 truncate">
                      {civilianDisplayName}
                    </h3>
                    <p className="text-[11px] text-slate-500 truncate">
                      Case: <strong className="font-mono text-slate-800">{caseReference}</strong> •{' '}
                      {selectedIncident.title || 'Untitled Case'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700 rounded-lg border border-slate-200">
                    Chain-of-Custody Logged
                  </span>
                </div>
              </div>

              {/* Chat Feed (Internal Scroll Container) */}
              <div
                ref={chatFeedRef}
                className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50/40 min-h-0 overscroll-contain"
              >
                {messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full py-16 text-center text-slate-400">
                    <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-500 flex items-center justify-center mb-3">
                      <MessageSquare className="w-6 h-6" />
                    </div>
                    <p className="text-xs font-semibold text-slate-600">No messages in this case yet.</p>
                    <p className="text-[11px] text-slate-400 mt-1 max-w-sm">
                      Dispatch an initial message or formal evidence request to the complainant using the bar below.
                    </p>
                  </div>
                ) : (
                  messages.map((m) => {
                    const isMe = m.sender_role !== 'civilian';
                    const senderLabel = m.sender_name || (isMe ? 'Investigator' : 'Complainant');
                    const timeString = m.created_at
                      ? new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                      : '';

                    return (
                      <div key={m.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                        <div className="flex items-center gap-1.5 mb-1 px-1 text-[11px] text-slate-400">
                          <span className="font-semibold text-slate-700">{senderLabel}</span>
                          {timeString && (
                            <>
                              <span>•</span>
                              <span>{timeString}</span>
                            </>
                          )}
                        </div>

                        <div
                          className={`max-w-lg p-3.5 rounded-2xl text-xs leading-relaxed ${
                            isMe
                              ? 'bg-blue-600 text-white rounded-br-xs shadow-sm'
                              : m.is_evidence_request
                              ? 'bg-amber-50 text-amber-950 border border-amber-300 rounded-bl-xs shadow-sm'
                              : 'bg-white text-slate-800 border border-slate-200 rounded-bl-xs shadow-xs'
                          }`}
                        >
                          {m.is_evidence_request && (
                            <div className="flex items-center gap-1.5 font-bold text-amber-900 mb-1.5 pb-1 border-b border-amber-200">
                              <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                              <span>Forensic Evidence Request</span>
                            </div>
                          )}
                          <p className="whitespace-pre-wrap">{m.content}</p>

                          {m.attachment_name && (
                            <div
                              className={`mt-2 p-2 rounded-lg text-[11px] font-mono flex items-center gap-2 ${
                                isMe ? 'bg-blue-700/60 text-blue-100' : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              <FileCheck className="w-3.5 h-3.5 shrink-0" />
                              <span className="truncate">{m.attachment_name}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Input Area */}
              <form onSubmit={handleSend} className="p-4 border-t border-slate-200 bg-white shrink-0 space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="evidenceReq"
                    checked={isEvidenceRequest}
                    onChange={(e) => setIsEvidenceRequest(e.target.checked)}
                    className="rounded border-slate-300 text-amber-600 focus:ring-amber-500 cursor-pointer"
                  />
                  <label htmlFor="evidenceReq" className="text-xs font-bold text-slate-700 cursor-pointer">
                    Flag as Formal Evidence Request (prompts complainant for supporting logs/screenshots)
                  </label>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder={`Reply to ${civilianDisplayName}...`}
                    className="flex-1 px-4 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder:text-slate-400"
                  />
                  <Button
                    type="submit"
                    variant="primary"
                    size="md"
                    isLoading={isSending}
                    disabled={!inputText.trim()}
                    rightIcon={<Send className="w-4 h-4" />}
                  >
                    Dispatch
                  </Button>
                </div>
              </form>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center text-slate-400 m-auto">
              <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
                <MessageSquare className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-800">Select a Complaint Thread</h3>
              <p className="text-xs text-slate-400 max-w-sm mt-1">
                Choose an incident thread from the left column to inspect case logs and communicate with the complainant.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
