import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  BellRing,
  AlertTriangle,
  ShieldAlert,
  Search,
  Filter,
  Activity,
  Layers,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { api } from '../../services/api';
import { SecurityAlert } from '../../types';

export const SecurityAlerts: React.FC = () => {
  const [alerts, setAlerts] = useState<SecurityAlert[]>([]);
  const [filterSeverity, setFilterSeverity] = useState('all');

  useEffect(() => {
    const load = async () => {
      const data = await api.getAlerts();
      setAlerts(data);
    };
    load();
  }, []);

  const filtered = alerts.filter(
    (a) => filterSeverity === 'all' || a.severity === filterSeverity
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
            SOC Telemetry & Detection Alerts
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Raw security events parsed through rule-based detection engines and correlated with reported civilian cases.
          </p>
        </div>
      </div>

      {/* Filter toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-600">Filter Severity:</span>
          {['all', 'critical', 'high', 'medium'].map((sev) => (
            <button
              key={sev}
              onClick={() => setFilterSeverity(sev)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-colors ${
                filterSeverity === sev
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>
        <div className="text-xs text-slate-500 font-medium">
          Showing <strong>{filtered.length}</strong> alerts
        </div>
      </div>

      {/* Alert Feed */}
      <div className="space-y-4">
        {filtered.map((alert) => (
          <div
            key={alert.id}
            className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all space-y-3"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                  {alert.detection_rule_name}
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500 font-medium">Source: {alert.source}</span>
              </div>
              <Badge severity={alert.severity} />
            </div>

            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div className="space-y-1 max-w-3xl">
                <h3 className="text-base font-bold text-slate-900">{alert.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{alert.description}</p>
              </div>

              {alert.correlated_incident_id && (
                <div className="shrink-0 text-right">
                  <Link to={`/investigator/incidents/${alert.correlated_incident_id}`}>
                    <Button variant="outline" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
                      View Correlated Incident
                    </Button>
                  </Link>
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>Timestamp: {new Date(alert.created_at).toLocaleString()}</span>
              <span>Status: <strong className="text-slate-700 uppercase">{alert.status}</strong></span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
