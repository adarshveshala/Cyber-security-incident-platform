import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ShieldAlert,
  ArrowLeft,
  User,
  Calendar,
  Clock,
  Globe,
  DollarSign,
  Fingerprint,
  FileCheck,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  MessageSquare,
  History,
  Activity,
  Layers,
  FileSpreadsheet,
  Plus,
  MapPin,
  Laptop,
  Compass,
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { Incident, IncidentStatus, IncidentSeverity, AIAnalysisResult, ResponsePlaybook } from '../../types';
import { getDefaultAvatar } from '../../utils/avatars';

export const IncidentWorkspace: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [incident, setIncident] = useState<Incident | null>(null);
  const [loading, setLoading] = useState(true);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [statusModalOpen, setStatusModalOpen] = useState(false);
  const [newStatus, setNewStatus] = useState<IncidentStatus>('investigation_in_progress');
  const [statusNotes, setStatusNotes] = useState('');
  const [notes, setNotes] = useState<{ author: string; text: string; date: string }[]>([
    {
      author: 'Special Agent Marcus Vance',
      text: 'Verified initial RFC 822 email headers. Reverse DNS check on 194.26.29.112 indicates high-risk bulletproof ASN.',
      date: '2026-11-15T10:30:00Z',
    },
  ]);
  const [newNoteText, setNewNoteText] = useState('');

  useEffect(() => {
    const load = async () => {
      if (id) {
        const found = await api.getIncidentById(id);
        setIncident(found);
        if (found) {
          setNewStatus(found.status);
        }
      }
      setLoading(false);
    };
    load();
  }, [id]);

  const handleRunAiCopilot = async () => {
    if (!incident) return;
    setIsAnalyzing(true);
    try {
      const result = await api.getInvestigatorAICopilot(incident.id);
      setAiAnalysis(result);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleStatusUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!incident) return;
    try {
      const updated = await api.updateIncidentStatus(
        incident.id,
        newStatus,
        user?.full_name || 'Special Agent Marcus Vance',
        statusNotes
      );
      setIncident(updated);
      setStatusModalOpen(false);
      setStatusNotes('');
    } catch (e: any) {
      console.error(e);
    }
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim()) return;
    setNotes((prev) => [
      ...prev,
      {
        author: user?.full_name || 'Special Agent Marcus Vance',
        text: newNoteText.trim(),
        date: new Date().toISOString(),
      },
    ]);
    setNewNoteText('');
  };

  if (loading) {
    return <div className="p-12 text-center text-xs text-slate-500">Loading forensic workspace...</div>;
  }

  if (!incident) {
    return (
      <div className="p-12 text-center space-y-4">
        <h2 className="text-lg font-bold text-slate-800">Incident Not Found</h2>
        <Link to="/investigator/soc">
          <Button variant="outline">Back to SOC Overview</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Breadcrumb & Action Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <Link
            to="/investigator/soc"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors mb-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to SOC Overview
          </Link>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-extrabold text-[#172554]">{incident.title}</h1>
            <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200">
              {incident.complaint_id}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Button
            variant="teal"
            onClick={handleRunAiCopilot}
            isLoading={isAnalyzing}
            leftIcon={<Sparkles className="w-4 h-4" />}
          >
            Run AI Forensic Copilot
          </Button>

          <Button variant="primary" onClick={() => setStatusModalOpen(true)}>
            Update Case Status
          </Button>

          <Link to="/investigator/messages">
            <Button variant="outline" leftIcon={<MessageSquare className="w-4 h-4 text-blue-600" />}>
              Civilian Channel
            </Button>
          </Link>
        </div>
      </div>

      {/* Incident Status Pill Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-4 text-xs">
          <div>
            <span className="text-slate-400">Severity:</span>
            <div className="mt-0.5">
              <Badge severity={incident.severity} />
            </div>
          </div>
          <div className="h-8 w-px bg-slate-200 hidden sm:block"></div>
          <div>
            <span className="text-slate-400">Status:</span>
            <div className="mt-0.5">
              <Badge status={incident.status} />
            </div>
          </div>
          <div className="h-8 w-px bg-slate-200 hidden sm:block"></div>
          <div>
            <span className="text-slate-400">Assigned Investigator:</span>
            <div className="flex items-center gap-2 mt-0.5">
              <img
                src={getDefaultAvatar('male', 'investigator')}
                alt="Investigator"
                className="w-5 h-5 rounded-md object-cover border border-slate-200"
              />
              <p className="font-bold text-slate-800 text-xs">
                {incident.assigned_investigator_name || 'Unassigned (Triage)'}
              </p>
            </div>
          </div>
          <div className="h-8 w-px bg-slate-200 hidden sm:block"></div>
          <div>
            <span className="text-slate-400">Complainant:</span>
            <div className="flex items-center gap-2 mt-0.5">
              <img
                src={getDefaultAvatar('female', 'civilian')}
                alt={incident.civilian_name}
                className="w-5 h-5 rounded-md object-cover border border-slate-200"
              />
              <p className="font-bold text-slate-800 text-xs">{incident.civilian_name}</p>
            </div>
          </div>
        </div>

        <div className="text-right text-xs">
          <span className="text-slate-400">Financial Loss:</span>
          <p className="font-extrabold text-red-600 text-sm">
            {incident.financial_loss ? `$${incident.financial_loss.toLocaleString()}` : '$0'}
          </p>
        </div>
      </div>

      {/* AI Copilot Results Panel (When Triggered) */}
      {aiAnalysis && (
        <div className="bg-gradient-to-br from-teal-50/90 via-white to-blue-50/60 rounded-2xl p-6 border-2 border-teal-300/80 shadow-md space-y-6">
          <div className="flex items-center justify-between border-b border-teal-100 pb-3">
            <div className="flex items-center gap-2 text-teal-900">
              <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold">Investigator AI Copilot Analysis</h3>
                <p className="text-[11px] text-teal-700">Grounded strictly in verified evidence artifacts</p>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-teal-100 text-teal-800">
              Confidence Score: {aiAnalysis.confidence_score}%
            </span>
          </div>

          <p className="text-xs text-slate-700 leading-relaxed font-normal">{aiAnalysis.summary}</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Key Findings */}
            <div className="space-y-2">
              <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">Key Forensic Findings:</h4>
              <ul className="space-y-1.5">
                {aiAnalysis.key_findings.map((f, i) => (
                  <li key={i} className="flex items-start gap-1.5 text-slate-700 leading-relaxed">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-600 mt-1.5 shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* MITRE ATT&CK Mapping */}
            <div className="space-y-2">
              <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">MITRE ATT&CK Mapping:</h4>
              <div className="space-y-2">
                {aiAnalysis.mitre_techniques.map((tech) => (
                  <div key={tech.id} className="p-2.5 rounded-xl bg-white border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-blue-700">{tech.id}</span>
                      <span className="text-[10px] uppercase font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                        {tech.tactic}
                      </span>
                    </div>
                    <div className="font-bold text-slate-800">{tech.name}</div>
                    <p className="text-[11px] text-slate-600">{tech.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recommended Investigation Steps */}
          <div className="p-4 rounded-xl bg-blue-50/80 border border-blue-200 space-y-2 text-xs">
            <h4 className="font-bold text-blue-900 uppercase tracking-wider text-[11px]">Recommended Response Steps:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {aiAnalysis.recommended_actions.map((act, i) => (
                <div key={i} className="flex items-start gap-2 bg-white p-2.5 rounded-lg border border-blue-100 text-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span>{act}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Forensic Grid: Evidence Gallery, Case Notes, Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Evidence & Case Description */}
        <div className="lg:col-span-7 space-y-6">
          {/* Incident Details Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-slate-900">Incident Scope & Indicators</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-slate-400">Civilian Location:</span>
                <p className="font-semibold text-slate-800 mt-0.5 bg-slate-50 p-2 rounded border border-slate-200 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span className="truncate">{incident.location_name || 'Unspecified'}</span>
                </p>
              </div>
              <div>
                <span className="text-slate-400">Reporting Device IP:</span>
                <p className="font-mono font-semibold text-emerald-800 mt-0.5 bg-emerald-50/70 p-2 rounded border border-emerald-200 flex items-center gap-1.5">
                  <Laptop className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>{incident.reporter_ip || 'Auto-Captured (Forensic Log)'}</span>
                </p>
              </div>
              <div>
                <span className="text-slate-400">Suspect Information:</span>
                <p className="font-mono font-semibold text-slate-800 mt-0.5 bg-slate-50 p-2 rounded border border-slate-200">
                  {incident.suspect_info || 'None submitted'}
                </p>
              </div>
              <div>
                <span className="text-slate-400">Platform Involved:</span>
                <p className="font-semibold text-slate-800 mt-0.5 bg-slate-50 p-2 rounded border border-slate-200">
                  {incident.platform_involved || 'Unspecified'}
                </p>
              </div>
              {incident.latitude && incident.longitude && (
                <div className="sm:col-span-2">
                  <span className="text-slate-400">Geospatial SOC Coordinates:</span>
                  <div className="flex items-center justify-between bg-blue-50/70 p-2 rounded border border-blue-200 mt-0.5">
                    <span className="font-mono text-blue-800 text-xs">
                      {incident.latitude.toFixed(4)}° N, {incident.longitude.toFixed(4)}° E &bull; {incident.location_name}
                    </span>
                    <Link
                      to="/investigator/overview"
                      className="text-[11px] font-bold text-blue-700 hover:underline shrink-0 ml-2 flex items-center gap-1"
                    >
                      <Compass className="w-3.5 h-3.5" />
                      <span>View on SOC Intelligence Map &rarr;</span>
                    </Link>
                  </div>
                </div>
              )}
              {incident.website_url && (
                <div className="sm:col-span-2">
                  <span className="text-slate-400">Target Website / URL:</span>
                  <div className="flex items-center justify-between bg-slate-50 p-2 rounded border border-slate-200 mt-0.5">
                    <span className="font-mono text-blue-700 truncate">{incident.website_url}</span>
                    <Link
                      to={`/investigator/threat-intel?q=${encodeURIComponent(incident.website_url)}`}
                      className="text-[11px] font-bold text-teal-700 hover:underline shrink-0 ml-2"
                    >
                      Enrich Threat Intel &rarr;
                    </Link>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-slate-100">
              <span className="text-xs text-slate-400">Full Incident Description:</span>
              <p className="text-xs text-slate-800 font-normal mt-1 leading-relaxed whitespace-pre-wrap">
                {incident.description}
              </p>
            </div>
          </div>

          {/* Evidence Repository & Hashes */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900">Cryptographic Evidence Vault</h2>
                <p className="text-xs text-slate-500">SHA-256 integrity verified artifacts</p>
              </div>
              <span className="text-xs font-mono font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                {incident.evidence?.length || 0} Artifacts
              </span>
            </div>

            {(!incident.evidence || incident.evidence.length === 0) ? (
              <div className="p-6 text-center text-xs text-slate-400 bg-slate-50 rounded-xl">
                No evidence files associated with this record.
              </div>
            ) : (
              <div className="space-y-3">
                {incident.evidence.map((ev) => (
                  <div
                    key={ev.id}
                    className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-2 hover:border-slate-300 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <FileCheck className="w-5 h-5 text-teal-600 shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-slate-900">{ev.file_name}</p>
                          <p className="text-[11px] text-slate-500">
                            {(ev.file_size / 1024).toFixed(1)} KB • Uploaded by {ev.uploaded_by_name}
                          </p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-teal-50 text-teal-700 border border-teal-200 rounded">
                        INTEGRITY SECURED
                      </span>
                    </div>

                    <div className="flex items-center gap-2 bg-slate-50 p-2 rounded text-[10px] font-mono text-slate-600">
                      <Fingerprint className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span className="truncate">SHA-256: {ev.sha256_hash}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Case Notes & Official Timeline */}
        <div className="lg:col-span-5 space-y-6">
          {/* Internal Investigator Notes */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Internal Forensic Notes</h3>
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {notes.map((n, i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span className="font-bold text-slate-700">{n.author}</span>
                    <span>{new Date(n.date).toLocaleDateString()}</span>
                  </div>
                  <p className="text-slate-700">{n.text}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handleAddNote} className="space-y-2 pt-2 border-t border-slate-100">
              <textarea
                rows={2}
                value={newNoteText}
                onChange={(e) => setNewNoteText(e.target.value)}
                placeholder="Add confidential internal observation or IOC note..."
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
              <div className="flex justify-end">
                <Button type="submit" variant="secondary" size="sm" leftIcon={<Plus className="w-3.5 h-3.5" />}>
                  Save Internal Note
                </Button>
              </div>
            </form>
          </div>

          {/* Forensic Audit Timeline */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Forensic Chain-of-Custody Timeline</h3>
            <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
              {incident.timeline?.map((evt) => (
                <div key={evt.id} className="relative space-y-1">
                  <div className="absolute -left-6 top-1 w-2.5 h-2.5 rounded-full bg-blue-600 ring-4 ring-white" />
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-slate-900">{evt.actor_name}</span>
                    <span className="text-slate-400">
                      {new Date(evt.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{evt.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Modal: Status Management */}
      <Modal
        isOpen={statusModalOpen}
        onClose={() => setStatusModalOpen(false)}
        title="Update Investigation Lifecycle Status"
        subtitle={`Case ID: ${incident.complaint_id}`}
      >
        <form onSubmit={handleStatusUpdate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Select New Status</label>
            <select
              value={newStatus}
              onChange={(e) => setNewStatus(e.target.value as IncidentStatus)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none font-semibold text-slate-800"
            >
              <option value="submitted">Submitted (Awaiting Triage)</option>
              <option value="under_review">Under Review</option>
              <option value="assigned">Assigned</option>
              <option value="investigation_in_progress">Investigation in Progress</option>
              <option value="additional_info_required">Additional Information Required</option>
              <option value="resolved">Resolved (Evidence Complete)</option>
              <option value="closed">Closed</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Status Transition Notes / Reason</label>
            <textarea
              rows={3}
              value={statusNotes}
              onChange={(e) => setStatusNotes(e.target.value)}
              placeholder="e.g. Host isolated and wire recall notice confirmed with beneficiary financial institution."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <Button type="button" variant="outline" onClick={() => setStatusModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Commit Status Change
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
