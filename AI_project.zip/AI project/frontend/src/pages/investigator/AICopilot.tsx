import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Search,
  FileCheck,
  ShieldAlert,
  ArrowRight,
  CheckCircle2,
  FileText,
  Copy,
  AlertTriangle,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { api } from '../../services/api';
import { Incident, AIAnalysisResult } from '../../types';

export const AICopilot: React.FC = () => {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [selectedIncidentId, setSelectedIncidentId] = useState<string>('');
  const [analysis, setAnalysis] = useState<AIAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const load = async () => {
      const all = await api.getIncidents();
      setIncidents(all);
      if (all.length > 0) {
        setSelectedIncidentId(all[0].id);
        runAnalysis(all[0].id);
      }
    };
    load();
  }, []);

  const runAnalysis = async (incidentId: string) => {
    setIsLoading(true);
    try {
      const res = await api.getInvestigatorAICopilot(incidentId);
      setAnalysis(res);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyReport = () => {
    if (!analysis) return;
    const reportText = `SENTINEL GRID - AI INVESTIGATIVE DOSSIER
Incident: ${analysis.incident_id}
Confidence Score: ${analysis.confidence_score}%
Summary: ${analysis.summary}

KEY FINDINGS:
${analysis.key_findings.map((f) => `- ${f}`).join('\n')}

MITRE ATT&CK TECHNIQUES:
${analysis.mitre_techniques.map((t) => `- [${t.id}] ${t.name} (${t.tactic})`).join('\n')}

INVESTIGATIVE INQUIRIES:
${analysis.suggested_questions.map((q) => `- ${q}`).join('\n')}

RECOMMENDED ACTIONS:
${analysis.recommended_actions.map((a) => `- ${a}`).join('\n')}
`;
    navigator.clipboard.writeText(reportText);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const currentInc = incidents.find((i) => i.id === selectedIncidentId);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-700 text-[11px] font-bold border border-teal-200 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            SOC Forensic Intelligence Engine
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
            AI Investigation Copilot
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Automated complaint synthesis, MITRE ATT&CK alignment, and evidence gap identification.
          </p>
        </div>

        {analysis && (
          <Button variant="outline" size="sm" onClick={handleCopyReport} leftIcon={<Copy className="w-4 h-4 text-slate-600" />}>
            {copied ? 'Copied Dossier!' : 'Copy Case Dossier'}
          </Button>
        )}
      </div>

      {/* Target Case Selector */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs font-bold text-slate-700 whitespace-nowrap">Select Incident to Analyze:</span>
          <select
            value={selectedIncidentId}
            onChange={(e) => {
              setSelectedIncidentId(e.target.value);
              runAnalysis(e.target.value);
            }}
            className="text-xs border border-slate-300 rounded-lg px-3 py-2 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-96 font-medium"
          >
            {incidents.map((i) => (
              <option key={i.id} value={i.id}>
                {i.complaint_id} — {i.title}
              </option>
            ))}
          </select>
        </div>

        <Button
          variant="teal"
          size="sm"
          onClick={() => runAnalysis(selectedIncidentId)}
          isLoading={isLoading}
          leftIcon={<Sparkles className="w-3.5 h-3.5" />}
        >
          Re-Synthesize Copilot Analysis
        </Button>
      </div>

      {/* Main Analysis Display */}
      {analysis && (
        <div className="space-y-6">
          {/* Executive Synthesis Card */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-sm space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
                  Forensic Copilot Summary
                </span>
                <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                  {currentInc?.title} ({currentInc?.complaint_id})
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-teal-50 text-teal-800 border border-teal-200">
                  Reliability: High ({analysis.confidence_score}%)
                </span>
                <Badge severity={analysis.recommended_severity} />
              </div>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed font-normal whitespace-pre-wrap">
              {analysis.summary}
            </p>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500 italic">
              <strong>Guardrail Compliance:</strong> {analysis.caveat_notes}
            </div>
          </div>

          {/* 3-Column Detailed Analysis Matrix */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Key Findings */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Key Observational Findings
              </h4>
              <ul className="space-y-2 text-xs">
                {analysis.key_findings.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-slate-700 leading-relaxed">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-1.5 shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* MITRE ATT&CK Alignment */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                MITRE ATT&CK Matrix Alignment
              </h4>
              <div className="space-y-2">
                {analysis.mitre_techniques.map((t) => (
                  <div key={t.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-blue-700">{t.id}</span>
                      <span className="text-[10px] uppercase font-bold text-slate-500 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                        {t.tactic}
                      </span>
                    </div>
                    <div className="font-bold text-slate-800">{t.name}</div>
                    <p className="text-[11px] text-slate-500">{t.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Inquiries & Gaps */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Missing Evidence & Inquiries
              </h4>
              <ul className="space-y-2 text-xs">
                {analysis.suggested_questions.map((q, i) => (
                  <li key={i} className="flex items-start gap-2 text-slate-700 leading-relaxed">
                    <HelpCircle className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                    <span>{q}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
