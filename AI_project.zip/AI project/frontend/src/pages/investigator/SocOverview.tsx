import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Activity,
  AlertTriangle,
  ShieldAlert,
  Clock,
  CheckCircle2,
  Users,
  Layers,
  ArrowRight,
  TrendingUp,
  FileCheck,
  Search,
  Filter,
  Sparkles,
  ExternalLink,
  Shield,
  Cpu,
  Fingerprint,
  Radio,
  BadgeCheck,
  Globe2,
  RefreshCw
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { api } from '../../services/api';
import { Incident, SecurityAlert } from '../../types';
import { getDefaultAvatar } from '../../utils/avatars';
import { GeospatialIncidentMap } from '../../components/soc/GeospatialIncidentMap';

const TREND_DATA = [
  { day: 'Mon', incidents: 4, alerts: 18, resolved: 3 },
  { day: 'Tue', incidents: 7, alerts: 25, resolved: 5 },
  { day: 'Wed', incidents: 5, alerts: 22, resolved: 4 },
  { day: 'Thu', incidents: 9, alerts: 34, resolved: 7 },
  { day: 'Fri', incidents: 12, alerts: 41, resolved: 8 },
  { day: 'Sat', incidents: 6, alerts: 19, resolved: 5 },
  { day: 'Sun', incidents: 8, alerts: 28, resolved: 6 },
];

export const SocOverview: React.FC = () => {
  const { user } = useAuth();
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [alerts, setAlerts] = useState<SecurityAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastSynced, setLastSynced] = useState<string>('Just now');
  const navigate = useNavigate();

  const loadData = async (isManual = false) => {
    if (isManual) setIsRefreshing(true);
    try {
      const [incData, altData] = await Promise.all([
        api.getIncidents(),
        api.getAlerts(),
      ]);
      setIncidents(incData);
      setAlerts(altData);
      setLastSynced(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (err) {
      console.error('Error fetching live SOC data:', err);
    } finally {
      setLoading(false);
      if (isManual) setTimeout(() => setIsRefreshing(false), 500);
    }
  };

  useEffect(() => {
    loadData();
    // Auto-poll live database state every 10 seconds
    const interval = setInterval(() => {
      loadData();
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const totalIncidents = incidents.length;
  const criticalCount = incidents.filter(i => i.severity === 'critical').length;
  const activeInvestigations = incidents.filter(i => i.status === 'investigation_in_progress' || i.status === 'assigned').length;
  const newComplaints = incidents.filter(i => i.status === 'submitted' || i.status === 'under_review').length;
  const resolvedCount = incidents.filter(i => i.status === 'resolved' || i.status === 'closed').length;

  const severityData = [
    { name: 'Critical', value: criticalCount, color: '#DC2626' },
    { name: 'High', value: incidents.filter(i => i.severity === 'high').length, color: '#F97316' },
    { name: 'Medium', value: incidents.filter(i => i.severity === 'medium').length, color: '#F59E0B' },
    { name: 'Low', value: incidents.filter(i => i.severity === 'low').length, color: '#10B981' },
  ];

  return (
    <div className="space-y-8">
      {/* 1. Top SOC Command Header with Detective Portrait & Operational Crest */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-md relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Subtle Cyber Circuit Mesh Telemetry Overlay */}
        <div className="absolute inset-0 bg-circuit-mesh pointer-events-none opacity-80"></div>
        <div className="flex items-start sm:items-center gap-5 z-10">
          <div className="relative shrink-0">
            <img
              src={user?.avatar_url || getDefaultAvatar(user?.gender, user?.role)}
              alt={user?.full_name || 'Investigator'}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-slate-800 shadow-sm"
            />
            <div className="absolute -bottom-1.5 -right-1.5 p-1 bg-slate-900 text-blue-400 rounded-lg shadow-sm" title="Lead Detective">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-900 text-white">
                Badge #{user?.badge_number || 'SG-INV-8492'}
              </span>
              <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Database Connected ({totalIncidents} Incidents)
              </span>
              <button
                type="button"
                onClick={() => loadData(true)}
                disabled={isRefreshing}
                className="flex items-center gap-1 text-[11px] font-bold text-slate-600 hover:text-blue-700 bg-slate-100 hover:bg-slate-200 px-2.5 py-0.5 rounded-full transition-colors border border-slate-200"
                title="Fetch latest updates from database"
              >
                <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin text-blue-600' : ''}`} />
                <span>{isRefreshing ? 'Syncing...' : 'Sync Now'}</span>
              </button>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554] tracking-tight">
              Security Operations Center (SOC)
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 max-w-xl">
              Monitor incoming complaints, correlate threat indicators, and direct incident response.
            </p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap sm:flex-col gap-2.5 w-full md:w-auto z-10 shrink-0">
          <Link to="/investigator/queue" className="flex-1 sm:flex-initial">
            <Button variant="primary" size="md" className="w-full bg-slate-900 hover:bg-slate-800 text-white shadow-md shadow-slate-900/20" leftIcon={<Layers className="w-4 h-4 text-blue-400" />}>
              Triage Queue ({newComplaints})
            </Button>
          </Link>
          <Link to="/investigator/threat-intel" className="flex-1 sm:flex-initial">
            <Button variant="outline" size="md" className="w-full" leftIcon={<Search className="w-4 h-4 text-slate-500" />}>
              Lookup Indicator
            </Button>
          </Link>
        </div>

        {/* Decorative background logo */}
        <div className="absolute right-0 top-0 bottom-0 w-1/4 opacity-5 pointer-events-none flex items-center justify-center">
          <Shield className="w-80 h-80 -mr-10 text-slate-900" />
        </div>
      </div>

      {/* 2. Vibrant KPI Stat Cards with Colored Top Borders */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 border-t-4 border-t-slate-800 shadow-sm space-y-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Total Cases</p>
          <div className="text-3xl font-black text-[#172554]">{totalIncidents}</div>
          <p className="text-[11px] text-slate-400 font-medium">Total incidents</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 border-t-4 border-t-blue-500 shadow-sm space-y-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-blue-700">New Complaints</p>
          <div className="text-3xl font-black text-blue-600">{newComplaints}</div>
          <p className="text-[11px] text-blue-600 font-semibold">Awaiting triage</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 border-t-4 border-t-teal-500 shadow-sm space-y-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-teal-700">In Progress</p>
          <div className="text-3xl font-black text-teal-600">{activeInvestigations}</div>
          <p className="text-[11px] text-teal-600 font-semibold">Active investigations</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 border-t-4 border-t-red-500 shadow-sm space-y-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-red-700">Critical Priority</p>
          <div className="text-3xl font-black text-red-600">{criticalCount}</div>
          <p className="text-[11px] text-red-600 font-semibold">High impact</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 border-t-4 border-t-emerald-500 shadow-sm space-y-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">Resolved</p>
          <div className="text-3xl font-black text-emerald-600">{resolvedCount}</div>
          <p className="text-[11px] text-emerald-600 font-semibold">Closed with report</p>
        </div>
      </div>

      {/* 3. GEOSPATIAL INCIDENT INTELLIGENCE MAP */}
      <GeospatialIncidentMap incidents={incidents} />

      {/* 4. Visual Analytics Charts: Trends & Severity Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* 7-Day Activity Trends */}
        <div className="lg:col-span-8 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Weekly Threat & Ingestion Cadence</h2>
              <p className="text-xs text-slate-500">Correlated security events vs verified complaints</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-blue-600 font-bold">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span> Incidents
              </span>
              <span className="flex items-center gap-1.5 text-teal-600 font-bold">
                <span className="w-2.5 h-2.5 rounded-full bg-teal-500"></span> Raw Alerts
              </span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={TREND_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorInc" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorAlt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0D9488" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#0D9488" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" stroke="#94A3B8" fontSize={12} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={12} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: '12px',
                    border: '1px solid #E2E8F0',
                    fontSize: '12px',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                  }}
                />
                <Area type="monotone" dataKey="incidents" stroke="#2563EB" strokeWidth={2.5} fillOpacity={1} fill="url(#colorInc)" />
                <Area type="monotone" dataKey="alerts" stroke="#0D9488" strokeWidth={2.5} fillOpacity={1} fill="url(#colorAlt)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Severity Distribution Donut */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Severity Distribution</h2>
            <p className="text-xs text-slate-500">Current active workload by threat rating</p>
          </div>

            <div className="h-44 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={severityData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {severityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: '8px',
                    border: '1px solid #E2E8F0',
                    fontSize: '11px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-100">
            {severityData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></span>
                <span className="text-slate-600 font-medium">{item.name}:</span>
                <strong className="text-slate-900">{item.value}</strong>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 4. Priority Triage Queue & Live Alert Feed with Visual Thumbnails */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Priority Incident Queue */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                <Layers className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">Priority Incident Queue</h2>
                <p className="text-xs text-slate-500">Complaints awaiting investigator triage & evidence review</p>
              </div>
            </div>
            <Link to="/investigator/queue">
              <Button variant="ghost" size="sm" rightIcon={<ArrowRight className="w-4 h-4" />}>
                Full Queue
              </Button>
            </Link>
          </div>

          <div className="divide-y divide-slate-100">
            {incidents.slice(0, 4).map((inc) => (
              <div
                key={inc.id}
                onClick={() => navigate(`/investigator/incidents/${inc.id}`)}
                className="p-5 hover:bg-slate-50/80 cursor-pointer transition-colors space-y-2.5"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-lg border border-blue-200">
                      {inc.complaint_id}
                    </span>
                    <span className="text-xs font-semibold text-slate-600 capitalize">
                      {inc.category.replace(/_/g, ' ')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge severity={inc.severity} />
                    <Badge status={inc.status} />
                  </div>
                </div>

                <h3 className="text-sm font-bold text-slate-900 hover:text-blue-600 transition-colors">
                  {inc.title}
                </h3>

                <div className="flex flex-wrap items-center justify-between text-xs text-slate-500 pt-1 border-t border-slate-100 gap-2">
                  <div className="flex items-center gap-2">
                    <img
                      src={getDefaultAvatar('female', 'civilian')}
                      alt={inc.civilian_name}
                      className="w-5 h-5 rounded-md object-cover border border-slate-200"
                    />
                    <span>Complainant: <strong className="text-slate-800">{inc.civilian_name}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 font-mono text-[11px] text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                    <Fingerprint className="w-3 h-3" />
                    <span>Evidence Hash Stamped</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live SOC Alerts Ingestion Feed with Real Photo Accent */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden flex flex-col justify-between">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center font-bold">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">Security Alert Feed</h2>
                <p className="text-xs text-slate-500">Live detection rule triggers</p>
              </div>
            </div>
            <Link to="/investigator/alerts">
              <Button variant="ghost" size="sm" rightIcon={<ExternalLink className="w-3.5 h-3.5" />}>
                View All
              </Button>
            </Link>
          </div>

          <div className="divide-y divide-slate-100 flex-1 overflow-y-auto max-h-96">
            {alerts.map((alt) => (
              <div key={alt.id} className="p-4 hover:bg-slate-50 transition-colors space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                    {alt.detection_rule_name}
                  </span>
                  <Badge severity={alt.severity} size="sm" />
                </div>
                <h4 className="text-xs font-bold text-slate-800">{alt.title}</h4>
                <p className="text-[11px] text-slate-500 leading-snug">{alt.description}</p>
                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                  <span>Source: {alt.source}</span>
                  {alt.correlated_incident_id && (
                    <span className="text-blue-600 font-bold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                      Correlated Case
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 bg-slate-50 border-t border-slate-100 text-center">
            <Link to="/investigator/copilot" className="text-xs font-bold text-teal-700 hover:text-teal-900 flex items-center justify-center gap-1.5">
              <Sparkles className="w-4 h-4 text-teal-600" />
              <span>Launch AI Forensic Copilot on Active Telemetry &rarr;</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
