import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Shield,
  ShieldCheck,
  Building2,
  Mail,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';
import { AVATAR_PRESETS, getDefaultAvatar } from '../../utils/avatars';

interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  badge: string;
  department: string;
  activeCases: number;
  status: 'active' | 'on_leave';
  avatar: string;
}

const INITIAL_TEAM: TeamMember[] = [
  {
    id: 'usr-inv-101',
    name: 'Special Agent Marcus Vance',
    email: 'marcus.vance@sentinelgrid.io',
    role: 'investigator',
    badge: 'SG-INV-8492',
    department: 'Cyber Fraud & Ransomware Unit',
    activeCases: 4,
    status: 'active',
    avatar: AVATAR_PRESETS[4].url, // Special Agent Marcus (Male Tactical)
  },
  {
    id: 'usr-inv-202',
    name: 'Lead Detective Elena Rostova',
    email: 'elena.rostova@sentinelgrid.io',
    role: 'senior_investigator',
    badge: 'SG-LEAD-1049',
    department: 'Advanced Threat Triage & Incident Response',
    activeCases: 3,
    status: 'active',
    avatar: AVATAR_PRESETS[1].url, // Lead Detective Elena (Female Forensic)
  },
  {
    id: 'usr-adm-999',
    name: 'Director David Sterling',
    email: 'admin@sentinelgrid.io',
    role: 'admin',
    badge: 'SG-DIR-0001',
    department: 'Platform Administration & Security Operations',
    activeCases: 1,
    status: 'active',
    avatar: AVATAR_PRESETS[5].url, // Director Sterling (Male Command)
  },
];

export const TeamManagement: React.FC = () => {
  const { user } = useAuth();
  const [team, setTeam] = useState<TeamMember[]>(INITIAL_TEAM);
  const [modalOpen, setModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('investigator');
  const [newDepartment, setNewDepartment] = useState('Digital Forensics & Triage');

  const isAdmin = user?.role === 'admin' || user?.role === 'senior_investigator';

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEmail.trim()) return;

    const randomBadge = `SG-INV-${Math.floor(1000 + Math.random() * 9000)}`;
    const newMember: TeamMember = {
      id: `usr-inv-${Date.now().toString().slice(-4)}`,
      name: newName.trim(),
      email: newEmail.trim(),
      role: newRole,
      badge: randomBadge,
      department: newDepartment,
      activeCases: 0,
      status: 'active',
      avatar: getDefaultAvatar(newRole === 'senior_investigator' ? 'female' : 'male', newRole),
    };

    setTeam((prev) => [...prev, newMember]);
    setModalOpen(false);
    setNewName('');
    setNewEmail('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
            Forensic Team & Access Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Certified investigator roster, assigned case distribution, and authorized account provisioning.
          </p>
        </div>

        {isAdmin && (
          <Button variant="primary" onClick={() => setModalOpen(true)} leftIcon={<UserPlus className="w-4 h-4" />}>
            Provision New Investigator
          </Button>
        )}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-bold text-[10px]">
                <th className="py-3.5 px-4">Investigator Name</th>
                <th className="py-3.5 px-4">Badge Number</th>
                <th className="py-3.5 px-4">Security Role</th>
                <th className="py-3.5 px-4">Department Unit</th>
                <th className="py-3.5 px-4">Active Cases</th>
                <th className="py-3.5 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {team.map((member) => (
                <tr key={member.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={member.avatar}
                        alt={member.name}
                        className="w-9 h-9 rounded-xl object-cover border border-slate-200 shadow-xs"
                      />
                      <div>
                        <div className="font-bold text-slate-900">{member.name}</div>
                        <div className="text-[11px] text-slate-500">{member.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-blue-700">{member.badge}</td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-700">
                      {member.role.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-600">{member.department}</td>
                  <td className="py-3.5 px-4 font-bold text-slate-900">{member.activeCases} active</td>
                  <td className="py-3.5 px-4">
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      Active
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Provision Investigator Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Provision Authorized Investigator Account"
        subtitle="Administrator Action: Issue credentials and badge identifier"
      >
        <form onSubmit={handleAddMember} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Full Legal Name</label>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g. Detective Robert Hayes"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Official Email Address</label>
            <input
              type="email"
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              placeholder="robert.hayes@sentinelgrid.io"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Assigned Role</label>
              <select
                value={newRole}
                onChange={(e) => setNewRole(e.target.value as UserRole)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none font-medium"
              >
                <option value="investigator">Investigator</option>
                <option value="senior_investigator">Senior Investigator / Lead</option>
                <option value="admin">System Administrator</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Department</label>
              <input
                type="text"
                value={newDepartment}
                onChange={(e) => setNewDepartment(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Issue Credentials & Save
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
