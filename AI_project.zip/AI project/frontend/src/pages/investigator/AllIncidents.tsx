import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Layers, Search, Filter, Download, ArrowRight } from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { api } from '../../services/api';
import { Incident } from '../../types';

export const AllIncidents: React.FC = () => {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    const load = async () => {
      const data = await api.getIncidents();
      setIncidents(data);
    };
    load();
  }, []);

  const filtered = incidents.filter((inc) => {
    const matchesSearch =
      inc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.complaint_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.civilian_name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || inc.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const exportCSV = () => {
    const headers = ['Complaint ID', 'Title', 'Category', 'Severity', 'Status', 'Victim', 'Loss', 'Reported Date'];
    const rows = filtered.map((i) => [
      i.complaint_id,
      `"${i.title.replace(/"/g, '""')}"`,
      i.category,
      i.severity,
      i.status,
      `"${i.civilian_name}"`,
      i.financial_loss || 0,
      i.incident_date,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sentinel_incidents_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">Master Incident Registry</h1>
          <p className="text-xs text-slate-500 mt-1">
            Global repository of all reported cybercrimes across all classifications and operational tenants.
          </p>
        </div>
        <Button variant="outline" onClick={exportCSV} leftIcon={<Download className="w-4 h-4 text-slate-600" />}>
          Export Incident CSV
        </Button>
      </div>

      <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search all incidents..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none"
        >
          <option value="all">All Lifecycle Statuses</option>
          <option value="submitted">Submitted</option>
          <option value="under_review">Under Review</option>
          <option value="assigned">Assigned</option>
          <option value="investigation_in_progress">Investigation in Progress</option>
          <option value="resolved">Resolved</option>
          <option value="closed">Closed</option>
        </select>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-bold text-[10px]">
                <th className="py-3.5 px-4">Complaint ID</th>
                <th className="py-3.5 px-4">Incident Title</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Severity</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Complainant</th>
                <th className="py-3.5 px-4">Financial Loss</th>
                <th className="py-3.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((inc) => (
                <tr key={inc.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-blue-700">{inc.complaint_id}</td>
                  <td className="py-3.5 px-4 font-bold text-slate-900 max-w-xs truncate">{inc.title}</td>
                  <td className="py-3.5 px-4 capitalize text-slate-600">{inc.category.replace(/_/g, ' ')}</td>
                  <td className="py-3.5 px-4">
                    <Badge severity={inc.severity} size="sm" />
                  </td>
                  <td className="py-3.5 px-4">
                    <Badge status={inc.status} size="sm" />
                  </td>
                  <td className="py-3.5 px-4 text-slate-700 font-medium">{inc.civilian_name}</td>
                  <td className="py-3.5 px-4 font-semibold text-slate-900">
                    {inc.financial_loss ? `$${inc.financial_loss.toLocaleString()}` : '$0'}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <Link to={`/investigator/incidents/${inc.id}`}>
                      <Button variant="outline" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
                        Examine
                      </Button>
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
