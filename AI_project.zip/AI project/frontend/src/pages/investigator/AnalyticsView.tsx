import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Clock,
  ShieldCheck,
  Calendar,
  Layers,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';

const CATEGORY_STATS = [
  { category: 'Financial Fraud', count: 12, fill: '#2563EB' },
  { category: 'Phishing', count: 18, fill: '#0D9488' },
  { category: 'Account Hacking', count: 9, fill: '#F59E0B' },
  { category: 'Malware / Ransom', count: 4, fill: '#DC2626' },
  { category: 'Impersonation', count: 7, fill: '#8B5CF6' },
  { category: 'Data Breach', count: 3, fill: '#EC4899' },
];

const RESOLUTION_TIME_DATA = [
  { month: 'Jun', avgHours: 36 },
  { month: 'Jul', avgHours: 28 },
  { month: 'Aug', avgHours: 22 },
  { month: 'Sep', avgHours: 19 },
  { month: 'Oct', avgHours: 15 },
  { month: 'Nov', avgHours: 11 },
];

const WORKLOAD_DATA = [
  { name: 'Marcus Vance', active: 4, resolved: 14 },
  { name: 'Elena Rostova', active: 3, resolved: 22 },
  { name: 'David Sterling', active: 1, resolved: 8 },
  { name: 'Triage Pool', active: 5, resolved: 0 },
];

export const AnalyticsView: React.FC = () => {
  const [timeRange, setTimeRange] = useState('30d');

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
            Forensic & Incident Analytics
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Quantitative metrics on incident intake, Mean Time to Containment (MTTC), and investigator workloads.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-white p-1 rounded-xl border border-slate-200">
          {[
            { id: '7d', label: '7 Days' },
            { id: '30d', label: '30 Days' },
            { id: '90d', label: '90 Days' },
            { id: 'ytd', label: 'YTD' },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setTimeRange(t.id)}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                timeRange === t.id ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Top Level Benchmark Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-sm space-y-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Mean Time to Triage</p>
          <div className="text-3xl font-extrabold text-blue-600">42 min</div>
          <p className="text-[11px] text-emerald-600 font-semibold">&darr; 18% improvement</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-sm space-y-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Mean Time to Resolution</p>
          <div className="text-3xl font-extrabold text-teal-600">11.4 hrs</div>
          <p className="text-[11px] text-emerald-600 font-semibold">&darr; 24% faster closing</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-sm space-y-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Evidence Integrity Rate</p>
          <div className="text-3xl font-extrabold text-slate-900">100%</div>
          <p className="text-[11px] text-slate-500">SHA-256 zero discrepancies</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-sm space-y-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Civilian CSAT Rating</p>
          <div className="text-3xl font-extrabold text-emerald-600">98.2%</div>
          <p className="text-[11px] text-slate-500">Post-resolution feedback</p>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Incident Volume by Category */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
          <h2 className="text-base font-bold text-slate-900">Incidents by Crime Classification</h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={CATEGORY_STATS} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="category" stroke="#94A3B8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: '8px',
                    border: '1px solid #E2E8F0',
                    fontSize: '11px',
                  }}
                />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {CATEGORY_STATS.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Resolution Time Over Time (MTTR Reduction) */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
          <h2 className="text-base font-bold text-slate-900">Resolution Speed Trend (Hours)</h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={RESOLUTION_TIME_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="month" stroke="#94A3B8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: '8px',
                    border: '1px solid #E2E8F0',
                    fontSize: '11px',
                  }}
                />
                <Line type="monotone" dataKey="avgHours" stroke="#0D9488" strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
