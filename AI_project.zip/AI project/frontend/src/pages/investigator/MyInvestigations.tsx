import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Briefcase,
  Search,
  Clock,
  ArrowRight,
  ShieldCheck,
  FileCheck,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { api } from '../../services/api';
import { Incident } from '../../types';

export const MyInvestigations: React.FC = () => {
  const { user } = useAuth();
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      const all = await api.getIncidents();
      // Filter for current investigator or demo fallback
      const mine = all.filter(
        (i) => i.assigned_investigator_name?.includes(user?.full_name || 'Marcus Vance') || i.assigned_investigator_id === user?.id
      );
      setIncidents(mine.length > 0 ? mine : all.slice(0, 2));
    };
    load();
  }, [user]);

  const filtered = incidents.filter(
    (i) =>
      i.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      i.complaint_id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">My Active Caseload</h1>
          <p className="text-xs text-slate-500 mt-1">
            Incidents assigned to you for digital forensics, victim communication, and resolution.
          </p>
        </div>
      </div>

      {/* Search Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-sm flex items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search my cases..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>
        <div className="text-xs text-slate-500 font-medium">
          Showing <strong>{filtered.length}</strong> active investigations
        </div>
      </div>

      {/* Grid of Assigned Cases */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filtered.map((inc) => (
          <div
            key={inc.id}
            className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  {inc.complaint_id}
                </span>
                <div className="flex items-center gap-2">
                  <Badge severity={inc.severity} size="sm" />
                  <Badge status={inc.status} size="sm" />
                </div>
              </div>

              <h3 className="text-base font-bold text-slate-900 line-clamp-1">{inc.title}</h3>
              <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{inc.description}</p>
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-3">
              <div className="grid grid-cols-2 gap-2 text-xs text-slate-500">
                <div>
                  <span className="text-slate-400">Victim:</span>
                  <p className="font-semibold text-slate-800">{inc.civilian_name}</p>
                </div>
                <div>
                  <span className="text-slate-400">Evidence:</span>
                  <p className="font-semibold text-slate-800">{inc.evidence_count || 0} file(s)</p>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <Link to={`/investigator/incidents/${inc.id}`} className="flex-1">
                  <Button variant="primary" size="sm" className="w-full" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
                    Open Forensic Workspace
                  </Button>
                </Link>
                <Link to="/investigator/messages">
                  <Button variant="outline" size="sm" leftIcon={<MessageSquare className="w-3.5 h-3.5 text-blue-600" />}>
                    Chat
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
