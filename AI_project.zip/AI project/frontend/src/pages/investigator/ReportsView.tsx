import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Calendar,
  CheckCircle2,
  FileText,
  Printer,
  ShieldCheck,
} from 'lucide-react';
import { Button } from '../../components/common/Button';

export const ReportsView: React.FC = () => {
  const [reportType, setReportType] = useState('executive_summary');
  const [format, setFormat] = useState('pdf');
  const [generating, setGenerating] = useState(false);
  const [downloadReady, setDownloadReady] = useState(false);

  const handleGenerate = () => {
    setGenerating(true);
    setDownloadReady(false);
    setTimeout(() => {
      setGenerating(false);
      setDownloadReady(true);
    }, 1200);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
          Forensic & Compliance Report Generator
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Export cryptographically verifiable incident summaries, chain of custody logs, and SOC metrics.
        </p>
      </div>

      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-sm space-y-6">
        <div className="space-y-4">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-400">
            Select Report Template
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              {
                id: 'executive_summary',
                title: 'Executive SOC Brief',
                desc: 'High-level metrics on caseload, MTTR, critical incidents, and threat categories.',
              },
              {
                id: 'evidence_custody',
                title: 'Evidence Chain of Custody',
                desc: 'Forensic listing of all SHA-256 hashes, upload origins, and verification timestamps.',
              },
              {
                id: 'case_disposition',
                title: 'Incident Disposition Dossier',
                desc: 'Detailed breakdown of resolved cases, containment steps, and referral packages.',
              },
            ].map((tmpl) => (
              <div
                key={tmpl.id}
                onClick={() => setReportType(tmpl.id)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  reportType === tmpl.id
                    ? 'border-blue-600 bg-blue-50/70 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900">{tmpl.title}</h4>
                  {reportType === tmpl.id && <CheckCircle2 className="w-4 h-4 text-blue-600" />}
                </div>
                <p className="text-[11px] text-slate-500 mt-1 leading-snug">{tmpl.desc}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Time Horizon</label>
            <select className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white text-slate-800 focus:outline-none">
              <option>Current Calendar Month (November 2026)</option>
              <option>Previous Quarter (Q3 2026)</option>
              <option>Year to Date (2026)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Output Format</label>
            <div className="flex items-center gap-3 pt-1">
              <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                <input
                  type="radio"
                  name="fmt"
                  checked={format === 'pdf'}
                  onChange={() => setFormat('pdf')}
                  className="text-blue-600"
                />
                <span>Encrypted PDF (.pdf)</span>
              </label>
              <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                <input
                  type="radio"
                  name="fmt"
                  checked={format === 'csv'}
                  onChange={() => setFormat('csv')}
                  className="text-blue-600"
                />
                <span>Raw Data (.csv)</span>
              </label>
            </div>
          </div>
        </div>

        <div className="pt-4 flex items-center justify-between border-t border-slate-100">
          <Button variant="primary" onClick={handleGenerate} isLoading={generating} leftIcon={<FileText className="w-4 h-4" />}>
            Compile Report
          </Button>

          {downloadReady && (
            <Button
              variant="outline"
              className="bg-emerald-50 text-emerald-800 border-emerald-200"
              leftIcon={<Download className="w-4 h-4 text-emerald-600" />}
              onClick={() => alert('Report download initiated.')}
            >
              Download {format.toUpperCase()} Package
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};
