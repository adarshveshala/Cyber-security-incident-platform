import React from 'react';
import { Link } from 'react-router-dom';
import {
  ShieldAlert,
  ShieldCheck,
  Search,
  Lock,
  ArrowRight,
  Sparkles,
  Activity,
  CheckCircle2,
  Users,
  Database,
  Fingerprint,
  Cpu,
  UserCheck,
  ExternalLink,
  ChevronRight,
  FileCheck,
  Shield,
  Layers,
  KeyRound
} from 'lucide-react';
import { Button } from '../../components/common/Button';

export const LandingPage: React.FC = () => {
  return (
    <div className="bg-[#F7FAFC] overflow-hidden">
      {/* 1. HERO SECTION - Spacious, Light, Impactful with Cyber Grid */}
      <section className="relative pt-16 pb-24 lg:pt-24 lg:pb-32 border-b border-slate-200 bg-cyber-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            {/* Left: Punchy Headlines & Primary CTAs */}
            <div className="lg:col-span-7 space-y-8">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/80 border border-blue-200 text-blue-700 text-xs font-bold">
                <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
                Next-Gen Incident Response Ecosystem
              </div>

              <div className="space-y-3">
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-[#172554] tracking-tight leading-[1.1]">
                  Report Cybercrime. <br />
                  <span className="text-blue-600">Empower Investigators.</span> <br />
                  Neutralize Threats.
                </h1>
                <p className="text-base sm:text-lg text-[#475569] max-w-xl leading-relaxed pt-2">
                  Sentinel Grid connects civilian cybercrime victims with certified digital forensic investigators and SOC teams through real-time telemetry, tamper-evident evidence, and AI copilots.
                </p>
              </div>

              {/* Action Buttons: Prominent Dual Access */}
              <div className="pt-2 flex flex-wrap items-center gap-4">
                <Link to="/civilian/report">
                  <Button size="lg" variant="primary" leftIcon={<ShieldAlert className="w-5 h-5" />}>
                    Report a Cybercrime
                  </Button>
                </Link>
                <Link to="/civilian/login">
                  <Button size="lg" variant="secondary" leftIcon={<UserCheck className="w-5 h-5 text-blue-600" />}>
                    Civilian Portal
                  </Button>
                </Link>
                <Link to="/investigator/login">
                  <Button size="lg" variant="outline" leftIcon={<Lock className="w-5 h-5 text-slate-500" />}>
                    Investigator SOC
                  </Button>
                </Link>
              </div>

              {/* Trust Metrics */}
              <div className="pt-6 grid grid-cols-3 gap-6 border-t border-slate-200">
                <div>
                  <div className="text-2xl font-black text-[#172554]">SHA-256</div>
                  <div className="text-xs text-slate-500 font-medium">Chain of Custody</div>
                </div>
                <div>
                  <div className="text-2xl font-black text-blue-600">Dual-Role</div>
                  <div className="text-xs text-slate-500 font-medium">Civilian & SOC Portals</div>
                </div>
                <div>
                  <div className="text-2xl font-black text-teal-600">MITRE AI</div>
                  <div className="text-xs text-slate-500 font-medium">ATT&CK Mapping</div>
                </div>
              </div>
            </div>

            {/* Right: Visual Incident Card with Photo Accent */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto w-full max-w-md">
                {/* Visual Image Backdrop Card */}
                <div className="relative rounded-3xl overflow-hidden border border-slate-200 shadow-2xl bg-white">
                  <div className="relative h-48 w-full overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800"
                      alt="Cybersecurity Operations"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-white via-white/40 to-transparent"></div>
                    <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-white/90 backdrop-blur-md border border-slate-200 text-xs font-bold text-blue-700 flex items-center gap-1.5 shadow-sm">
                      <Activity className="w-3.5 h-3.5 text-blue-600" />
                      Live Incident Telemetry
                    </div>
                  </div>

                  {/* Incident Snapshot */}
                  <div className="p-6 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                      <div>
                        <div className="text-xs font-mono font-bold text-slate-900">CASE #SG-2026-8921</div>
                        <div className="text-sm font-bold text-[#172554]">Executive Phishing & Wire Fraud</div>
                      </div>
                      <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                        Active Triage
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-slate-400 block text-[10px] font-bold uppercase">Reported Loss</span>
                        <span className="font-bold text-slate-900">$34,500.00</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-slate-400 block text-[10px] font-bold uppercase">Evidence Status</span>
                        <span className="font-bold text-teal-600">Verified SHA-256</span>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-teal-50/70 border border-teal-200/60 flex items-center gap-3">
                      <Sparkles className="w-4 h-4 text-teal-600 shrink-0" />
                      <div className="text-xs text-teal-900">
                        <strong className="font-bold">AI Copilot Finding:</strong> Fast-flux infrastructure mapped to MITRE T1566.002.
                      </div>
                    </div>

                    <div className="pt-1 flex items-center justify-between text-xs">
                      <span className="text-slate-500 font-medium">Assigned: Spec. Agent M. Vance</span>
                      <Link to="/investigator/login" className="text-blue-600 font-bold hover:underline flex items-center gap-1">
                        Open Case &rarr;
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. DUAL-PORTAL GATEWAY - Direct Choice between Civilian & Investigator */}
      <section className="py-20 lg:py-28 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-blue-600">Dual Dedicated Workspaces</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#172554] tracking-tight">
            Choose Your Access Portal
          </h2>
          <p className="text-slate-500 text-sm">
            Tailored experiences designed specifically for citizen reporting and authorized forensic operations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {/* PORTAL CARD 1: CIVILIAN */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-md hover:shadow-xl transition-all overflow-hidden flex flex-col justify-between group">
            <div className="relative h-60 w-full overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=900"
                alt="Civilian Protection"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-white via-white/30 to-transparent"></div>
              <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-md">
                <UserCheck className="w-3.5 h-3.5" />
                Civilian Portal
              </div>
            </div>

            <div className="p-8 space-y-6 flex-1 flex flex-col justify-between">
              <div className="space-y-3">
                <h3 className="text-2xl font-bold text-slate-900">
                  Citizen Incident Reporting & Tracking
                </h3>
                <p className="text-sm text-slate-500 leading-relaxed">
                  Submit cybercrime complaints in minutes with cryptographic evidence preservation and transparent real-time status updates.
                </p>

                <div className="grid grid-cols-2 gap-3 pt-2 text-xs font-medium text-slate-600">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    5-Step Guided Intake
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    Evidence Vault
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    Investigator Messaging
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    AI Safety Assistant
                  </div>
                </div>
              </div>

              <div className="pt-4 flex items-center gap-3 border-t border-slate-100">
                <Link to="/civilian/login" className="flex-1">
                  <Button variant="primary" size="lg" className="w-full">
                    Civilian Sign In
                  </Button>
                </Link>
                <Link to="/civilian/register" className="flex-1">
                  <Button variant="outline" size="lg" className="w-full">
                    Create Account
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* PORTAL CARD 2: INVESTIGATOR */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-md hover:shadow-xl transition-all overflow-hidden flex flex-col justify-between group">
            <div className="relative h-60 w-full overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=900"
                alt="Investigator SOC Command"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-white via-white/30 to-transparent"></div>
              <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-slate-900 text-white text-xs font-bold flex items-center gap-1.5 shadow-md">
                <ShieldAlert className="w-3.5 h-3.5 text-blue-400" />
                Investigator SOC
              </div>
            </div>

            <div className="p-8 space-y-6 flex-1 flex flex-col justify-between">
              <div className="space-y-3">
                <h3 className="text-2xl font-bold text-slate-900">
                  SOC Command & Digital Forensics
                </h3>
                <p className="text-sm text-slate-500 leading-relaxed">
                  Authorized workspace for sworn detectives and SOC analysts to triage cases, analyze indicators, and deploy response actions.
                </p>

                <div className="grid grid-cols-2 gap-3 pt-2 text-xs font-medium text-slate-600">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    Live Incident Triage
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    MITRE ATT&CK Copilot
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    Threat Intel Hub (IOCs)
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    Immutable Audit Trail
                  </div>
                </div>
              </div>

              <div className="pt-4 flex items-center gap-3 border-t border-slate-100">
                <Link to="/investigator/login" className="w-full">
                  <Button variant="primary" size="lg" className="w-full bg-slate-900 hover:bg-slate-800 text-white">
                    Investigator SOC Login &rarr;
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. HOW IT WORKS - Visual 3-Step Process with Images */}
      <section id="how-it-works" className="py-20 lg:py-28 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-blue-600">Operational Pipeline</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#172554] tracking-tight">
              From Report to Threat Neutralization
            </h2>
            <p className="text-slate-500 text-sm">
              An end-to-end synchronized workflow ensuring speed, evidence integrity, and resolution.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="rounded-2xl border border-slate-200 overflow-hidden bg-[#F7FAFC] flex flex-col justify-between hover:shadow-md transition-all">
              <div className="h-44 overflow-hidden relative">
                <img
                  src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=600"
                  alt="Incident Intake"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 w-8 h-8 rounded-lg bg-blue-600 text-white font-extrabold flex items-center justify-center text-sm shadow">
                  01
                </div>
              </div>
              <div className="p-6 space-y-2">
                <h4 className="text-lg font-bold text-slate-900">Guided Intake & Hashing</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Complainants submit details with automatic SHA-256 evidence hashing for strict legal custody.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="rounded-2xl border border-slate-200 overflow-hidden bg-[#F7FAFC] flex flex-col justify-between hover:shadow-md transition-all">
              <div className="h-44 overflow-hidden relative">
                <img
                  src="https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80&w=600"
                  alt="AI Threat Triage"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 w-8 h-8 rounded-lg bg-teal-600 text-white font-extrabold flex items-center justify-center text-sm shadow">
                  02
                </div>
              </div>
              <div className="p-6 space-y-2">
                <h4 className="text-lg font-bold text-slate-900">AI Triage & Intel Lookup</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Automated correlation of suspect IPs, domains, and hashes against global threat intelligence feeds.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="rounded-2xl border border-slate-200 overflow-hidden bg-[#F7FAFC] flex flex-col justify-between hover:shadow-md transition-all">
              <div className="h-44 overflow-hidden relative">
                <img
                  src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&q=80&w=600"
                  alt="Forensic Investigation"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 w-8 h-8 rounded-lg bg-slate-900 text-white font-extrabold flex items-center justify-center text-sm shadow">
                  03
                </div>
              </div>
              <div className="p-6 space-y-2">
                <h4 className="text-lg font-bold text-slate-900">Investigation & Resolution</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Assigned detectives collaborate with complainants, apply MITRE playbooks, and log audit actions.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. CYBER SAFETY CENTER - Visual Learning Cards */}
      <section id="safety-center" className="py-20 lg:py-28 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-4">
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-blue-600">Citizen Education</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#172554] tracking-tight">
              Cyber Safety & Threat Awareness
            </h2>
            <p className="text-slate-500 text-sm max-w-lg">
              Essential defense guides to protect your banking, personal identity, and devices.
            </p>
          </div>
          <Link to="/civilian/safety-center">
            <Button variant="outline" rightIcon={<ArrowRight className="w-4 h-4" />}>
              Open Safety Center
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              title: 'Phishing & Spoofing',
              desc: 'Spot fake domain alerts, spoofed banking links, and social engineering.',
              image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=400',
              tag: 'High Risk'
            },
            {
              title: 'UPI & Payment Fraud',
              desc: 'Never enter your PIN to receive money; identify bogus QR code payment traps.',
              image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=400',
              tag: 'Financial'
            },
            {
              title: 'Identity Theft',
              desc: 'Guard your government IDs, prevent unauthorized SIM swaps and credential leaks.',
              image: 'https://images.unsplash.com/photo-1614064641938-3bbee52942c7?auto=format&fit=crop&q=80&w=400',
              tag: 'Privacy'
            },
            {
              title: 'Evidence Preservation',
              desc: 'Learn how to export unedited headers, chat transcripts, and payment receipts.',
              image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80&w=400',
              tag: 'Forensics'
            }
          ].map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div className="h-36 overflow-hidden relative">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded text-[10px] font-bold bg-white/90 text-slate-800 backdrop-blur-sm border border-slate-200">
                  {item.tag}
                </div>
              </div>
              <div className="p-5 space-y-2 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm mb-1">{item.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
                </div>
                <Link
                  to="/civilian/safety-center"
                  className="pt-3 text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center justify-between border-t border-slate-100"
                >
                  <span>Read Guide</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 pb-8 border-b border-slate-800">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-white font-extrabold text-base">
                <ShieldAlert className="w-5 h-5 text-blue-400" />
                <span>SENTINEL GRID</span>
              </div>
              <p className="text-slate-400 leading-relaxed text-xs">
                AI-assisted cybersecurity incident reporting, investigation, and intelligence platform.
              </p>
              <div className="text-[11px] text-slate-500">
                &copy; {new Date().getFullYear()} Sentinel Grid. All rights reserved.
              </div>
            </div>

            <div>
              <h5 className="text-white font-bold mb-3 uppercase tracking-wider text-[11px]">Civilian Portal</h5>
              <ul className="space-y-2">
                <li><Link to="/civilian/login" className="hover:text-white transition-colors">Civilian Sign In</Link></li>
                <li><Link to="/civilian/register" className="hover:text-white transition-colors">Register Account</Link></li>
                <li><Link to="/civilian/report" className="hover:text-white transition-colors">Report Cybercrime</Link></li>
                <li><Link to="/civilian/safety-center" className="hover:text-white transition-colors">Cyber Safety Center</Link></li>
              </ul>
            </div>

            <div>
              <h5 className="text-white font-bold mb-3 uppercase tracking-wider text-[11px]">Investigator SOC</h5>
              <ul className="space-y-2">
                <li><Link to="/investigator/login" className="hover:text-white transition-colors">Investigator Sign In</Link></li>
                <li><Link to="/investigator/soc" className="hover:text-white transition-colors">SOC Command Center</Link></li>
                <li><Link to="/investigator/threat-intel" className="hover:text-white transition-colors">Threat Intelligence</Link></li>
                <li><Link to="/investigator/evidence" className="hover:text-white transition-colors">Evidence Vault</Link></li>
              </ul>
            </div>

            <div className="space-y-2">
              <h5 className="text-white font-bold mb-3 uppercase tracking-wider text-[11px]">Notice & Ethics</h5>
              <p className="text-slate-500 text-[11px] leading-relaxed">
                Sentinel Grid facilitates structured cybercrime triage and evidence management between complainants and authorized forensic personnel. For emergencies, contact local law enforcement authorities.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
