import React, { useState } from 'react';
import { Bell, Lock, Eye, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Button } from '../../components/common/Button';

export const CivilianSettings: React.FC = () => {
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [smsAlerts, setSmsAlerts] = useState(false);
  const [twoFactor, setTwoFactor] = useState(true);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">Security & Notification Settings</h1>
        <p className="text-xs text-slate-500 mt-1">
          Configure real-time dispatch alerts, session security, and account preferences.
        </p>
      </div>

      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-sm space-y-6">
        {saved && (
          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Preferences saved successfully.</span>
          </div>
        )}

        <div className="space-y-4">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-slate-400">
            Notification Dispatches
          </h2>

          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200/80">
            <div>
              <p className="text-xs font-bold text-slate-800">Email Status Alerts</p>
              <p className="text-[11px] text-slate-500">Receive email notices when an investigator updates your complaint.</p>
            </div>
            <input
              type="checkbox"
              checked={emailAlerts}
              onChange={(e) => setEmailAlerts(e.target.checked)}
              className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
            />
          </div>

          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200/80">
            <div>
              <p className="text-xs font-bold text-slate-800">Urgent SMS Alerts</p>
              <p className="text-[11px] text-slate-500">Receive an SMS when an investigator sends an urgent evidence request.</p>
            </div>
            <input
              type="checkbox"
              checked={smsAlerts}
              onChange={(e) => setSmsAlerts(e.target.checked)}
              className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
            />
          </div>
        </div>

        <div className="space-y-4 pt-4 border-t border-slate-100">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-slate-400">
            Authentication Security
          </h2>

          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200/80">
            <div>
              <p className="text-xs font-bold text-slate-800">Two-Factor Authentication (2FA)</p>
              <p className="text-[11px] text-slate-500">Protect your civilian account with an authenticator app (TOTP).</p>
            </div>
            <input
              type="checkbox"
              checked={twoFactor}
              onChange={(e) => setTwoFactor(e.target.checked)}
              className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
            />
          </div>
        </div>

        <div className="pt-4 flex justify-end">
          <Button variant="primary" onClick={handleSave}>
            Save Preferences
          </Button>
        </div>
      </div>
    </div>
  );
};
