import React from 'react';
import { Link } from 'react-router-dom';
import { Bell, CheckCheck, ExternalLink, ShieldAlert, MessageSquare, AlertCircle, Clock } from 'lucide-react';
import { useSocket } from '../../context/SocketContext';
import { Button } from '../../components/common/Button';

export const CivilianNotifications: React.FC = () => {
  const { notifications, markNotificationAsRead, markAllNotificationsAsRead, unreadNotificationCount } = useSocket();

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">Notification Center</h1>
          <p className="text-xs text-slate-500 mt-1">
            Real-time alerts regarding status updates, investigator messages, and evidence requests.
          </p>
        </div>
        {unreadNotificationCount > 0 && (
          <Button variant="outline" size="sm" onClick={markAllNotificationsAsRead} leftIcon={<CheckCheck className="w-4 h-4 text-blue-600" />}>
            Mark All as Read
          </Button>
        )}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden divide-y divide-slate-100">
        {notifications.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            You have no notifications at this time.
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => markNotificationAsRead(n.id)}
              className={`p-5 transition-colors cursor-pointer flex items-start justify-between gap-4 ${
                !n.is_read ? 'bg-blue-50/40 hover:bg-blue-50/70' : 'hover:bg-slate-50'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-xl shrink-0 ${
                  n.type === 'incident_status' ? 'bg-blue-100 text-blue-700' :
                  n.type === 'new_message' ? 'bg-purple-100 text-purple-700' :
                  'bg-amber-100 text-amber-700'
                }`}>
                  {n.type === 'incident_status' ? <ShieldAlert className="w-5 h-5" /> :
                   n.type === 'new_message' ? <MessageSquare className="w-5 h-5" /> :
                   <AlertCircle className="w-5 h-5" />}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className={`text-sm font-bold ${!n.is_read ? 'text-slate-900' : 'text-slate-700'}`}>
                      {n.title}
                    </h3>
                    {!n.is_read && (
                      <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                    )}
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed max-w-2xl">{n.message}</p>
                  <p className="text-[10px] text-slate-400">
                    {new Date(n.created_at).toLocaleDateString()} at {new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>

              {n.link_url && (
                <Link to={n.link_url} className="shrink-0">
                  <Button variant="ghost" size="sm" rightIcon={<ExternalLink className="w-3.5 h-3.5" />}>
                    View
                  </Button>
                </Link>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
