import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  FileText,
  Search,
  Filter,
  Plus,
  ArrowRight,
  ShieldCheck,
  Clock,
  User,
  Calendar,
  DollarSign,
  ChevronRight,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { api } from '../../services/api';
import { Incident, IncidentStatus, IncidentCategory } from '../../types';
import { getDefaultAvatar } from '../../utils/avatars';

export const MyComplaints: React.FC = () => {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      try {
        if (!user?.id) {
          setIncidents([]);
          return;
        }
        const data = await api.getIncidents({ civilianId: user.id });
        setIncidents(data);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user]);

  const filteredIncidents = incidents.filter((inc) => {
    const matchesSearch =
      inc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.complaint_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || inc.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || inc.category === categoryFilter;
    return matchesSearch && matchesStatus && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">My Complaints Registry</h1>
          <p className="text-xs text-slate-500 mt-1">
            Track case progress, assigned forensic investigators, and official audit milestones.
          </p>
        </div>
        <Link to="/civilian/report">
          <Button variant="primary" leftIcon={<Plus className="w-4 h-4" />}>
            Report New Incident
          </Button>
        </Link>
      </div>

      {/* Filters & Search Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by ID, keyword, suspect..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Statuses</option>
            <option value="submitted">Submitted</option>
            <option value="under_review">Under Review</option>
            <option value="assigned">Assigned</option>
            <option value="investigation_in_progress">Investigation in Progress</option>
            <option value="additional_info_required">Additional Info Required</option>
            <option value="resolved">Resolved</option>
            <option value="closed">Closed</option>
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Categories</option>
            <option value="financial_fraud">Financial Fraud</option>
            <option value="phishing">Phishing</option>
            <option value="identity_theft">Identity Theft</option>
            <option value="account_hacking">Account Hacking</option>
            <option value="malware">Malware / Ransomware</option>
            <option value="impersonation">Impersonation</option>
            <option value="cyberbullying">Cyberbullying</option>
            <option value="social_media_fraud">Social Media Fraud</option>
            <option value="data_breach">Data Breach</option>
          </select>
        </div>
      </div>

      {/* Complaints List / Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
        {filteredIncidents.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <FileText className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-semibold text-slate-700">No complaints match your criteria</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Try adjusting your search query or status filter, or submit a new cybercrime report.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredIncidents.map((incident) => (
              <div
                key={incident.id}
                onClick={() => navigate(`/civilian/complaints/${incident.id}`)}
                className="p-6 hover:bg-slate-50/80 cursor-pointer transition-colors space-y-3 group"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200/60">
                      {incident.complaint_id}
                    </span>
                    <span className="text-xs text-slate-400">•</span>
                    <span className="text-xs font-semibold text-slate-600 capitalize">
                      {incident.category.replace(/_/g, ' ')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge severity={incident.severity} />
                    <Badge status={incident.status} />
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="space-y-1 max-w-3xl">
                    <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                      {incident.title}
                    </h3>
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {incident.description}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    {incident.financial_loss ? (
                      <div className="text-xs font-bold text-red-600 flex items-center gap-1 sm:justify-end">
                        <DollarSign className="w-3.5 h-3.5" />
                        ${incident.financial_loss.toLocaleString()} loss
                      </div>
                    ) : (
                      <div className="text-xs text-slate-400 sm:justify-end">No direct monetary loss</div>
                    )}
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-500 gap-3">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      Reported: {new Date(incident.created_at).toLocaleDateString()}
                    </span>
                    {incident.assigned_investigator_name ? (
                      <span className="flex items-center gap-2 font-semibold text-slate-800">
                        <img
                          src={getDefaultAvatar('male', 'investigator')}
                          alt="Investigator"
                          className="w-5 h-5 rounded-md object-cover border border-slate-200"
                        />
                        {incident.assigned_investigator_name}
                      </span>
                    ) : (
                      <span className="text-slate-400 font-medium">Pending Triage Assignment</span>
                    )}
                  </div>
                  <span className="text-xs font-bold text-blue-600 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                    Open Timeline & Evidence &rarr;
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
