import React, { useState } from 'react';
import {
  BookOpen,
  ShieldCheck,
  CreditCard,
  KeyRound,
  Users,
  Smartphone,
  ShoppingBag,
  FileText,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Card } from '../../components/common/Card';

export const CyberSafetyCenter: React.FC = () => {
  const [expandedTopic, setExpandedTopic] = useState<string | null>('phishing');

  const topics = [
    {
      id: 'phishing',
      icon: AlertTriangle,
      color: 'text-red-600 bg-red-50 border-red-200',
      title: 'Phishing & Email Spoofing Defense',
      tagline: 'Recognize deceptive links, forged domains, and urgent payment requests.',
      content: {
        summary:
          'Phishing remains the #1 initial access vector. Adversaries mimic trusted organizations (banks, tax authorities, IT departments) to compel victims into entering credentials or authorizing funds.',
        redFlags: [
          'High urgency claiming immediate account suspension or legal action.',
          'Mismatched sender address (e.g., display name says "Chase Bank" but address is info@chase-support-91.net).',
          'Generic greetings ("Dear Customer") instead of your registered name.',
          'Links redirecting to unfamiliar domain extensions (.top, .xyz, .cc).',
        ],
        defenseActions: [
          'Never click password reset or security verification links sent via unsolicited email.',
          'Navigate independently to the service website via bookmarks or official apps.',
          'Inspect email headers: look for SPF: FAIL or DKIM: FAIL flags.',
        ],
      },
    },
    {
      id: 'upi_payment',
      icon: CreditCard,
      color: 'text-amber-600 bg-amber-50 border-amber-200',
      title: 'UPI & Instant Payment Fraud Prevention',
      tagline: 'Protect digital wallets, QR code scams, and unauthorized debit collect requests.',
      content: {
        summary:
          'Instant payment networks (UPI, Zelle, Venmo, Wire) settle immediately. Scammers exploit the speed of these networks through fake payment approvals and deceptive QR codes.',
        redFlags: [
          'Golden Rule: You NEVER need to enter your PIN or password to RECEIVE money.',
          'Scammer sends a QR code claiming "Scan this QR code to receive your refund". Scanning always debits your account.',
          'Caller requests installation of remote desktop apps (AnyDesk, TeamViewer) to "troubleshoot failed payment".',
        ],
        defenseActions: [
          'Refuse payment collect requests from unknown numbers or IDs.',
          'Set daily transaction velocity limits in your mobile banking app.',
          'If funds were diverted, call your bank within 2 hours to initiate a golden-hour SWIFT recall.',
        ],
      },
    },
    {
      id: 'password_security',
      icon: KeyRound,
      color: 'text-blue-600 bg-blue-50 border-blue-200',
      title: 'Password & Passkey Architecture',
      tagline: 'Eliminate password reuse and transition to hardware-backed multi-factor authentication.',
      content: {
        summary:
          'Over 80% of data breaches involve stolen or reused credentials. Simple passwords can be cracked in seconds via automated rainbow tables and credential stuffing bots.',
        redFlags: [
          'Reusing the same password across personal email, banking, and social accounts.',
          'Using personal information (birthdays, child names, pet names) in passwords.',
          'Relying solely on SMS 2FA, which is susceptible to SIM-swapping attacks.',
        ],
        defenseActions: [
          'Use a dedicated password manager (Bitwarden, 1Password) to generate 18+ character passwords.',
          'Enable FIDO2 Passkeys or authenticator apps (Google Authenticator, YubiKey) instead of SMS.',
          'Check HaveIBeenPwned periodically to verify if your email appeared in public leaks.',
        ],
      },
    },
    {
      id: 'social_media',
      icon: Users,
      color: 'text-purple-600 bg-purple-50 border-purple-200',
      title: 'Social Media & Impersonation Safety',
      tagline: 'Safeguard your accounts against takeover, sextortion, and cloned profile schemes.',
      content: {
        summary:
          'Adversaries clone public profiles or compromise accounts to scam your friends, solicit cryptocurrency, or demand ransoms for personal photos.',
        redFlags: [
          'A friend sends an urgent DM asking you to vote for their brand ambassador contest or click a link.',
          'Someone asks you to receive a verification SMS and forward the code to them.',
          'Demands for gift cards or cryptocurrency under threat of publishing private media.',
        ],
        defenseActions: [
          'Never forward SMS login codes or screenshot 2FA recovery backup codes to anyone.',
          'Lock down privacy settings: hide your friend list and phone number from public view.',
          'Set up third-party authenticator 2FA on Instagram, LinkedIn, and Facebook.',
        ],
      },
    },
    {
      id: 'identity_theft',
      icon: Smartphone,
      color: 'text-teal-600 bg-teal-50 border-teal-200',
      title: 'Identity Theft & SIM Swap Defense',
      tagline: 'Prevent criminals from opening credit lines or hijacking your cellular phone number.',
      content: {
        summary:
          'SIM swapping occurs when an attacker bribes or deceives a mobile carrier representative into transferring your phone number to their SIM card, capturing your SMS 2FA codes.',
        redFlags: [
          'Sudden loss of cellular reception accompanied by "No Service" or "SIM Not Provisioned".',
          'Unexpected notifications regarding address changes or credit card applications.',
          'Unsolicited authentication push notifications from your email or bank.',
        ],
        defenseActions: [
          'Set a carrier account security PIN (Port-Out Freeze) with your mobile telecom provider.',
          'Freeze your credit files at major credit bureaus (Equifax, Experian, TransUnion).',
          'Remove your primary phone number from publicly searchable online directories.',
        ],
      },
    },
    {
      id: 'online_shopping',
      icon: ShoppingBag,
      color: 'text-emerald-600 bg-emerald-50 border-emerald-200',
      title: 'Online Shopping & Counterfeit Store Safety',
      tagline: 'Avoid fake retail storefronts, bogus tracking links, and credit card skimmers.',
      content: {
        summary:
          'During holiday seasons, thousands of fraudulent eCommerce websites pop up mimicking luxury brands or electronics retailers with 80% discount discounts.',
        redFlags: [
          'Prices that are unrealistically low compared to legitimate retail benchmarks.',
          'Only accepts irreversible payment methods: Zelle, Bitcoin, or wire transfer.',
          'No physical company address, return policy, or customer service contact number.',
        ],
        defenseActions: [
          'Always pay via credit card or virtual cards (Privacy.com, Apple Pay) which provide chargeback protections.',
          'Check the domain registration date on Whois: newly registered domains under 6 months old are high risk.',
          'Never download .exe or .apk files claiming to be "special store coupons".',
        ],
      },
    },
    {
      id: 'reporting_guide',
      icon: FileText,
      color: 'text-indigo-600 bg-indigo-50 border-indigo-200',
      title: 'How to Properly Report & Preserve Evidence',
      tagline: 'Collect legally sound digital evidence so forensic examiners can build a case.',
      content: {
        summary:
          'Proper digital evidence preservation can be the difference between recovering stolen funds and closing a case without resolution. Digital evidence is volatile and can be easily destroyed.',
        redFlags: [
          'Do NOT delete scam text messages, WhatsApp conversations, or call logs.',
          'Do NOT crop screenshots; investigators require timestamps, battery percentages, and status bars.',
          'Do NOT reboot an infected computer if ransomware is actively executing without taking a memory snapshot.',
        ],
        defenseActions: [
          'Export original RFC 822 email files (.eml or .msg) to retain full unadulterated IP headers.',
          'Download official bank statements as PDF rather than taking camera photos of screens.',
          'File a formal report on Sentinel Grid immediately to generate cryptographic SHA-256 evidence seals.',
        ],
      },
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
          Cyber Safety & Defense Hub
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Interactive educational modules and actionable protocols to protect your accounts, money, and identity.
        </p>
      </div>

      <div className="space-y-4">
        {topics.map((t) => {
          const Icon = t.icon;
          const isExpanded = expandedTopic === t.id;
          return (
            <div
              key={t.id}
              className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden transition-all"
            >
              <div
                onClick={() => setExpandedTopic(isExpanded ? null : t.id)}
                className="p-6 cursor-pointer hover:bg-slate-50/70 transition-colors flex items-start justify-between gap-4"
              >
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-2xl shrink-0 border ${t.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900">{t.title}</h3>
                    <p className="text-xs text-slate-500 mt-0.5">{t.tagline}</p>
                  </div>
                </div>
                <button className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </button>
              </div>

              {isExpanded && (
                <div className="px-6 pb-6 pt-2 border-t border-slate-100 space-y-4 text-xs">
                  <p className="text-slate-700 leading-relaxed font-normal">{t.content.summary}</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                    {/* Red Flags */}
                    <div className="p-4 rounded-xl bg-red-50/60 border border-red-200/80 space-y-2">
                      <h4 className="font-bold text-red-900 flex items-center gap-1.5 uppercase text-[10px] tracking-wider">
                        <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
                        Warning Signs & Red Flags:
                      </h4>
                      <ul className="space-y-1.5 text-red-800">
                        {t.content.redFlags.map((rf, i) => (
                          <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
                            <span>{rf}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Defensive Actions */}
                    <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200/80 space-y-2">
                      <h4 className="font-bold text-emerald-900 flex items-center gap-1.5 uppercase text-[10px] tracking-wider">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        Recommended Protective Actions:
                      </h4>
                      <ul className="space-y-1.5 text-emerald-800">
                        {t.content.defenseActions.map((da, i) => (
                          <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                            <span>{da}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
