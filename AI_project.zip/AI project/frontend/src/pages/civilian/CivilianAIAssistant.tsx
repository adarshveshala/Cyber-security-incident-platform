import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  ShieldCheck,
  HelpCircle,
  AlertTriangle,
  FileCheck,
  CheckCircle2,
  Lock,
  ArrowRight,
  ShieldAlert,
  Info,
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { AVATAR_PRESETS, getDefaultAvatar } from '../../utils/avatars';

export const CivilianAIAssistant: React.FC = () => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<
    { role: 'user' | 'assistant'; content: string; tips?: string[]; checklist?: string[] }[]
  >([
    {
      role: 'assistant',
      content:
        'Hello! I am your Sentinel Grid Civilian Security Assistant. I can help identify warning signs of scams, explain cybercrime categories, provide guidance on preserving evidence like email headers and SMS screenshots, or answer safety questions. How can I assist you today?',
      tips: [
        'Ask: "I received a strange text about a parcel fee with a link, is it a scam?"',
        'Ask: "How do I save email headers to prove someone spoofed an address?"',
        'Ask: "Someone hacked my Instagram account and changed my 2FA, what should I do?"',
      ],
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async (queryText?: string) => {
    const q = queryText || inputQuery;
    if (!q.trim()) return;

    const userMessage = { role: 'user' as const, content: q };
    setMessages((prev) => [...prev, userMessage]);
    if (!queryText) setInputQuery('');
    setIsLoading(true);

    try {
      const response = await api.getCivilianAIAdvice(q);
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: response.answer,
          tips: response.tips,
          checklist: response.safetyChecklist,
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-700 text-[11px] font-bold border border-teal-200 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            Civilian Cyber Defense AI
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">AI Security Advisor</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time defensive triage, scam detection guidance, and evidence preservation assistance.
          </p>
        </div>
      </div>

      {/* Non-Legal Disclaimer */}
      <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 flex items-start gap-2.5 text-xs text-amber-900">
        <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong>Notice:</strong> This assistant provides cybersecurity educational recommendations and forensic preservation guidance. It does not provide legal representation or official judicial declarations.
        </p>
      </div>

      {/* Chat Container */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden flex flex-col h-[580px]">
        {/* Chat Feed */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6 bg-slate-50/30">
          {messages.map((m, idx) => {
            const isUser = m.role === 'user';
            return (
              <div key={idx} className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}>
                {!isUser && (
                  <img
                    src={AVATAR_PRESETS[10].url}
                    alt="Copilot AI"
                    className="w-8 h-8 rounded-xl object-cover border border-teal-200 shadow-xs shrink-0"
                  />
                )}

                <div
                  className={`max-w-xl p-4 rounded-2xl text-xs leading-relaxed space-y-3 ${
                    isUser
                      ? 'bg-blue-600 text-white rounded-br-xs shadow-sm'
                      : 'bg-white text-slate-800 border border-slate-200 rounded-bl-xs shadow-xs'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{m.content}</p>

                  {/* Optional Actionable Tips */}
                  {m.tips && m.tips.length > 0 && (
                    <div className="pt-2 border-t border-slate-100 space-y-1.5">
                      <p className="font-bold text-slate-900 text-[11px] uppercase tracking-wider">
                        Actionable Recommendations:
                      </p>
                      <ul className="space-y-1">
                        {m.tips.map((t, i) => (
                          <li
                            key={i}
                            onClick={() => {
                              if (t.startsWith('Ask:')) {
                                const clean = t.replace('Ask: "', '').replace('"', '');
                                handleSend(clean);
                              }
                            }}
                            className={`flex items-start gap-1.5 ${
                              t.startsWith('Ask:')
                                ? 'text-teal-700 bg-teal-50 hover:bg-teal-100 cursor-pointer p-1.5 rounded transition-colors'
                                : 'text-slate-600'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                            <span>{t}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Safety Checklist */}
                  {m.checklist && m.checklist.length > 0 && (
                    <div className="pt-2 border-t border-slate-100 space-y-1.5">
                      <p className="font-bold text-slate-900 text-[11px] uppercase tracking-wider">
                        Safety Checklist:
                      </p>
                      <div className="grid grid-cols-1 gap-1">
                        {m.checklist.map((c, i) => (
                          <div key={i} className="flex items-center gap-2 p-1.5 rounded bg-slate-50 text-slate-700 text-[11px]">
                            <Lock className="w-3 h-3 text-blue-600 shrink-0" />
                            <span>{c}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {isUser && (
                  <img
                    src={user?.avatar_url || getDefaultAvatar(user?.gender, user?.role)}
                    alt={user?.full_name || 'Civilian'}
                    className="w-8 h-8 rounded-xl object-cover border border-slate-200 shadow-xs shrink-0"
                  />
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 items-center text-xs text-slate-400">
              <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center animate-pulse">
                <Sparkles className="w-4 h-4" />
              </div>
              <span>AI Advisor is analyzing scam patterns and best practices...</span>
            </div>
          )}
        </div>

        {/* Query Input Bar */}
        <div className="p-4 border-t border-slate-200 bg-white">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="Ask about a scam message, suspicious email, or how to report..."
              className="flex-1 px-4 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-none"
            />
            <Button type="submit" variant="teal" isLoading={isLoading} rightIcon={<Send className="w-4 h-4" />}>
              Consult AI
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
};
