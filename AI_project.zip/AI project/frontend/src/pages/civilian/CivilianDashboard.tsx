import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ShieldAlert,
  FilePlus,
  FileText,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  MessageSquare,
  ShieldCheck,
  ChevronRight,
  TrendingUp,
  Fingerprint,
  Lock,
  BadgeCheck,
  CreditCard,
  Mail,
  UserX,
  KeyRound,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { api } from '../../services/api';
import { Incident } from '../../types';
import { getDefaultAvatar } from '../../utils/avatars';

export const CivilianDashboard: React.FC = () => {
  const { user } = useAuth();
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      try {
        if (!user?.id) {
          setIncidents([]);
          return;
        }
        const data = await api.getIncidents({ civilianId: user.id });
        setIncidents(data);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user]);

  const totalCount = incidents.length;
  const pendingCount = incidents.filter(i => i.status !== 'resolved' && i.status !== 'closed').length;
  const resolvedCount = incidents.filter(i => i.status === 'resolved' || i.status === 'closed').length;

  // Connected Active Case (pulls live latest pending case or first case if any exist)
  const activeCase = incidents.length > 0
    ? (incidents.find(i => i.status !== 'resolved' && i.status !== 'closed') || incidents[0])
    : undefined;

  const getStepStatus = (currentStatus: string, stepIdx: number) => {
    const statusOrder: Record<string, number> = {
      submitted: 1,
      under_review: 2,
      assigned: 3,
      investigation_in_progress: 4,
      additional_info_required: 4,
      resolved: 5,
      closed: 5,
    };
    const currentStep = statusOrder[currentStatus] || 1;
    if (stepIdx < currentStep) return 'done';
    if (stepIdx === currentStep) return 'current';
    return 'upcoming';
  };

  const steps = [
    { num: 1, title: 'Submitted', desc: 'Case intake received' },
    { num: 2, title: 'Under Review', desc: 'Initial triage' },
    { num: 3, title: 'Assigned', desc: 'Investigator designated' },
    { num: 4, title: 'Investigating', desc: 'Forensics active' },
    { num: 5, title: 'Resolved', desc: 'Final case resolution' },
  ];

  const userAvatar = user?.avatar_url || getDefaultAvatar(user?.gender, user?.role);

  return (
    <div className="space-y-6">
      {/* 1. Cohesive Welcome & Action Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-sm relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="absolute inset-0 bg-cyber-grid pointer-events-none opacity-40"></div>

        <div className="flex items-center gap-5 z-10 w-full md:w-auto">
          <div className="relative shrink-0">
            <img
              src={userAvatar}
              alt={user?.full_name || 'Civilian'}
              className="w-16 h-16 sm:w-18 sm:h-18 rounded-2xl object-cover border-2 border-blue-500 shadow-xs"
            />
            <div className="absolute -bottom-1 -right-1 p-0.5 bg-blue-600 text-white rounded-md shadow-xs" title="Verified Account">
              <BadgeCheck className="w-3.5 h-3.5" />
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
                Civilian Portal
              </span>
              <span className="text-xs text-slate-400">•</span>
              <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Active Support
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554] tracking-tight">
              Welcome, {user?.full_name || 'Sarah Connor'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 max-w-lg">
              Track your reported incidents, evidence, and investigator correspondence in real time.
            </p>
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex items-center gap-3 w-full md:w-auto z-10 shrink-0">
          <Link to="/civilian/report" className="flex-1 md:flex-initial">
            <Button variant="primary" size="md" className="w-full shadow-sm" leftIcon={<FilePlus className="w-4 h-4" />}>
              Report Incident
            </Button>
          </Link>
          <Link to="/civilian/ai-assistant" className="flex-1 md:flex-initial">
            <Button variant="teal" size="md" className="w-full" leftIcon={<Sparkles className="w-4 h-4" />}>
              AI Copilot
            </Button>
          </Link>
        </div>
      </div>

      {/* 2. Connected Active Case Live Progress Tracker */}
      {activeCase ? (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div className="space-y-1">
              <div className="flex items-center gap-2.5">
                <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-lg border border-blue-200">
                  {activeCase.complaint_id}
                </span>
                <span className="text-sm font-bold text-slate-900 truncate max-w-md">
                  {activeCase.title}
                </span>
              </div>
              <p className="text-xs text-slate-500 capitalize">
                Category: {activeCase.category.replace(/_/g, ' ')} &bull; Reported {new Date(activeCase.created_at).toLocaleDateString()}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <Badge status={activeCase.status} />
              <Link to={`/civilian/complaints/${activeCase.id}`}>
                <Button variant="outline" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
                  View Full Case
                </Button>
              </Link>
            </div>
          </div>

          {/* Interactive Connected 5-Stage Milestone Timeline */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {steps.map((st) => {
              const status = getStepStatus(activeCase.status, st.num);
              return (
                <div
                  key={st.num}
                  className={`p-3.5 rounded-2xl border text-xs space-y-1 transition-all ${
                    status === 'done'
                      ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900'
                      : status === 'current'
                      ? 'bg-blue-50 border-blue-300 text-blue-900 ring-2 ring-blue-500/20'
                      : 'bg-slate-50 border-slate-200 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-[10px]">STAGE 0{st.num}</span>
                    {status === 'done' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                    {status === 'current' && <span className="w-2 h-2 rounded-full bg-blue-600 animate-ping"></span>}
                  </div>
                  <div className="font-bold text-xs">{st.title}</div>
                  <div className="text-[10px] opacity-75">{st.desc}</div>
                </div>
              );
            })}
          </div>

          {/* Assigned Investigator Connection Bar */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img
                src={getDefaultAvatar('male', 'investigator')}
                alt="Investigator"
                className="w-10 h-10 rounded-xl object-cover border border-slate-200 shadow-xs"
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-900">
                    {activeCase.assigned_investigator_name || 'Special Agent Marcus Vance'}
                  </span>
                  <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.2 rounded border border-blue-200">
                    Assigned Investigator
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Forensic Triage Unit &bull; Ready to review additional evidence
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Link to="/civilian/messages">
                <Button variant="outline" size="sm" leftIcon={<MessageSquare className="w-3.5 h-3.5" />}>
                  Message Investigator
                </Button>
              </Link>
              <Link to={`/civilian/complaints/${activeCase.id}`}>
                <Button variant="primary" size="sm" leftIcon={<FilePlus className="w-3.5 h-3.5" />}>
                  Upload Evidence
                </Button>
              </Link>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-6 relative overflow-hidden">
          <div className="flex items-center gap-4 z-10">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-200 shadow-xs shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div className="space-y-0.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Fresh Account • Active Grid Protection
              </span>
              <h2 className="text-base sm:text-lg font-bold text-[#172554]">
                You have 0 active incident reports
              </h2>
              <p className="text-xs text-slate-500 max-w-lg">
                Your portal is clean and ready. If you ever experience financial fraud, phishing, or harassment, submit a report below to begin an investigation.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 w-full sm:w-auto z-10 shrink-0">
            <Link to="/civilian/report" className="flex-1 sm:flex-initial">
              <Button variant="primary" size="md" leftIcon={<FilePlus className="w-4 h-4" />}>
                File First Report
              </Button>
            </Link>
          </div>
        </div>
      )}

      {/* 3. Concise Overview Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Complaints</p>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-[#172554] mt-1">{totalCount}</h3>
            <p className="text-xs text-slate-500 mt-0.5">Recorded incidents</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <FileText className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Investigations</p>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-amber-600 mt-1">{pendingCount}</h3>
            <p className="text-xs text-amber-600 mt-0.5 font-medium flex items-center gap-1">
              <Clock className="w-3 h-3" /> Under active analysis
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Resolved Cases</p>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-emerald-600 mt-1">{resolvedCount}</h3>
            <p className="text-xs text-emerald-600 mt-0.5 font-medium flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Concluded with report
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* 4. Streamlined Incident Reporting Hub (All Categories Kept, Low Word Clutter) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-[#172554]">Instant Incident Reporting</h2>
            <p className="text-xs text-slate-500">Select a cybercrime category to launch guided reporting</p>
          </div>
          <Link to="/civilian/report" className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1">
            <span>View All Categories</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              title: 'Phishing & Email Scams',
              category: 'phishing',
              tag: 'High Risk',
              color: 'text-red-600 bg-red-50 border-red-200',
              icon: Mail,
            },
            {
              title: 'Financial & UPI Fraud',
              category: 'financial_fraud',
              tag: 'Financial Loss',
              color: 'text-amber-600 bg-amber-50 border-amber-200',
              icon: CreditCard,
            },
            {
              title: 'Identity Theft & Impersonation',
              category: 'identity_theft',
              tag: 'Privacy Breach',
              color: 'text-purple-600 bg-purple-50 border-purple-200',
              icon: UserX,
            },
            {
              title: 'Account Takeover & Hacking',
              category: 'account_hacking',
              tag: 'Unauthorized Access',
              color: 'text-blue-600 bg-blue-50 border-blue-200',
              icon: KeyRound,
            },
          ].map((cat) => {
            const Icon = cat.icon;
            return (
              <div
                key={cat.category}
                onClick={() => navigate('/civilian/report')}
                className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs hover:border-blue-300 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 group-hover:bg-blue-50 group-hover:text-blue-600 text-slate-700 flex items-center justify-center transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${cat.color}`}>
                    {cat.tag}
                  </span>
                </div>

                <div className="mt-4 space-y-1">
                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                    {cat.title}
                  </h4>
                  <div className="pt-2 text-xs font-semibold text-blue-600 flex items-center justify-between border-t border-slate-100">
                    <span>Start Report</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. Connected Dual Panel: Recent Complaints + AI Security Assistant */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Recent Complaints List */}
        <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden">
          <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-[#172554]">My Complaints</h2>
              <p className="text-xs text-slate-500">Recent reported incidents and active investigator assignments</p>
            </div>
            <Link to="/civilian/complaints">
              <Button variant="ghost" size="sm" rightIcon={<ArrowRight className="w-4 h-4" />}>
                View All
              </Button>
            </Link>
          </div>

          {incidents.length === 0 ? (
            <div className="p-10 text-center space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-800">No Incidents Reported</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Your complaints log is clean. When you report cyber fraud, phishing, or extortion, your case progress and assigned investigator will appear here.
                </p>
              </div>
              <Link to="/civilian/report" className="inline-block pt-1">
                <Button variant="primary" size="sm" leftIcon={<FilePlus className="w-4 h-4" />}>
                  File an Incident Report
                </Button>
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {incidents.slice(0, 3).map((incident) => (
                <div
                  key={incident.id}
                  onClick={() => navigate(`/civilian/complaints/${incident.id}`)}
                  className="p-5 hover:bg-slate-50/70 cursor-pointer transition-colors space-y-2.5"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                        {incident.complaint_id}
                      </span>
                      <span className="text-xs font-semibold text-slate-600 capitalize">
                        {incident.category.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge severity={incident.severity} />
                      <Badge status={incident.status} />
                    </div>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 hover:text-blue-600 transition-colors">
                    {incident.title}
                  </h3>

                  <div className="flex flex-wrap items-center justify-between text-xs text-slate-500 pt-1">
                    <div className="flex items-center gap-2">
                      <img
                        src={getDefaultAvatar('male', 'investigator')}
                        alt="Investigator"
                        className="w-5 h-5 rounded-md object-cover border border-slate-200"
                      />
                      <span>Investigator: <strong className="text-slate-800">{incident.assigned_investigator_name || 'Agent Marcus Vance'}</strong></span>
                    </div>
                    <span className="text-blue-600 font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                      View Details &rarr;
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right: AI Security Assistant Quick Action & Alert */}
        <div className="lg:col-span-4 space-y-6">
          {/* AI Security Assistant Card */}
          <div className="bg-gradient-to-br from-teal-50 to-blue-50 rounded-3xl p-6 border border-teal-200 shadow-sm space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#172554]">AI Security Advisor</h3>
                <p className="text-[11px] text-teal-700 font-medium">Scam & Evidence Guidance</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Analyze suspicious emails, verify payment requests, and learn how to preserve digital evidence.
            </p>

            <div className="space-y-2">
              <button
                onClick={() => navigate('/civilian/ai-assistant')}
                className="w-full text-left p-2.5 rounded-xl bg-white border border-teal-200 hover:border-teal-300 text-xs font-medium text-slate-700 transition-all flex items-center justify-between shadow-2xs"
              >
                <span>&ldquo;How do I preserve screenshot evidence?&rdquo;</span>
                <ChevronRight className="w-3.5 h-3.5 text-teal-600" />
              </button>
              <button
                onClick={() => navigate('/civilian/ai-assistant')}
                className="w-full text-left p-2.5 rounded-xl bg-white border border-teal-200 hover:border-teal-300 text-xs font-medium text-slate-700 transition-all flex items-center justify-between shadow-2xs"
              >
                <span>&ldquo;Is this bank wire request legitimate?&rdquo;</span>
                <ChevronRight className="w-3.5 h-3.5 text-teal-600" />
              </button>
            </div>

            <Link to="/civilian/ai-assistant" className="block pt-1">
              <Button variant="teal" size="sm" className="w-full justify-between" rightIcon={<ArrowRight className="w-4 h-4" />}>
                <span>Open Assistant</span>
              </Button>
            </Link>
          </div>

          {/* Active Security Bulletin */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                Security Advisory
              </h3>
              <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                ACTIVE
              </span>
            </div>

            <p className="text-xs font-bold text-slate-900">
              Spoofed Payment Redirection Schemes
            </p>
            <p className="text-xs text-slate-500 leading-relaxed">
              Verify any changes to vendor bank accounts via an authorized phone call before initiating transfers.
            </p>

            <Link
              to="/civilian/safety-center"
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 pt-1"
            >
              <span>Cyber Safety Guides</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
