import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ShieldAlert,
  ArrowLeft,
  MessageSquare,
  Upload,
  Calendar,
  Clock,
  User,
  Globe,
  DollarSign,
  Fingerprint,
  FileCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ShieldCheck,
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { Incident, IncidentStatus } from '../../types';
import { getDefaultAvatar } from '../../utils/avatars';

export const ComplaintDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [incident, setIncident] = useState<Incident | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [newFile, setNewFile] = useState<File | null>(null);
  const [newFileDescription, setNewFileDescription] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    const load = async () => {
      if (id) {
        const found = await api.getIncidentById(id);
        setIncident(found);
      }
      setLoading(false);
    };
    load();
  }, [id]);

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFile || !incident) return;
    setIsUploading(true);
    try {
      await api.uploadEvidence(
        incident.id,
        newFile,
        { id: user?.id || 'usr-civ-001', name: user?.full_name || 'Sarah Connor' },
        newFileDescription
      );
      // Reload incident
      const reloaded = await api.getIncidentById(incident.id);
      setIncident(reloaded);
      setUploadModalOpen(false);
      setNewFile(null);
      setNewFileDescription('');
    } finally {
      setIsUploading(false);
    }
  };

  if (loading) {
    return <div className="p-12 text-center text-xs text-slate-500">Loading complaint details...</div>;
  }

  if (!incident) {
    return (
      <div className="p-12 text-center space-y-4">
        <h2 className="text-lg font-bold text-slate-800">Complaint Not Found</h2>
        <Link to="/civilian/complaints">
          <Button variant="outline">Back to Complaints</Button>
        </Link>
      </div>
    );
  }

  const statusSteps: { status: IncidentStatus; label: string }[] = [
    { status: 'submitted', label: 'Submitted' },
    { status: 'under_review', label: 'Under Review' },
    { status: 'assigned', label: 'Assigned' },
    { status: 'investigation_in_progress', label: 'In Progress' },
    { status: 'resolved', label: 'Resolved' },
  ];

  const currentStepIdx = statusSteps.findIndex(s => s.status === incident.status);

  return (
    <div className="space-y-8">
      {/* Back button & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <Link
            to="/civilian/complaints"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors mb-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to My Complaints
          </Link>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-extrabold text-[#172554]">{incident.title}</h1>
            <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200">
              {incident.complaint_id}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Link to={`/civilian/messages`}>
            <Button variant="secondary" leftIcon={<MessageSquare className="w-4 h-4 text-blue-600" />}>
              Chat with Investigator
            </Button>
          </Link>
          <Button variant="primary" onClick={() => setUploadModalOpen(true)} leftIcon={<Upload className="w-4 h-4" />}>
            Add Evidence
          </Button>
        </div>
      </div>

      {/* Progress Stepper */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Investigation Lifecycle</span>
          <div className="flex items-center gap-2">
            <Badge severity={incident.severity} />
            <Badge status={incident.status} />
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
          {statusSteps.map((stepItem, idx) => {
            const isCompleted = currentStepIdx >= idx;
            const isCurrent = incident.status === stepItem.status;
            return (
              <div key={stepItem.status} className="relative space-y-2">
                <div
                  className={`h-2 rounded-full transition-all ${
                    isCompleted ? 'bg-blue-600' : 'bg-slate-200'
                  }`}
                />
                <div className="flex items-center gap-1.5">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      isCurrent ? 'bg-blue-600 animate-ping' : isCompleted ? 'bg-blue-600' : 'bg-slate-300'
                    }`}
                  />
                  <span className={`text-xs font-semibold ${isCompleted ? 'text-slate-900' : 'text-slate-400'}`}>
                    {stepItem.label}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid: Incident Metadata + Assigned Investigator & Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Details & Evidence */}
        <div className="lg:col-span-7 space-y-6">
          {/* Summary Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-slate-900">Incident Information</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-slate-500">Category:</span>
                <p className="font-semibold text-slate-800 capitalize mt-0.5">{incident.category.replace(/_/g, ' ')}</p>
              </div>
              <div>
                <span className="text-slate-500">Incident Date:</span>
                <p className="font-semibold text-slate-800 mt-0.5">{incident.incident_date} {incident.incident_time}</p>
              </div>
              <div>
                <span className="text-slate-500">Platform Involved:</span>
                <p className="font-semibold text-slate-800 mt-0.5">{incident.platform_involved || 'Not specified'}</p>
              </div>
              <div>
                <span className="text-slate-500">Reported Financial Loss:</span>
                <p className="font-semibold text-slate-800 mt-0.5">
                  {incident.financial_loss ? `$${incident.financial_loss.toLocaleString()}` : 'None'}
                </p>
              </div>
              {incident.website_url && (
                <div className="sm:col-span-2">
                  <span className="text-slate-500">Target Website / URL:</span>
                  <p className="font-mono text-blue-700 bg-slate-50 p-2 rounded border border-slate-200 mt-0.5 truncate">
                    {incident.website_url}
                  </p>
                </div>
              )}
              {incident.suspect_info && (
                <div className="sm:col-span-2">
                  <span className="text-slate-500">Suspect Information:</span>
                  <p className="font-semibold text-slate-800 bg-slate-50 p-2 rounded border border-slate-200 mt-0.5">
                    {incident.suspect_info}
                  </p>
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-slate-100">
              <span className="text-xs text-slate-500">Detailed Description:</span>
              <p className="text-xs text-slate-700 font-normal mt-1 leading-relaxed whitespace-pre-wrap">
                {incident.description}
              </p>
            </div>
          </div>

          {/* Evidence Gallery */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900">Submitted Evidence Artifacts</h2>
                <p className="text-xs text-slate-500">Tamper-evident files with SHA-256 hashes</p>
              </div>
              <button
                onClick={() => setUploadModalOpen(true)}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800"
              >
                + Upload More
              </button>
            </div>

            {(!incident.evidence || incident.evidence.length === 0) ? (
              <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 rounded-xl">
                No evidence documents uploaded yet.
              </div>
            ) : (
              <div className="space-y-3">
                {incident.evidence.map((ev) => (
                  <div
                    key={ev.id}
                    className="p-3.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-white transition-all space-y-2"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <FileCheck className="w-5 h-5 text-teal-600 shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-slate-800">{ev.file_name}</p>
                          <p className="text-[11px] text-slate-500">
                            {(ev.file_size / 1024).toFixed(1)} KB • Uploaded {new Date(ev.uploaded_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-teal-50 text-teal-700 border border-teal-200 rounded">
                        VERIFIED HASH
                      </span>
                    </div>

                    <div className="flex items-center gap-2 bg-slate-50 p-2 rounded text-[10px] font-mono text-slate-600">
                      <Fingerprint className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span className="truncate">SHA-256: {ev.sha256_hash}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Assigned Investigator & Forensic Timeline */}
        <div className="lg:col-span-5 space-y-6">
          {/* Assigned Investigator Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Assigned Forensic Investigator</h3>
            {incident.assigned_investigator_name ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3.5">
                  <div className="relative">
                    <img
                      src={getDefaultAvatar('male', 'investigator')}
                      alt={incident.assigned_investigator_name || 'Investigator'}
                      className="w-13 h-13 rounded-2xl object-cover border-2 border-blue-500 shadow-sm"
                    />
                    <div className="absolute -bottom-1 -right-1 p-0.5 bg-blue-600 text-white rounded-md shadow-xs">
                      <ShieldCheck className="w-3.5 h-3.5" />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900">{incident.assigned_investigator_name}</h4>
                      <span className="text-[10px] font-mono font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                        #SG-INV-8492
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">Lead Detective &bull; Cyber Fraud & Ransomware Unit</p>
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 mt-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      <span>Active Case Lead &bull; Available in Chat</span>
                    </div>
                  </div>
                </div>
                <Link to="/civilian/messages">
                  <Button variant="primary" size="sm" className="w-full shadow-sm" leftIcon={<MessageSquare className="w-3.5 h-3.5" />}>
                    Open Direct Message Channel
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/70 text-xs text-slate-600">
                This complaint is currently in the initial triage queue awaiting lead investigator assignment.
              </div>
            )}
          </div>

          {/* Forensic Activity Timeline */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-sm space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Forensic Audit Timeline</h3>
            <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
              {incident.timeline?.map((evt) => (
                <div key={evt.id} className="relative space-y-1">
                  <div className="absolute -left-6 top-1 w-2.5 h-2.5 rounded-full bg-blue-600 ring-4 ring-white" />
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-slate-900">{evt.actor_name}</span>
                    <span className="text-slate-400">
                      {new Date(evt.created_at).toLocaleDateString()} {new Date(evt.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{evt.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Modal: Upload Additional Evidence */}
      <Modal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        title="Upload Additional Evidence"
        subtitle={`Appending forensic file to ${incident.complaint_id}`}
      >
        <form onSubmit={handleUploadSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Select File</label>
            <input
              type="file"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  setNewFile(e.target.files[0]);
                }
              }}
              className="w-full text-xs text-slate-600 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700 cursor-pointer border border-slate-200 rounded-lg p-2"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Evidence Description</label>
            <textarea
              rows={3}
              value={newFileDescription}
              onChange={(e) => setNewFileDescription(e.target.value)}
              placeholder="e.g. Supplementary bank transfer receipt or WhatsApp chat log"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <Button type="button" variant="outline" onClick={() => setUploadModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" isLoading={isUploading} leftIcon={<Upload className="w-4 h-4" />}>
              Compute SHA-256 & Upload
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
