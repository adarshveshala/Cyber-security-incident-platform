import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Send,
  Paperclip,
  ShieldCheck,
  User,
  Clock,
  AlertCircle,
  FileCheck,
  CheckCheck,
  HelpCircle,
  ArrowRight,
  ExternalLink,
  MessageSquare,
  RefreshCw,
  PlusCircle,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import { Button } from '../../components/common/Button';
import { api } from '../../services/api';
import { Incident, Message } from '../../types';
import { getDefaultAvatar } from '../../utils/avatars';

export const CivilianMessages: React.FC = () => {
  const { user } = useAuth();
  const { addMessage, recentMessages } = useSocket();
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Dedicated container ref for internal chat scrolling (NEVER scroll the whole window)
  const chatFeedRef = useRef<HTMLDivElement>(null);
  const prevMsgCountRef = useRef(0);
  const activeIncidentIdRef = useRef<string | null>(null);

  const scrollChatToBottom = useCallback((smooth = false) => {
    const el = chatFeedRef.current;
    if (!el) return;
    el.scrollTo({
      top: el.scrollHeight,
      behavior: smooth ? 'smooth' : 'auto',
    });
  }, []);

  // Load complaints for this civilian
  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      try {
        const civilianId = user?.id || 'usr-civ-001';
        let data = await api.getIncidents({ civilianId });

        // If civilian-specific filter returned empty, fetch general incident list for the user's role
        if (!data || data.length === 0) {
          data = await api.getIncidents();
        }

        if (!isMounted) return;
        setIncidents(data);
        if (data.length > 0) {
          setSelectedIncident((prev) => {
            if (prev) {
              const stillExists = data.find((i) => i.id === prev.id || i.complaint_id === prev.complaint_id);
              return stillExists || data[0];
            }
            return data[0];
          });
        }
      } catch (err) {
        console.error('Failed to load civilian complaints:', err);
      }
    };
    load();
    return () => {
      isMounted = false;
    };
  }, [user?.id]);

  // Fetch messages when selected incident changes or on interval
  useEffect(() => {
    if (!selectedIncident) return;
    let isMounted = true;
    const incId = selectedIncident.id;

    // Reset message count baseline on incident switch
    if (activeIncidentIdRef.current !== incId) {
      activeIncidentIdRef.current = incId;
      prevMsgCountRef.current = 0;
    }

    const fetchMsgs = async () => {
      try {
        const msgs = await api.getMessagesByIncident(incId);
        if (!isMounted) return;

        setMessages((prev) => {
          // Check if messages list actually changed to prevent unnecessary re-renders
          if (
            prev.length === msgs.length &&
            (prev.length === 0 || prev[prev.length - 1]?.id === msgs[msgs.length - 1]?.id)
          ) {
            return prev;
          }
          return msgs;
        });
      } catch (err) {
        console.warn('Error fetching messages for civilian complaint:', err);
      }
    };

    fetchMsgs();
    const interval = setInterval(fetchMsgs, 4000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [selectedIncident?.id, selectedIncident?.complaint_id]);

  // Handle internal chat scrolling safely (never touches window scroll)
  useEffect(() => {
    const el = chatFeedRef.current;
    if (!el) return;

    if (prevMsgCountRef.current === 0 && messages.length > 0) {
      // First load for this conversation: snap to bottom instantly
      el.scrollTop = el.scrollHeight;
    } else if (messages.length > prevMsgCountRef.current) {
      // Only smooth-scroll if user is already near bottom (within 140px)
      const isNearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 140;
      if (isNearBottom) {
        scrollChatToBottom(true);
      }
    }
    prevMsgCountRef.current = messages.length;
  }, [messages, scrollChatToBottom]);

  // Merge socket messages if relevant to active complaint
  useEffect(() => {
    if (!selectedIncident || recentMessages.length === 0) return;
    const latest = recentMessages[recentMessages.length - 1];
    if (
      latest &&
      (latest.incident_id === selectedIncident.id || latest.incident_id === selectedIncident.complaint_id)
    ) {
      setMessages((prev) => {
        if (prev.some((m) => m.id === latest.id)) return prev;
        return [...prev, latest];
      });
      // Scroll down for own new message
      setTimeout(() => scrollChatToBottom(true), 50);
    }
  }, [recentMessages, selectedIncident, scrollChatToBottom]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !selectedIncident) return;
    const text = inputText.trim();
    setIsSending(true);
    try {
      const sent = await api.sendMessage(
        selectedIncident.id,
        {
          id: user?.id || 'usr-civ-001',
          name: user?.full_name || 'Sarah Connor',
          role: user?.role || 'civilian',
        },
        text
      );
      setMessages((prev) => [...prev, sent]);
      addMessage(sent);
      setInputText('');
      setTimeout(() => scrollChatToBottom(true), 50);
    } catch (err) {
      console.error('Error sending civilian message:', err);
    } finally {
      setIsSending(false);
    }
  };

  const handleManualRefresh = async () => {
    if (!selectedIncident) return;
    setIsRefreshing(true);
    try {
      const msgs = await api.getMessagesByIncident(selectedIncident.id);
      setMessages(msgs);
      setTimeout(() => scrollChatToBottom(false), 50);
    } finally {
      setTimeout(() => setIsRefreshing(false), 400);
    }
  };

  const investigatorName =
    selectedIncident?.assigned_investigator_name || 'Assigned SOC Digital Forensics Investigator';
  const caseReference =
    selectedIncident?.complaint_id || selectedIncident?.id?.slice(0, 8) || 'SG-CASE';

  return (
    <div className="space-y-4">
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">Investigator Communications</h1>
          <p className="text-xs text-slate-500 mt-1">
            Direct, encrypted messaging channel between you and your assigned digital forensics investigator.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {selectedIncident && (
            <button
              type="button"
              onClick={handleManualRefresh}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-600 hover:bg-slate-50 shadow-xs transition-colors cursor-pointer"
              title="Refresh messages"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-blue-600' : ''}`} />
              <span>Sync Feed</span>
            </button>
          )}
          <Link
            to="/civilian/report"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-xs font-semibold text-white shadow-xs transition-colors"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>New Report</span>
          </Link>
        </div>
      </div>

      {/* Main Grid Workspace */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden grid grid-cols-1 md:grid-cols-12 h-[calc(100vh-210px)] min-h-[560px] max-h-[850px]">
        {/* Left Column: Case Conversation Threads */}
        <div className="md:col-span-4 border-r border-slate-200 flex flex-col h-full min-h-0 bg-slate-50/40">
          <div className="p-4 border-b border-slate-200 bg-white flex items-center justify-between shrink-0">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Active Complaint Threads ({incidents.length})
            </h2>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Encrypted
            </span>
          </div>

          {/* Scrollable Cases List with Internal Scrolling */}
          <div className="divide-y divide-slate-100 overflow-y-auto flex-1 min-h-0 overscroll-contain">
            {incidents.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 space-y-3">
                <p>No active complaint threads found.</p>
                <Link
                  to="/civilian/report"
                  className="inline-flex items-center gap-1.5 text-blue-600 hover:underline font-semibold text-xs"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  File your first report
                </Link>
              </div>
            ) : (
              incidents.map((inc) => {
                const isSelected =
                  selectedIncident?.id === inc.id || selectedIncident?.complaint_id === inc.complaint_id;
                const caseCode = inc.complaint_id || (inc.id ? inc.id.slice(0, 8) : 'SG-PENDING');
                const createdDate = inc.created_at ? new Date(inc.created_at).toLocaleDateString() : 'Active';

                return (
                  <button
                    type="button"
                    key={inc.id}
                    onClick={() => {
                      setSelectedIncident(inc);
                    }}
                    className={`w-full text-left p-4 cursor-pointer transition-colors block border-l-4 select-none ${
                      isSelected
                        ? 'bg-blue-50/90 border-blue-600 shadow-xs'
                        : 'hover:bg-slate-100/70 border-transparent bg-transparent'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-[11px] font-bold text-blue-700 bg-white px-2 py-0.5 rounded border border-blue-200 shadow-2xs">
                        {caseCode}
                      </span>
                      <span className="text-[10px] text-slate-400 font-medium">
                        {createdDate}
                      </span>
                    </div>

                    <h3 className="text-xs font-bold text-slate-900 mt-1.5 truncate">
                      {inc.title || 'Incident Report'}
                    </h3>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                      {inc.assigned_investigator_name
                        ? `Investigator: ${inc.assigned_investigator_name}`
                        : 'Awaiting investigator assignment'}
                    </p>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Active Conversation */}
        <div className="md:col-span-8 flex flex-col h-full min-h-0 bg-white">
          {selectedIncident ? (
            <>
              {/* Thread Header */}
              <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-white shrink-0">
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={getDefaultAvatar('male', 'investigator')}
                    alt={investigatorName}
                    className="w-10 h-10 rounded-xl object-cover border border-slate-200 shadow-xs shrink-0"
                  />
                  <div className="min-w-0">
                    <h3 className="text-sm font-bold text-slate-900 truncate">
                      {investigatorName}
                    </h3>
                    <p className="text-[11px] text-slate-500 truncate">
                      Case: <strong className="font-mono text-slate-800">{caseReference}</strong> •{' '}
                      {selectedIncident.title || 'Incident Report'}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="px-2.5 py-1 text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    Verified Channel
                  </span>
                </div>
              </div>

              {/* Messages Area (Internal Scroll Container) */}
              <div
                ref={chatFeedRef}
                className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50/40 min-h-0 overscroll-contain"
              >
                <div className="text-center my-1 shrink-0">
                  <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-500 text-[10px] font-medium border border-slate-200 shadow-2xs">
                    Official chain-of-custody log for case {caseReference}
                  </span>
                </div>

                {messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full py-16 text-center text-slate-400">
                    <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-500 flex items-center justify-center mb-3">
                      <MessageSquare className="w-6 h-6" />
                    </div>
                    <p className="text-xs font-semibold text-slate-600">No messages in this case yet.</p>
                    <p className="text-[11px] text-slate-400 mt-1 max-w-sm">
                      Send a clarification message or inquiry to your assigned forensics investigator below.
                    </p>
                  </div>
                ) : (
                  messages.map((m) => {
                    const isMe = m.sender_role === 'civilian';
                    const senderAvatar = isMe
                      ? user?.avatar_url || getDefaultAvatar(user?.gender, user?.role)
                      : getDefaultAvatar('male', 'investigator');
                    const senderLabel = m.sender_name || (isMe ? 'You' : 'Investigator');
                    const timeString = m.created_at
                      ? new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                      : '';

                    return (
                      <div
                        key={m.id}
                        className={`flex items-start gap-2.5 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}
                      >
                        <img
                          src={senderAvatar}
                          alt={senderLabel}
                          className="w-7 h-7 rounded-lg object-cover border border-slate-200 shadow-2xs shrink-0 mt-3"
                        />
                        <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-[85%]`}>
                          <div className="flex items-center gap-1.5 mb-1 px-1 text-[11px] text-slate-400">
                            <span className="font-semibold text-slate-700">{senderLabel}</span>
                            {timeString && (
                              <>
                                <span>•</span>
                                <span>{timeString}</span>
                              </>
                            )}
                          </div>

                          <div
                            className={`p-3.5 rounded-2xl text-xs leading-relaxed ${
                              isMe
                                ? 'bg-blue-600 text-white rounded-tr-xs shadow-xs'
                                : m.is_evidence_request
                                ? 'bg-amber-50 text-amber-950 border border-amber-300 rounded-tl-xs shadow-xs'
                                : 'bg-white text-slate-800 border border-slate-200/90 rounded-tl-xs shadow-xs'
                            }`}
                          >
                            {m.is_evidence_request && (
                              <div className="flex items-center gap-1.5 font-bold text-amber-900 mb-1.5 pb-1 border-b border-amber-200">
                                <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                <span>Forensic Evidence Request</span>
                              </div>
                            )}
                            <p className="whitespace-pre-wrap">{m.content}</p>

                            {m.attachment_name && (
                              <div
                                className={`mt-2 p-2 rounded-lg text-[11px] font-mono flex items-center gap-2 ${
                                  isMe ? 'bg-blue-700/60 text-blue-100' : 'bg-slate-100 text-slate-700'
                                }`}
                              >
                                <FileCheck className="w-3.5 h-3.5 shrink-0" />
                                <span className="truncate">{m.attachment_name}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Input Box */}
              <form
                onSubmit={handleSend}
                className="p-4 border-t border-slate-200 bg-white shrink-0 flex items-center gap-2"
              >
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={`Reply regarding ${caseReference}...`}
                  className="flex-1 px-4 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder:text-slate-400"
                />
                <Button
                  type="submit"
                  variant="primary"
                  size="md"
                  isLoading={isSending}
                  disabled={!inputText.trim()}
                  rightIcon={<Send className="w-4 h-4" />}
                >
                  Send
                </Button>
              </form>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center text-slate-400 m-auto">
              <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
                <MessageSquare className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-800">Select an Incident Thread</h3>
              <p className="text-xs text-slate-400 max-w-sm mt-1">
                Choose a complaint from the list on the left to view messages from your assigned forensics investigator.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
