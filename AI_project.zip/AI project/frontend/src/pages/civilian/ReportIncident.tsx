import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  ShieldAlert,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Upload,
  FileText,
  AlertCircle,
  HelpCircle,
  DollarSign,
  Globe,
  Calendar,
  Clock,
  User,
  Fingerprint,
  X,
  FileCheck,
  CreditCard,
  Mail,
  KeyRound,
  Shield,
  Layers,
  MapPin,
  Laptop,
  RefreshCw,
  RotateCcw,
  Compass
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../../components/common/Button';
import { api } from '../../services/api';
import { IncidentCategory, IncidentSeverity } from '../../types';

export const ReportIncident: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedIncident, setSubmittedIncident] = useState<any | null>(null);

  // Form State
  const [category, setCategory] = useState<IncidentCategory>('financial_fraud');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [incidentDate, setIncidentDate] = useState(new Date().toISOString().split('T')[0]);
  const [incidentTime, setIncidentTime] = useState('12:00');
  const [platformInvolved, setPlatformInvolved] = useState('');
  const [suspectInfo, setSuspectInfo] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [hasFinancialLoss, setHasFinancialLoss] = useState(false);
  const [financialLoss, setFinancialLoss] = useState<number | ''>('');
  const [contactEmail, setContactEmail] = useState(user?.email || '');
  const [contactPhone, setContactPhone] = useState(user?.phone || '');

  // Device IP & Location Fields
  const [deviceIp, setDeviceIp] = useState<string>('Detecting IP...');
  const [city, setCity] = useState<string>('Hyderabad');
  const [region, setRegion] = useState<string>('Telangana');
  const [country, setCountry] = useState<string>('India');

  const [files, setFiles] = useState<{ file: File; hash: string }[]>([]);
  const [formError, setFormError] = useState('');

  // Auto-detect reporting device network IP on mount
  useEffect(() => {
    let isMounted = true;
    const detectClientNetwork = async () => {
      try {
        const res = await fetch('https://ipwho.is/');
        if (res.ok) {
          const data = await res.json();
          if (isMounted && data.success !== false && data.ip) {
            setDeviceIp(data.ip);
            return;
          }
        }
      } catch (e) {
        try {
          const res2 = await fetch('https://api.ipify.org?format=json');
          if (res2.ok) {
            const data2 = await res2.json();
            if (isMounted && data2.ip) {
              setDeviceIp(data2.ip);
              return;
            }
          }
        } catch (e2) {}
      }

      if (isMounted) {
        setDeviceIp('157.50.140.6');
      }
    };

    detectClientNetwork();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleClearLocation = () => {
    setCity('');
    setRegion('');
    setCountry('');
  };

  const categories: { id: IncidentCategory; label: string; desc: string; icon: React.ComponentType<{ className?: string }>; color: string }[] = [
    { id: 'financial_fraud', label: 'Online Financial Fraud', desc: 'Wire diversion, unauthorized debit, UPI scam, payment gateway breach', icon: CreditCard, color: 'text-amber-600 bg-amber-50' },
    { id: 'phishing', label: 'Phishing & Email Spoofing', desc: 'Deceptive emails, fake login links, malicious invoice attachments', icon: Mail, color: 'text-red-600 bg-red-50' },
    { id: 'identity_theft', label: 'Identity Theft', desc: 'Stolen SSN/national ID, synthetic identities, unauthorized loan applications', icon: Fingerprint, color: 'text-purple-600 bg-purple-50' },
    { id: 'account_hacking', label: 'Account Hacking / Takeover', desc: 'Compromised email, bypassed MFA, brute-forced cloud credentials', icon: KeyRound, color: 'text-blue-600 bg-blue-50' },
    { id: 'social_media_fraud', label: 'Social Media Fraud', desc: 'Extortion schemes, fake investment groups, cloned profile scams', icon: Globe, color: 'text-teal-600 bg-teal-50' },
    { id: 'malware', label: 'Ransomware & Malware', desc: 'Encrypted hard drives, trojan droppers, spyware, keyloggers', icon: ShieldAlert, color: 'text-rose-600 bg-rose-50' },
    { id: 'impersonation', label: 'Impersonation & Executive Spoofing', desc: 'Adversary posing as executive, police officer, or bank supervisor', icon: User, color: 'text-indigo-600 bg-indigo-50' },
    { id: 'cyberbullying', label: 'Cyberbullying & Harassment', desc: 'Stalking, targeted defamation, unauthorized disclosure of private data', icon: AlertCircle, color: 'text-orange-600 bg-orange-50' },
    { id: 'data_breach', label: 'Data Breach / Leak', desc: 'Customer data exposed online, leaked credentials pastebin archive', icon: FileText, color: 'text-cyan-600 bg-cyan-50' },
    { id: 'other', label: 'Other Cybercrime', desc: 'Digital extortion, DDoS disruption, unauthorized surveillance', icon: HelpCircle, color: 'text-slate-600 bg-slate-50' },
  ];

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const uploaded = Array.from(e.target.files);

    for (const f of uploaded) {
      // Calculate SHA-256 for cryptographic integrity verification
      const arrayBuffer = await f.arrayBuffer();
      const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      setFiles(prev => [...prev, { file: f, hash: hashHex }]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const validateStep = (currentStep: number) => {
    setFormError('');
    if (currentStep === 1) {
      if (!title.trim()) {
        setFormError('Please provide a descriptive title for this incident.');
        return false;
      }
    } else if (currentStep === 2) {
      if (!description.trim() || description.length < 20) {
        setFormError('Please provide a detailed description (at least 20 characters) explaining what occurred.');
        return false;
      }
    } else if (currentStep === 3) {
      if (hasFinancialLoss && (!financialLoss || Number(financialLoss) <= 0)) {
        setFormError('Please enter the approximate monetary amount lost.');
        return false;
      }
    } else if (currentStep === 4) {
      if (!contactEmail.trim()) {
        setFormError('Contact email is required so investigators can reach you.');
        return false;
      }
    }
    return true;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    setFormError('');
    setStep(prev => prev - 1);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setFormError('');
    try {
      // Determine recommended initial severity based on financial loss or category
      let initialSeverity: IncidentSeverity = 'medium';
      if (Number(financialLoss) > 10000 || category === 'malware' || category === 'data_breach') {
        initialSeverity = 'high';
      } else if (category === 'cyberbullying') {
        initialSeverity = 'medium';
      }

      // Construct clean combined location
      const locationParts = [city.trim(), region.trim(), country.trim()].filter(Boolean);
      const combinedLocation = locationParts.join(', ') || 'Hyderabad, Telangana, India';

      let lat: number | undefined;
      let lng: number | undefined;

      // 1. Try live OpenStreetMap Nominatim geocoding if network is active
      if (locationParts.length > 0) {
        try {
          const geoQuery = encodeURIComponent(combinedLocation);
          const geoRes = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${geoQuery}&limit=1`, {
            headers: { 'Accept': 'application/json' }
          });
          if (geoRes.ok) {
            const geoData = await geoRes.json();
            if (geoData && geoData.length > 0) {
              lat = parseFloat(geoData[0].lat);
              lng = parseFloat(geoData[0].lon);
            }
          }
        } catch (err) {}
      }

      // 2. Comprehensive global coordinates dictionary
      if (!lat) {
        const queryLower = combinedLocation.toLowerCase();
        const CITY_COORDS: Record<string, [number, number]> = {
          'hyderabad': [17.3850, 78.4867],
          'secunderabad': [17.4399, 78.4983],
          'warangal': [17.9689, 79.5941],
          'telangana': [17.3850, 78.4867],
          'bangalore': [12.9716, 77.5946],
          'bengaluru': [12.9716, 77.5946],
          'mumbai': [19.0760, 72.8777],
          'delhi': [28.6139, 77.2090],
          'new delhi': [28.6139, 77.2090],
          'chennai': [13.0827, 80.2707],
          'kolkata': [22.5726, 88.3639],
          'pune': [18.5204, 73.8567],
          'ahmedabad': [23.0225, 72.5714],
          'jaipur': [26.9124, 75.7873],
          'lucknow': [26.8467, 80.9462],
          'chandigarh': [30.7333, 76.7794],
          'kochi': [9.9312, 76.2673],
          'india': [20.5937, 78.9629],
          'london': [51.5074, -0.1278],
          'new york': [40.7128, -74.0060],
          'san francisco': [37.7749, -122.4194],
          'frankfurt': [50.1109, 8.6821],
          'tokyo': [35.6762, 139.6503],
          'singapore': [1.3521, 103.8198],
          'paris': [48.8566, 2.3522],
          'berlin': [52.5200, 13.4050],
          'toronto': [43.6532, -79.3832],
          'sydney': [-33.8688, 151.2093],
          'dubai': [25.2048, 55.2708],
          'chicago': [41.8781, -87.6298],
          'austin': [30.2672, -97.7431],
          'seattle': [47.6062, -122.3321],
          'los angeles': [34.0522, -118.2437],
        };

        for (const [key, coords] of Object.entries(CITY_COORDS)) {
          if (queryLower.includes(key)) {
            lat = coords[0];
            lng = coords[1];
            break;
          }
        }
      }

      // 3. Default fallback
      if (!lat) {
        lat = 17.3850;
        lng = 78.4867;
      }

      const created = await api.createIncident({
        title,
        category,
        severity: initialSeverity,
        description,
        incident_date: incidentDate,
        incident_time: incidentTime,
        platform_involved: platformInvolved,
        suspect_info: suspectInfo,
        website_url: websiteUrl,
        financial_loss: hasFinancialLoss ? Number(financialLoss) : 0,
        currency: 'USD',
        latitude: lat,
        longitude: lng,
        location_name: combinedLocation,
        city: city.trim() || undefined,
        region: region.trim() || undefined,
        country: country.trim() || undefined,
        reporter_ip: deviceIp !== 'Detecting...' ? deviceIp : '157.50.140.6',
        contact_email: contactEmail,
        contact_phone: contactPhone,
        civilian_id: user?.id || 'usr-civ-001',
        civilian_name: user?.full_name || 'Sarah Connor',
      });

      // Upload files associated with the new incident
      for (const item of files) {
        await api.uploadEvidence(
          created.id,
          item.file,
          { id: user?.id || 'usr-civ-001', name: user?.full_name || 'Sarah Connor' },
          'Initial evidence uploaded during incident report'
        );
      }

      setSubmittedIncident(created);
    } catch (err: any) {
      setFormError(err?.message || 'Failed to submit incident. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // SUCCESS CONFIRMATION VIEW
  if (submittedIncident) {
    return (
      <div className="max-w-2xl mx-auto py-8">
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-xl text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200">
              Complaint Registered
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
              Incident Submitted Successfully
            </h1>
            <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
              Your cybercrime complaint has been securely registered in the Sentinel Grid investigation queue. Certified investigators will begin evidence verification.
            </p>
          </div>

          {/* Tracking ID Badge */}
          <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-center space-y-1">
            <p className="text-xs font-semibold text-blue-700 uppercase tracking-wider">Complaint Reference Identifier</p>
            <div className="text-3xl font-extrabold text-blue-900 font-mono tracking-wider">
              {submittedIncident.complaint_id}
            </div>
            <p className="text-[11px] text-blue-600">Save this identifier for all communications with assigned investigators.</p>
          </div>

          {/* Important Legal Notice */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-left text-xs text-slate-600 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <ShieldAlert className="w-4 h-4 text-amber-500" />
              <span>Official Protocol Notice</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              This filing creates a cryptographically verified record and routes your report to registered cyber forensic specialists. This platform connects civilians with investigators and does not replace official police dispatch hotlines for imminent physical threats.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <Link to={`/civilian/complaints/${submittedIncident.id}`} className="flex-1">
              <Button variant="primary" className="w-full" rightIcon={<ArrowRight className="w-4 h-4" />}>
                Go to Case Workspace
              </Button>
            </Link>
            <Link to="/civilian/dashboard" className="flex-1">
              <Button variant="outline" className="w-full">
                Return to Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172554]">
          Report a Cybersecurity Incident
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Follow the guided multi-step form to preserve digital evidence and initiate forensic triage.
        </p>
      </div>

      {/* Stepper Progress Indicator */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200/90 shadow-sm">
        <div className="grid grid-cols-5 gap-2 sm:gap-4 text-center">
          {[
            { num: 1, label: 'Category' },
            { num: 2, label: 'Details' },
            { num: 3, label: 'Suspect & Loss' },
            { num: 4, label: 'Evidence & Contact' },
            { num: 5, label: 'Review' },
          ].map((item) => (
            <div key={item.num} className="space-y-1.5">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center mx-auto text-xs font-bold transition-all ${
                  step === item.num
                    ? 'bg-blue-600 text-white ring-4 ring-blue-100 shadow-sm'
                    : step > item.num
                    ? 'bg-emerald-500 text-white'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                {step > item.num ? <CheckCircle2 className="w-4 h-4" /> : item.num}
              </div>
              <p className={`text-[11px] font-semibold truncate ${step === item.num ? 'text-blue-700' : 'text-slate-500'}`}>
                {item.label}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Error alert if validation fails */}
      {formError && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{formError}</span>
        </div>
      )}

      {/* Form Steps Card */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-sm space-y-6">
        {/* STEP 1: CATEGORY & TITLE */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Step 1: Incident Category & Brief Title</h2>
              <p className="text-xs text-slate-500 mt-0.5">Select the category that best matches what took place.</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Incident Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Spear-phishing email impersonating corporate finance officer"
                className="w-full px-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                required
              />
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-700">
                Choose Incident Category <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {categories.map((cat) => {
                  const Icon = cat.icon;
                  return (
                    <div
                      key={cat.id}
                      onClick={() => setCategory(cat.id)}
                      className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all flex items-start gap-3 ${
                        category === cat.id
                          ? 'border-blue-600 bg-blue-50/70 shadow-xs ring-1 ring-blue-500'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${cat.color}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-bold ${category === cat.id ? 'text-blue-900' : 'text-slate-800'}`}>
                            {cat.label}
                          </span>
                          {category === cat.id && <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 ml-1" />}
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">{cat.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: INCIDENT DETAILS */}
        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Step 2: Incident Details & Timeline</h2>
              <p className="text-xs text-slate-500 mt-0.5">Provide specifics on when and where the cybercrime occurred.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Date of Incident</label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="date"
                    value={incidentDate}
                    onChange={(e) => setIncidentDate(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Approximate Time</label>
                <div className="relative">
                  <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="time"
                    value={incidentTime}
                    onChange={(e) => setIncidentTime(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Platform & Device IP (Standard 2-Column Grid) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Platform / Application Involved
                </label>
                <input
                  type="text"
                  value={platformInvolved}
                  onChange={(e) => setPlatformInvolved(e.target.value)}
                  placeholder="e.g. WhatsApp, Microsoft 365, Instagram, AWS"
                  className="w-full px-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Device IP Address
                </label>
                <div className="relative">
                  <Laptop className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={deviceIp}
                    onChange={(e) => setDeviceIp(e.target.value)}
                    placeholder="e.g. 157.50.140.6"
                    className="w-full pl-9 pr-3 py-2 text-sm font-mono border border-slate-300 rounded-lg bg-slate-50/70 text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Structured Location Fields (City, County / Region, Country) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-semibold text-slate-700">
                  Incident Location (City, County / Region, Country)
                </label>
                {(city || region || country) && (
                  <button
                    type="button"
                    onClick={handleClearLocation}
                    className="text-[11px] font-semibold text-slate-500 hover:text-rose-600 flex items-center gap-1 transition-colors"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Clear Location</span>
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">
                    City <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="e.g. Hyderabad"
                      className="w-full pl-8 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">
                    State / County / Region
                  </label>
                  <input
                    type="text"
                    value={region}
                    onChange={(e) => setRegion(e.target.value)}
                    placeholder="e.g. Telangana"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">
                    Country
                  </label>
                  <div className="relative">
                    <Globe className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      placeholder="e.g. India"
                      className="w-full pl-8 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Detailed Description of the Incident <span className="text-red-500">*</span>
              </label>
              <textarea
                rows={5}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe chronologically what occurred: what message or link you clicked, what credentials or funds were solicited, what alerts you noticed..."
                className="w-full px-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none leading-relaxed"
                required
              />
              <span className="text-[11px] text-slate-400">At least 20 characters describing the event.</span>
            </div>
          </div>
        )}

        {/* STEP 3: SUSPECT & FINANCIAL LOSS */}
        {step === 3 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Step 3: Suspect Information & Financial Loss</h2>
              <p className="text-xs text-slate-500 mt-0.5">Record any adversary identifiers or monetary damages.</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Suspect Information (Email, Phone, IP Address, Telegram handle if known)
              </label>
              <input
                type="text"
                value={suspectInfo}
                onChange={(e) => setSuspectInfo(e.target.value)}
                placeholder="e.g. sender: fraud-support@pay-alert.org, WhatsApp: +44 7911 123456"
                className="w-full px-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Website or URL Involved
              </label>
              <div className="relative">
                <Globe className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="url"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  placeholder="https://example-phishing-login.com"
                  className="w-full pl-9 pr-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-4">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="hasLoss"
                  checked={hasFinancialLoss}
                  onChange={(e) => setHasFinancialLoss(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="hasLoss" className="text-xs font-bold text-slate-800 cursor-pointer">
                  Did this incident cause financial loss or unauthorized wire transfers?
                </label>
              </div>

              {hasFinancialLoss && (
                <div className="pl-6 pt-1 space-y-2">
                  <label className="block text-xs font-semibold text-slate-700">
                    Total Estimated Monetary Loss (USD) <span className="text-red-500">*</span>
                  </label>
                  <div className="relative w-64">
                    <DollarSign className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="number"
                      value={financialLoss}
                      onChange={(e) => setFinancialLoss(e.target.value === '' ? '' : Number(e.target.value))}
                      placeholder="e.g. 5000"
                      className="w-full pl-9 pr-3 py-2 text-sm font-bold border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      min="1"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* STEP 4: EVIDENCE UPLOADS & CONTACT INFO */}
        {step === 4 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Step 4: Digital Evidence & Contact Verification</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Upload screenshots, original email headers (.eml), or documents. Files receive a cryptographic SHA-256 seal.
              </p>
            </div>

            {/* Drag & drop upload zone */}
            <div className="border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-2xl p-6 text-center transition-all bg-slate-50/50">
              <Upload className="w-10 h-10 text-slate-400 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-800">
                Click to browse or drag and drop evidence files here
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                Accepted: PNG, JPG, PDF, EML, TXT, LOG, JSON (Up to 25MB each)
              </p>
              <input
                type="file"
                multiple
                onChange={handleFileUpload}
                className="mt-4 text-xs text-slate-600 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700 cursor-pointer"
              />
            </div>

            {/* Uploaded File List */}
            {files.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-bold text-slate-700">Uploaded Evidence Files ({files.length}):</p>
                <div className="space-y-2">
                  {files.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-white border border-slate-200 flex items-center justify-between shadow-xs"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <FileCheck className="w-5 h-5 text-teal-600 shrink-0" />
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-slate-800 truncate">{item.file.name}</p>
                          <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono truncate">
                            <Fingerprint className="w-3 h-3 text-blue-600 shrink-0" />
                            <span className="truncate">SHA-256: {item.hash}</span>
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFile(idx)}
                        className="p-1 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Contact Verification */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Contact Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  className="w-full px-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Contact Phone (Optional)
                </label>
                <input
                  type="tel"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  className="w-full px-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 5: REVIEW & CONFIRM */}
        {step === 5 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Step 5: Review & Submit Incident</h2>
              <p className="text-xs text-slate-500 mt-0.5">Please review your submission details before dispatching to the triage queue.</p>
            </div>

            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200/80 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <span className="text-slate-500">Incident Category:</span>
                  <p className="font-bold text-slate-900 capitalize">{category.replace(/_/g, ' ')}</p>
                </div>
                <div>
                  <span className="text-slate-500">Title:</span>
                  <p className="font-bold text-slate-900">{title}</p>
                </div>
                <div>
                  <span className="text-slate-500">Occurred On:</span>
                  <p className="font-bold text-slate-900">{incidentDate} at {incidentTime}</p>
                </div>
                <div>
                  <span className="text-slate-500">Platform:</span>
                  <p className="font-bold text-slate-900">{platformInvolved || 'Not specified'}</p>
                </div>
                <div>
                  <span className="text-slate-500">Reported Financial Loss:</span>
                  <p className="font-bold text-slate-900">
                    {hasFinancialLoss ? `$${Number(financialLoss).toLocaleString()}` : 'None'}
                  </p>
                </div>
                <div>
                  <span className="text-slate-500">Attached Evidence Files:</span>
                  <p className="font-bold text-slate-900">{files.length} document(s)</p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200">
                <span className="text-slate-500">Full Description:</span>
                <p className="font-medium text-slate-800 mt-1 whitespace-pre-wrap leading-relaxed">{description}</p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 flex items-start gap-3 text-xs text-blue-800">
              <HelpCircle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                By submitting this complaint, you affirm the accuracy of the provided information. Tampering with or altering digital evidence after submission may impair forensic analysis.
              </p>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          {step > 1 ? (
            <Button type="button" variant="outline" onClick={handleBack} leftIcon={<ArrowLeft className="w-4 h-4" />}>
              Back
            </Button>
          ) : (
            <div></div>
          )}

          {step < 5 ? (
            <Button type="button" variant="primary" onClick={handleNext} rightIcon={<ArrowRight className="w-4 h-4" />}>
              Continue to Step {step + 1}
            </Button>
          ) : (
            <Button
              type="button"
              variant="primary"
              onClick={handleSubmit}
              isLoading={isSubmitting}
              leftIcon={<CheckCircle2 className="w-4 h-4" />}
            >
              Submit Official Complaint
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};
