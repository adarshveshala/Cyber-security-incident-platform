import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ShieldAlert,
  ShieldCheck,
  Lock,
  Mail,
  KeyRound,
  AlertCircle,
  Sparkles,
  UserCheck,
  Activity,
  Cpu,
  Layers,
  ArrowRight
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { useAuth } from '../../context/AuthContext';

export const InvestigatorLogin: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [badgeNumber, setBadgeNumber] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { loginInvestigator } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email || !password) {
      setError('Official email and password credentials are required.');
      return;
    }
    setIsLoading(true);
    try {
      const success = await loginInvestigator(email, password, badgeNumber);
      if (success) {
        navigate('/investigator/soc');
      } else {
        setError('Authentication denied. Please verify your investigator credentials.');
      }
    } catch (err: any) {
      setError(err?.message || 'Access authorization failure.');
    } finally {
      setIsLoading(false);
    }
  };

  const fillInvestigatorDemo = () => {
    setEmail('marcus.vance@sentinelgrid.io');
    setPassword('SpecialAgent#9042');
    setBadgeNumber('SG-INV-8492');
  };

  const fillSeniorLeadDemo = () => {
    setEmail('elena.rostova@sentinelgrid.io');
    setPassword('LeadDetective#1049');
    setBadgeNumber('SG-LEAD-1049');
  };

  return (
    <div className="min-h-screen bg-[#F7FAFC] flex">
      {/* LEFT: Spacious Authentication Form */}
      <div className="flex-1 flex flex-col justify-between py-12 px-6 sm:px-12 lg:px-20 xl:px-24 bg-cyber-grid relative">
        {/* Top Header & Brand */}
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl bg-slate-900 flex items-center justify-center text-white shadow-md group-hover:bg-slate-800 transition-colors">
              <ShieldAlert className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <span className="text-xl font-extrabold tracking-tight text-slate-900">
                SENTINEL<span className="text-blue-600">GRID</span>
              </span>
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">
                SOC Command Center
              </p>
            </div>
          </Link>

          <Link
            to="/civilian/login"
            className="hidden sm:inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-blue-600 px-3 py-1.5 rounded-lg border border-slate-200 hover:border-blue-300 bg-white transition-all shadow-sm"
          >
            <UserCheck className="w-3.5 h-3.5 text-blue-600" />
            Civilian Portal &rarr;
          </Link>
        </div>

        {/* Center Card Content */}
        <div className="max-w-md w-full mx-auto my-10 space-y-8">
          {/* Dual-Role Selector Tabs */}
          <div className="p-1 bg-slate-100 rounded-xl flex items-center gap-1 border border-slate-200">
            <Link
              to="/civilian/login"
              className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg text-slate-600 hover:text-slate-900 hover:bg-white/60 flex items-center justify-center gap-2 transition-all"
            >
              <UserCheck className="w-4 h-4 text-slate-400" />
              Civilian Portal
            </Link>
            <button
              type="button"
              className="flex-1 py-2 px-3 text-xs font-bold rounded-lg bg-slate-900 text-white shadow-sm flex items-center justify-center gap-2"
            >
              <ShieldAlert className="w-4 h-4 text-blue-400" />
              Investigator SOC
            </button>
          </div>

          {/* Heading */}
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-slate-900 text-slate-200">
              Restricted Authority
            </div>
            <h1 className="text-3xl font-extrabold text-[#172554] tracking-tight">
              Investigator Login
            </h1>
            <p className="text-sm text-slate-500">
              Authorized digital forensics, threat triage, and incident response operations.
            </p>
          </div>

          {/* Quick Demo Fill Pills */}
          <div className="space-y-2">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  Lead SOC Investigator
                </div>
                <div className="text-[11px] text-slate-500">marcus.vance@sentinelgrid.io</div>
              </div>
              <button
                type="button"
                onClick={fillInvestigatorDemo}
                className="px-3 py-1.5 text-xs font-bold text-slate-800 bg-white hover:bg-slate-900 hover:text-white rounded-lg border border-slate-300 transition-all shadow-sm"
              >
                Autofill Agent
              </button>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-teal-600" />
                  Senior Lead Detective
                </div>
                <div className="text-[11px] text-slate-500">elena.rostova@sentinelgrid.io</div>
              </div>
              <button
                type="button"
                onClick={fillSeniorLeadDemo}
                className="px-3 py-1.5 text-xs font-bold text-slate-800 bg-white hover:bg-slate-900 hover:text-white rounded-lg border border-slate-300 transition-all shadow-sm"
              >
                Autofill Lead
              </button>
            </div>
          </div>

          {/* Error Banner */}
          {error && (
            <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2.5 text-xs font-medium text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Official Security Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="agent@sentinelgrid.io"
                  className="w-full pl-10 pr-4 py-3 text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-slate-900 focus:border-slate-900 focus:outline-none transition-all shadow-sm"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Badge ID / Credential Token
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={badgeNumber}
                  onChange={(e) => setBadgeNumber(e.target.value)}
                  placeholder="e.g. SG-INV-8492"
                  className="w-full pl-10 pr-4 py-3 text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-slate-900 focus:border-slate-900 focus:outline-none transition-all shadow-sm"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Password
                </label>
                <Link
                  to="/auth/forgot-password"
                  className="text-xs font-semibold text-slate-600 hover:text-slate-900"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-4 py-3 text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-slate-900 focus:border-slate-900 focus:outline-none transition-all shadow-sm"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              variant="primary"
              size="lg"
              className="w-full py-3.5 text-sm font-bold bg-slate-900 hover:bg-slate-800 text-white shadow-md shadow-slate-900/20"
              isLoading={isLoading}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Authenticate & Open SOC
            </Button>
          </form>
        </div>

        {/* Bottom Security Note */}
        <div className="text-center text-[11px] text-slate-400 pt-6">
          Access monitored & logged &bull; Unauthorized access subject to prosecution
        </div>
      </div>

      {/* RIGHT: High-Tech SOC Photography & Visual Telemetry Banner (Desktop) */}
      <div className="hidden lg:block lg:w-1/2 xl:w-7/12 relative overflow-hidden bg-slate-950">
        <img
          src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=1400"
          alt="Security Operations Center"
          className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-luminosity"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/80 to-transparent"></div>

        {/* Floating Content Over Image */}
        <div className="relative h-full flex flex-col justify-between p-12 xl:p-16 text-white">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/20 border border-blue-400/30 text-blue-300 backdrop-blur-md">
              SOC Command & Forensics
            </span>
          </div>

          <div className="space-y-6 max-w-lg">
            <h2 className="text-3xl xl:text-4xl font-extrabold tracking-tight text-white leading-tight">
              Real-time threat triage. <br />
              <span className="text-blue-400">AI-assisted forensic intelligence.</span>
            </h2>

            {/* Visual SOC Metrics */}
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-1">
                <div className="flex items-center gap-2 text-teal-300 font-bold text-sm">
                  <Activity className="w-4 h-4" />
                  Live Triage
                </div>
                <p className="text-xs text-slate-300">
                  Priority incident queues with automated severity scoring.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-1">
                <div className="flex items-center gap-2 text-blue-300 font-bold text-sm">
                  <Cpu className="w-4 h-4" />
                  MITRE ATT&CK
                </div>
                <p className="text-xs text-slate-300">
                  Automated tactic & technique mapping.
                </p>
              </div>
            </div>
          </div>

          <div className="text-xs text-slate-400">
            Sentinel Grid &bull; Incident Response & Digital Forensics
          </div>
        </div>
      </div>
    </div>
  );
};
