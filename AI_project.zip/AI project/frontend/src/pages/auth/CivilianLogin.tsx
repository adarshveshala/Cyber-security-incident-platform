import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ShieldCheck,
  Mail,
  Lock,
  ArrowRight,
  AlertCircle,
  Sparkles,
  ShieldAlert,
  UserCheck,
  CheckCircle2,
  FileCheck
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { useAuth } from '../../context/AuthContext';

export const CivilianLogin: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { loginCivilian } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email || !password) {
      setError('Please enter your email and password.');
      return;
    }
    setIsLoading(true);
    try {
      const success = await loginCivilian(email, password);
      if (success) {
        navigate('/civilian/dashboard');
      } else {
        setError('Invalid email or password.');
      }
    } catch (err: any) {
      setError(err?.message || 'Authentication failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const fillDemo = () => {
    setEmail('sarah.connor@example.com');
    setPassword('CyberSafe@2026');
  };

  return (
    <div className="min-h-screen bg-[#F7FAFC] flex">
      {/* LEFT: Spacious Authentication Form */}
      <div className="flex-1 flex flex-col justify-between py-12 px-6 sm:px-12 lg:px-20 xl:px-24 bg-cyber-grid relative">
        {/* Top Header & Brand */}
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:bg-blue-700 transition-colors">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xl font-extrabold tracking-tight text-slate-900">
                SENTINEL<span className="text-blue-600">GRID</span>
              </span>
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">
                Citizen Cyber Defense
              </p>
            </div>
          </Link>

          <Link
            to="/investigator/login"
            className="hidden sm:inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-blue-600 px-3 py-1.5 rounded-lg border border-slate-200 hover:border-blue-300 bg-white transition-all shadow-sm"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-slate-500" />
            Investigator SOC Access &rarr;
          </Link>
        </div>

        {/* Center Card Content */}
        <div className="max-w-md w-full mx-auto my-10 space-y-8">
          {/* Dual-Role Selector Tabs */}
          <div className="p-1 bg-slate-100 rounded-xl flex items-center gap-1 border border-slate-200">
            <button
              type="button"
              className="flex-1 py-2 px-3 text-xs font-bold rounded-lg bg-white text-blue-700 shadow-sm flex items-center justify-center gap-2"
            >
              <UserCheck className="w-4 h-4 text-blue-600" />
              Civilian Portal
            </button>
            <Link
              to="/investigator/login"
              className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg text-slate-600 hover:text-slate-900 hover:bg-white/60 flex items-center justify-center gap-2 transition-all"
            >
              <ShieldAlert className="w-4 h-4 text-slate-400" />
              Investigator SOC
            </Link>
          </div>

          {/* Heading */}
          <div className="space-y-2">
            <h1 className="text-3xl font-extrabold text-[#172554] tracking-tight">
              Civilian Sign In
            </h1>
            <p className="text-sm text-slate-500">
              Report cyber incidents, upload evidence, and track case progress.
            </p>
          </div>

          {/* Quick Demo Fill Pill */}
          <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-100 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                Demo Complainant Account
              </div>
              <div className="text-[11px] text-blue-700 mt-0.5">sarah.connor@example.com</div>
            </div>
            <button
              type="button"
              onClick={fillDemo}
              className="px-3 py-1.5 text-xs font-bold text-blue-700 bg-white hover:bg-blue-600 hover:text-white rounded-lg border border-blue-200 transition-all shadow-sm"
            >
              1-Click Autofill
            </button>
          </div>

          {/* Error Banner */}
          {error && (
            <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2.5 text-xs font-medium text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-4 py-3 text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition-all shadow-sm"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Password
                </label>
                <Link
                  to="/auth/forgot-password"
                  className="text-xs font-semibold text-blue-600 hover:text-blue-800"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-4 py-3 text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition-all shadow-sm"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              variant="primary"
              size="lg"
              className="w-full py-3.5 text-sm font-bold shadow-md shadow-blue-500/20"
              isLoading={isLoading}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Sign In to Civilian Portal
            </Button>
          </form>

          {/* Registration Link */}
          <div className="text-center pt-2">
            <p className="text-xs text-slate-500">
              Don't have an account?{' '}
              <Link to="/civilian/register" className="font-bold text-blue-600 hover:text-blue-800">
                Register as a Civilian
              </Link>
            </p>
          </div>
        </div>

        {/* Bottom Security Note */}
        <div className="text-center text-[11px] text-slate-400 pt-6">
          Encrypted 256-bit TLS connection &bull; Tamper-evident evidence storage
        </div>
      </div>

      {/* RIGHT: Photography & Visual Trust Banner (Desktop) */}
      <div className="hidden lg:block lg:w-1/2 xl:w-7/12 relative overflow-hidden bg-slate-900">
        <img
          src="https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=1400"
          alt="Cybersecurity Digital Safety"
          className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-luminosity"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#172554] via-blue-950/80 to-transparent"></div>

        {/* Floating Content Over Image */}
        <div className="relative h-full flex flex-col justify-between p-12 xl:p-16 text-white">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/20 border border-blue-400/30 text-blue-200 backdrop-blur-md">
              Civilian Protection Network
            </span>
          </div>

          <div className="space-y-6 max-w-lg">
            <h2 className="text-3xl xl:text-4xl font-extrabold tracking-tight text-white leading-tight">
              Report threats safely. <br />
              <span className="text-blue-400">Track real investigative progress.</span>
            </h2>

            {/* Visual Trust Indicators */}
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-1">
                <div className="flex items-center gap-2 text-teal-300 font-bold text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  Encrypted Evidence
                </div>
                <p className="text-xs text-slate-300">
                  Tamper-evident chain of custody.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-1">
                <div className="flex items-center gap-2 text-blue-300 font-bold text-sm">
                  <FileCheck className="w-4 h-4" />
                  Direct Messaging
                </div>
                <p className="text-xs text-slate-300">
                  Secure channel with assigned detectives.
                </p>
              </div>
            </div>
          </div>

          <div className="text-xs text-slate-400">
            Sentinel Grid &bull; Official Incident Intake & Community Defense
          </div>
        </div>
      </div>
    </div>
  );
};
