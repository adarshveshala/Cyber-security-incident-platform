import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ShieldCheck,
  Mail,
  Lock,
  User,
  Phone,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  UserCheck,
  Cpu,
  Check
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { useAuth } from '../../context/AuthContext';
import { AVATAR_PRESETS, getDefaultAvatar } from '../../utils/avatars';

export const CivilianRegister: React.FC = () => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [gender, setGender] = useState<'female' | 'male' | 'other'>('female');
  const [avatarUrl, setAvatarUrl] = useState<string>(getDefaultAvatar('female'));
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { registerCivilian } = useAuth();
  const navigate = useNavigate();

  const handleGenderChange = (newGender: 'female' | 'male' | 'other') => {
    setGender(newGender);
    setAvatarUrl(getDefaultAvatar(newGender));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (password.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }

    setIsLoading(true);
    try {
      const success = await registerCivilian({
        full_name: fullName,
        email,
        phone,
        password,
        gender,
        avatar_url: avatarUrl,
      });
      if (success) {
        navigate('/civilian/dashboard');
      } else {
        setError('Registration could not be completed.');
      }
    } catch (err: any) {
      setError(err?.message || 'Registration failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const fillDemo = () => {
    setFullName('Alex Mercer');
    setEmail(`alex.mercer.${Math.floor(Math.random() * 9000 + 1000)}@example.org`);
    setPhone('+1 (555) 349-8812');
    setPassword('CyberGuard#2026');
    setConfirmPassword('CyberGuard#2026');
    setGender('female');
    setAvatarUrl(getDefaultAvatar('female'));
  };

  return (
    <div className="min-h-screen bg-[#F7FAFC] flex">
      {/* LEFT: Spacious Authentication Form */}
      <div className="flex-1 flex flex-col justify-between py-12 px-6 sm:px-12 lg:px-20 xl:px-24 bg-cyber-grid relative">
        {/* Top Header & Brand */}
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:bg-blue-700 transition-colors">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xl font-extrabold tracking-tight text-slate-900">
                SENTINEL<span className="text-blue-600">GRID</span>
              </span>
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">
                Citizen Cyber Defense
              </p>
            </div>
          </Link>

          <Link
            to="/investigator/login"
            className="hidden sm:inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-blue-600 px-3 py-1.5 rounded-lg border border-slate-200 hover:border-blue-300 bg-white transition-all shadow-sm"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-slate-500" />
            Investigator Access &rarr;
          </Link>
        </div>

        {/* Center Card Content */}
        <div className="max-w-md w-full mx-auto my-8 space-y-6">
          {/* Dual-Role Selector Tabs */}
          <div className="p-1 bg-slate-100 rounded-xl flex items-center gap-1 border border-slate-200">
            <button
              type="button"
              className="flex-1 py-2 px-3 text-xs font-bold rounded-lg bg-white text-blue-700 shadow-sm flex items-center justify-center gap-2"
            >
              <UserCheck className="w-4 h-4 text-blue-600" />
              Civilian Registration
            </button>
            <Link
              to="/investigator/login"
              className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg text-slate-600 hover:text-slate-900 hover:bg-white/60 flex items-center justify-center gap-2 transition-all"
            >
              <ShieldAlert className="w-4 h-4 text-slate-400" />
              Investigator SOC
            </Link>
          </div>

          {/* Heading */}
          <div className="space-y-1.5">
            <h1 className="text-3xl font-extrabold text-[#172554] tracking-tight">
              Create Account
            </h1>
            <p className="text-sm text-slate-500">
              Submit incidents and receive verified updates from cyber investigators.
            </p>
          </div>

          {/* Quick Demo Fill Pill */}
          <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-100 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                Quick Test Registration
              </div>
              <div className="text-[11px] text-blue-700 mt-0.5">Pre-fill valid citizen details</div>
            </div>
            <button
              type="button"
              onClick={fillDemo}
              className="px-3 py-1.5 text-xs font-bold text-blue-700 bg-white hover:bg-blue-600 hover:text-white rounded-lg border border-blue-200 transition-all shadow-sm"
            >
              1-Click Autofill
            </button>
          </div>

          {/* Error Banner */}
          {error && (
            <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2.5 text-xs font-medium text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Full Name
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Alex Mercer"
                  className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition-all shadow-sm"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition-all shadow-sm"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Phone (Optional)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 (555) 000-0000"
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition-all shadow-sm"
                  />
                </div>
              </div>
            </div>

            {/* Choose Gender & Default Non-Human Vector Avatar */}
            <div className="space-y-2.5 p-3.5 bg-slate-50/80 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Gender & Profile Avatar
                </label>
                <span className="text-[10px] text-blue-700 font-bold bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  Non-Human Graphic
                </span>
              </div>

              {/* Gender selector */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => handleGenderChange('female')}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all flex items-center justify-center gap-1.5 ${
                    gender === 'female'
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <User className="w-3.5 h-3.5" />
                  <span>Female</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleGenderChange('male')}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all flex items-center justify-center gap-1.5 ${
                    gender === 'male'
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <User className="w-3.5 h-3.5" />
                  <span>Male</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleGenderChange('other')}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all flex items-center justify-center gap-1.5 ${
                    gender === 'other'
                      ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Cpu className="w-3.5 h-3.5" />
                  <span>Emblem</span>
                </button>
              </div>

              {/* Avatar options preview */}
              <div className="flex items-center gap-2 pt-1 overflow-x-auto pb-1">
                {AVATAR_PRESETS.filter((p) => p.gender === gender).map((preset) => {
                  const isSelected = avatarUrl === preset.url;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => setAvatarUrl(preset.url)}
                      className={`relative p-1 rounded-xl border-2 transition-all shrink-0 ${
                        isSelected
                          ? 'border-blue-600 ring-2 ring-blue-500/20 bg-blue-50/50'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                      title={preset.name}
                    >
                      <img
                        src={preset.url}
                        alt={preset.name}
                        className="w-10 h-10 rounded-lg object-cover"
                      />
                      {isSelected && (
                        <span className="absolute -top-1 -right-1 p-0.5 bg-blue-600 text-white rounded-full">
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="8+ characters"
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition-all shadow-sm"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition-all shadow-sm"
                    required
                  />
                </div>
              </div>
            </div>

            <Button
              type="submit"
              variant="primary"
              size="lg"
              className="w-full py-3.5 text-sm font-bold shadow-md shadow-blue-500/20"
              isLoading={isLoading}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Create Civilian Account
            </Button>
          </form>

          {/* Login Link */}
          <div className="text-center pt-2">
            <p className="text-xs text-slate-500">
              Already have an account?{' '}
              <Link to="/civilian/login" className="font-bold text-blue-600 hover:text-blue-800">
                Sign In
              </Link>
            </p>
          </div>
        </div>

        {/* Bottom Security Note */}
        <div className="text-center text-[11px] text-slate-400 pt-6">
          Encrypted 256-bit TLS connection &bull; Protected under national cyber defense guidelines
        </div>
      </div>

      {/* RIGHT: Photography & Visual Trust Banner (Desktop) */}
      <div className="hidden lg:block lg:w-1/2 xl:w-7/12 relative overflow-hidden bg-slate-900">
        <img
          src="https://images.unsplash.com/photo-1614064641938-3bbee52942c7?auto=format&fit=crop&q=80&w=1400"
          alt="Digital Biometric Trust"
          className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-luminosity"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#172554] via-blue-950/80 to-transparent"></div>

        {/* Floating Content Over Image */}
        <div className="relative h-full flex flex-col justify-between p-12 xl:p-16 text-white">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/20 border border-blue-400/30 text-blue-200 backdrop-blur-md">
              Verified Citizen Enrollment
            </span>
          </div>

          <div className="space-y-6 max-w-lg">
            <h2 className="text-3xl xl:text-4xl font-extrabold tracking-tight text-white leading-tight">
              One account. <br />
              <span className="text-blue-400">Total digital safety and assistance.</span>
            </h2>

            {/* Visual Trust Indicators */}
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-1">
                <div className="flex items-center gap-2 text-teal-300 font-bold text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  Free Citizen Access
                </div>
                <p className="text-xs text-slate-300">
                  Zero cost reporting and guidance.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-1">
                <div className="flex items-center gap-2 text-blue-300 font-bold text-sm">
                  <ShieldCheck className="w-4 h-4" />
                  Privacy First
                </div>
                <p className="text-xs text-slate-300">
                  Zero unauthorized data sharing.
                </p>
              </div>
            </div>
          </div>

          <div className="text-xs text-slate-400">
            Sentinel Grid &bull; Official Incident Intake & Community Defense
          </div>
        </div>
      </div>
    </div>
  );
};
