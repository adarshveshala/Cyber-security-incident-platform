import React from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  ShieldAlert,
  FilePlus,
  FileText,
  MessageSquare,
  Bell,
  Sparkles,
  BookOpen,
  User,
  Settings,
  Activity,
  ListFilter,
  Briefcase,
  Layers,
  Globe2,
  FolderArchive,
  BellRing,
  BarChart3,
  FileSpreadsheet,
  Users,
  History,
  LogOut,
  ChevronRight,
  ShieldCheck,
  PanelLeftClose,
  PanelLeftOpen,
  X,
  Menu
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import { getDefaultAvatar } from '../../utils/avatars';

interface SidebarProps {
  portal: 'civilian' | 'investigator';
  isOpen?: boolean;
  onToggle?: () => void;
  onClose?: () => void;
}

interface NavItem {
  label: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
  highlight?: boolean;
  badge?: string;
  badgeCount?: number;
  ai?: boolean;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  portal,
  isOpen = true,
  onToggle,
  onClose,
}) => {
  const { user, logout } = useAuth();
  const { unreadNotificationCount } = useSocket();
  const navigate = useNavigate();

  const handleSignOut = () => {
    logout();
    if (portal === 'civilian') {
      navigate('/civilian/login');
    } else {
      navigate('/investigator/login');
    }
  };

  const civilianSections: NavSection[] = [
    {
      title: 'Reporting & Cases',
      items: [
        { label: 'Dashboard', path: '/civilian/dashboard', icon: LayoutDashboard },
        { label: 'Report Incident', path: '/civilian/report', icon: FilePlus, highlight: true },
        { label: 'My Complaints', path: '/civilian/complaints', icon: FileText, badge: '2 Active' },
      ],
    },
    {
      title: 'Assistance & Safety',
      items: [
        { label: 'Messages', path: '/civilian/messages', icon: MessageSquare, badge: '1 New' },
        { label: 'Notifications', path: '/civilian/notifications', icon: Bell, badgeCount: unreadNotificationCount },
        { label: 'AI Security Assistant', path: '/civilian/ai-assistant', icon: Sparkles, ai: true },
        { label: 'Cyber Safety Center', path: '/civilian/safety-center', icon: BookOpen },
      ],
    },
    {
      title: 'Account',
      items: [
        { label: 'Profile', path: '/civilian/profile', icon: User },
        { label: 'Settings', path: '/civilian/settings', icon: Settings },
      ],
    },
  ];

  const investigatorSections: NavSection[] = [
    {
      title: 'Operations',
      items: [
        { label: 'SOC Overview', path: '/investigator/soc', icon: Activity },
        { label: 'Incident Queue', path: '/investigator/queue', icon: ListFilter, badge: '3 New' },
        { label: 'My Investigations', path: '/investigator/my-cases', icon: Briefcase, badge: '2 Active' },
        { label: 'All Incidents', path: '/investigator/incidents', icon: Layers },
      ],
    },
    {
      title: 'Intelligence & Forensics',
      items: [
        { label: 'Threat Intelligence', path: '/investigator/threat-intel', icon: Globe2 },
        { label: 'AI Copilot', path: '/investigator/copilot', icon: Sparkles, ai: true },
        { label: 'Evidence Management', path: '/investigator/evidence', icon: FolderArchive },
        { label: 'Messages', path: '/investigator/messages', icon: MessageSquare },
      ],
    },
    {
      title: 'Management & Audit',
      items: [
        { label: 'Security Alerts', path: '/investigator/alerts', icon: BellRing, badge: '4 Raw' },
        { label: 'Analytics', path: '/investigator/analytics', icon: BarChart3 },
        { label: 'Reports', path: '/investigator/reports', icon: FileSpreadsheet },
        { label: 'Team Management', path: '/investigator/team', icon: Users },
        { label: 'Audit Logs', path: '/investigator/audit', icon: History },
        { label: 'Settings', path: '/investigator/settings', icon: Settings },
      ],
    },
  ];

  const sections = portal === 'civilian' ? civilianSections : investigatorSections;
  const userAvatar = user?.avatar_url || getDefaultAvatar(user?.gender, user?.role);

  return (
    <>
      {/* Mobile Backdrop when sidebar is open */}
      <div
        className={`fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 md:hidden transition-opacity duration-300 ${
          isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Sidebar Container */}
      <aside
        className={`fixed md:sticky top-0 h-screen z-50 md:z-20 bg-white border-r border-slate-200 flex flex-col shrink-0 overflow-y-auto transition-all duration-300 ease-in-out ${
          isOpen
            ? 'w-64 translate-x-0'
            : '-translate-x-full md:translate-x-0 md:w-20'
        }`}
      >
        {/* Brand Header & Toggle Button */}
        <div className={`p-4 border-b border-slate-100 flex items-center justify-between ${!isOpen ? 'md:justify-center' : ''}`}>
          <Link to="/" className="flex items-center gap-3 group min-w-0" onClick={onClose}>
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-sm group-hover:bg-blue-700 transition-colors shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            {isOpen && (
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-base font-extrabold tracking-tight text-slate-900">
                    SENTINEL<span className="text-blue-600">GRID</span>
                  </span>
                </div>
                <p className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase truncate">
                  {portal === 'civilian' ? 'Civilian Portal' : 'Investigator SOC'}
                </p>
              </div>
            )}
          </Link>

          {/* Close/Toggle button */}
          {onToggle && (
            <button
              type="button"
              onClick={onToggle}
              className={`p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors ${
                !isOpen ? 'hidden' : ''
              }`}
              title={isOpen ? 'Collapse sidebar' : 'Open sidebar'}
            >
              <PanelLeftClose className="w-4 h-4 hidden md:block" />
              <X className="w-5 h-5 md:hidden" />
            </button>
          )}

          {/* When collapsed on desktop, show a small expand button */}
          {!isOpen && onToggle && (
            <button
              type="button"
              onClick={onToggle}
              className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-slate-100 transition-colors hidden md:block mt-2"
              title="Open sidebar"
            >
              <PanelLeftOpen className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Navigation list */}
        <div className="p-3 flex-1 space-y-4">
          {sections.map((sec, secIdx) => (
            <div key={secIdx} className="space-y-1">
              {isOpen ? (
                <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {sec.title}
                </div>
              ) : (
                <div className="hidden md:block h-px bg-slate-100 my-2 mx-2" />
              )}

              {sec.items.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    onClick={() => {
                      if (window.innerWidth < 768 && onClose) {
                        onClose();
                      }
                    }}
                    title={!isOpen ? item.label : undefined}
                    className={({ isActive }) =>
                      `flex items-center ${isOpen ? 'justify-between px-3' : 'justify-center px-2'} py-2 text-xs font-medium rounded-xl transition-all ${
                        isActive
                          ? 'bg-blue-50 text-blue-700 font-bold shadow-xs border border-blue-200/70'
                          : item.highlight
                          ? 'text-blue-600 bg-blue-50/40 hover:bg-blue-50 font-semibold'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                      }`
                    }
                  >
                    <div className={`flex items-center ${isOpen ? 'gap-2.5' : 'justify-center'} min-w-0`}>
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          item.ai ? 'text-teal-600' : item.highlight ? 'text-blue-600' : 'text-slate-400'
                        }`}
                      />
                      {isOpen && <span className="truncate">{item.label}</span>}
                    </div>

                    {isOpen && (
                      <div className="flex items-center gap-1 shrink-0">
                        {item.badge && (
                          <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-slate-100 text-slate-600 rounded">
                            {item.badge}
                          </span>
                        )}
                        {item.badgeCount && item.badgeCount > 0 ? (
                          <span className="px-1.5 py-0.5 text-[10px] font-bold bg-blue-600 text-white rounded-full">
                            {item.badgeCount}
                          </span>
                        ) : null}
                        {item.ai && (
                          <span className="px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider bg-teal-50 text-teal-700 rounded border border-teal-200">
                            AI
                          </span>
                        )}
                      </div>
                    )}
                  </NavLink>
                );
              })}
            </div>
          ))}
        </div>

        {/* User profile footer & Sign Out Button */}
        <div className="p-3 border-t border-slate-100 bg-slate-50/50">
          {isOpen ? (
            <div className="p-2.5 rounded-xl bg-white border border-slate-200/80 shadow-xs mb-2 flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <img
                  src={userAvatar}
                  alt={user?.full_name || 'User'}
                  className="w-9 h-9 rounded-xl object-cover border border-slate-200 shadow-xs shrink-0"
                />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 truncate">{user?.full_name || 'User Account'}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
                    <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider truncate">
                      {user?.role?.replace('_', ' ') || 'Civilian'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="hidden md:flex justify-center mb-2">
              <img
                src={userAvatar}
                alt={user?.full_name || 'User'}
                className="w-9 h-9 rounded-xl object-cover border border-slate-200 shadow-xs"
                title={user?.full_name || 'User Account'}
              />
            </div>
          )}

          <button
            type="button"
            onClick={handleSignOut}
            className={`w-full flex items-center ${isOpen ? 'justify-center gap-2 px-3' : 'justify-center px-2'} py-2 text-xs font-semibold text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors border border-slate-200/80 bg-white shadow-xs`}
            title="Sign Out"
          >
            <LogOut className="w-4 h-4 text-slate-500 group-hover:text-red-600" />
            {isOpen && <span>Sign Out</span>}
          </button>
        </div>
      </aside>
    </>
  );
};
