import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldAlert, ShieldCheck, UserCheck, Lock, ArrowRight, Menu, X } from 'lucide-react';
import { Button } from './Button';
import { useAuth } from '../../context/AuthContext';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Tagline */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:bg-blue-700 transition-colors">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-extrabold tracking-tight text-slate-900">
                  SENTINEL<span className="text-blue-600 font-bold">GRID</span>
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 rounded-md border border-blue-200/60">
                  v2.4
                </span>
              </div>
              <p className="text-[11px] font-medium text-slate-500 uppercase tracking-widest -mt-0.5">
                Report. Investigate. Protect.
              </p>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#overview" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">
              Overview
            </a>
            <a href="#how-it-works" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">
              How It Works
            </a>
            <a href="#features" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">
              Features
            </a>
            <a href="#ai-copilot" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">
              AI Intelligence
            </a>
            <a href="#safety-center" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">
              Safety Center
            </a>
          </nav>

          {/* Action CTAs */}
          <div className="hidden lg:flex items-center gap-3">
            {user ? (
              <Button
                variant="primary"
                onClick={() => {
                  if (user.role === 'civilian') navigate('/civilian/dashboard');
                  else navigate('/investigator/soc');
                }}
                rightIcon={<ArrowRight className="w-4 h-4" />}
              >
                Go to {user.role === 'civilian' ? 'Civilian Portal' : 'Investigator SOC'}
              </Button>
            ) : (
              <>
                <Link to="/investigator/login">
                  <Button variant="outline" size="sm" leftIcon={<Lock className="w-3.5 h-3.5 text-slate-500" />}>
                    Investigator Login
                  </Button>
                </Link>
                <Link to="/civilian/login">
                  <Button variant="secondary" size="sm" leftIcon={<UserCheck className="w-3.5 h-3.5 text-blue-600" />}>
                    Civilian Sign In
                  </Button>
                </Link>
                <Link to="/civilian/report">
                  <Button variant="primary" size="sm" leftIcon={<ShieldCheck className="w-4 h-4" />}>
                    Report a Cybercrime
                  </Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu trigger */}
          <div className="flex md:hidden items-center gap-2">
            <Link to="/civilian/report">
              <Button variant="primary" size="sm">
                Report
              </Button>
            </Link>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3">
          <div className="grid grid-cols-1 gap-2 pt-2">
            <a
              href="#overview"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 rounded-lg"
            >
              Overview
            </a>
            <a
              href="#how-it-works"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 rounded-lg"
            >
              How It Works
            </a>
            <a
              href="#features"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 rounded-lg"
            >
              Features
            </a>
            <a
              href="#ai-copilot"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 rounded-lg"
            >
              AI Copilot
            </a>
            <a
              href="#safety-center"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 rounded-lg"
            >
              Safety Center
            </a>
          </div>
          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            <Link to="/civilian/report" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="primary" className="w-full">
                Report a Cybercrime
              </Button>
            </Link>
            <Link to="/civilian/login" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="secondary" className="w-full">
                Civilian Portal
              </Button>
            </Link>
            <Link to="/investigator/login" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="outline" className="w-full">
                Investigator Portal
              </Button>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};
