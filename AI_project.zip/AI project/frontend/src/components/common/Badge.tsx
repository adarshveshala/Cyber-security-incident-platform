import React from 'react';
import { IncidentSeverity, IncidentStatus } from '../../types';

interface BadgeProps {
  children?: React.ReactNode;
  variant?: 'severity' | 'status' | 'default' | 'role' | 'category';
  severity?: IncidentSeverity;
  status?: IncidentStatus;
  className?: string;
  size?: 'sm' | 'md';
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'default',
  severity,
  status,
  className = '',
  size = 'md',
}) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs font-medium' : 'px-2.5 py-1 text-xs font-semibold';

  if (variant === 'severity' || severity) {
    const sev = severity || (children as IncidentSeverity);
    switch (sev) {
      case 'critical':
        return (
          <span className={`inline-flex items-center gap-1.5 rounded-full bg-red-50 text-red-700 border border-red-200 ${sizeClasses} ${className}`}>
            <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse"></span>
            Critical
          </span>
        );
      case 'high':
        return (
          <span className={`inline-flex items-center gap-1.5 rounded-full bg-orange-50 text-orange-700 border border-orange-200 ${sizeClasses} ${className}`}>
            <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
            High
          </span>
        );
      case 'medium':
        return (
          <span className={`inline-flex items-center gap-1.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200 ${sizeClasses} ${className}`}>
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            Medium
          </span>
        );
      case 'low':
      default:
        return (
          <span className={`inline-flex items-center gap-1.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 ${sizeClasses} ${className}`}>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            Low
          </span>
        );
    }
  }

  if (variant === 'status' || status) {
    const st = status || (children as IncidentStatus);
    switch (st) {
      case 'submitted':
        return (
          <span className={`inline-flex items-center rounded-full bg-blue-50 text-blue-700 border border-blue-200 ${sizeClasses} ${className}`}>
            Submitted
          </span>
        );
      case 'under_review':
        return (
          <span className={`inline-flex items-center rounded-full bg-amber-50 text-amber-700 border border-amber-200 ${sizeClasses} ${className}`}>
            Under Review
          </span>
        );
      case 'assigned':
        return (
          <span className={`inline-flex items-center rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 ${sizeClasses} ${className}`}>
            Assigned
          </span>
        );
      case 'investigation_in_progress':
        return (
          <span className={`inline-flex items-center rounded-full bg-teal-50 text-teal-700 border border-teal-200 ${sizeClasses} ${className}`}>
            In Progress
          </span>
        );
      case 'additional_info_required':
        return (
          <span className={`inline-flex items-center rounded-full bg-purple-50 text-purple-700 border border-purple-200 ${sizeClasses} ${className}`}>
            Info Required
          </span>
        );
      case 'resolved':
        return (
          <span className={`inline-flex items-center rounded-full bg-green-50 text-green-700 border border-green-200 ${sizeClasses} ${className}`}>
            Resolved
          </span>
        );
      case 'closed':
        return (
          <span className={`inline-flex items-center rounded-full bg-slate-100 text-slate-700 border border-slate-200 ${sizeClasses} ${className}`}>
            Closed
          </span>
        );
      default:
        return (
          <span className={`inline-flex items-center rounded-full bg-slate-100 text-slate-700 ${sizeClasses} ${className}`}>
            {children}
          </span>
        );
    }
  }

  return (
    <span className={`inline-flex items-center rounded-full bg-slate-100 text-slate-700 border border-slate-200 ${sizeClasses} ${className}`}>
      {children}
    </span>
  );
};
