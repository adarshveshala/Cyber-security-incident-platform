import React, { useState } from 'react';
import { Check, Shield, Sparkles, User, ShieldCheck, Cpu } from 'lucide-react';
import { AVATAR_PRESETS, AvatarPreset, getDefaultAvatar } from '../../utils/avatars';
import { useAuth } from '../../context/AuthContext';
import { Button } from './Button';

interface AvatarSelectorProps {
  onSelected?: (url: string, gender: 'female' | 'male' | 'other') => void;
  compact?: boolean;
}

export const AvatarSelector: React.FC<AvatarSelectorProps> = ({ onSelected, compact = false }) => {
  const { user, updateUserAvatar } = useAuth();
  const [selectedGender, setSelectedGender] = useState<'female' | 'male' | 'other'>(
    user?.gender || (user?.role === 'civilian' ? 'female' : 'male')
  );
  const [currentAvatarUrl, setCurrentAvatarUrl] = useState<string>(
    user?.avatar_url || getDefaultAvatar(user?.gender, user?.role)
  );
  const [savedFeedback, setSavedFeedback] = useState(false);

  // Filter avatars based on gender tab
  const filteredAvatars = AVATAR_PRESETS.filter((p) => p.gender === selectedGender);

  const handleSelectAvatar = (preset: AvatarPreset) => {
    setCurrentAvatarUrl(preset.url);
    if (onSelected) {
      onSelected(preset.url, preset.gender);
    }
  };

  const handleApply = () => {
    updateUserAvatar(currentAvatarUrl, selectedGender);
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 2500);
  };

  const selectedPreset = AVATAR_PRESETS.find((p) => p.url === currentAvatarUrl) || filteredAvatars[0];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-5 sm:p-6 space-y-5">
      {/* Header & OpSec Notice */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-900">
              Choose Profile Picture
            </h3>
            <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
              Non-Human Avatars
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Choose your profile illustration according to gender or select a cyber defense emblem.
          </p>
        </div>

        {/* Live Active Preview */}
        <div className="flex items-center gap-3 p-2 px-3 bg-slate-50 rounded-xl border border-slate-200">
          <img
            src={currentAvatarUrl}
            alt="Active Avatar"
            className="w-10 h-10 rounded-xl object-cover border border-slate-200 shadow-xs"
          />
          <div className="text-left">
            <div className="text-xs font-bold text-slate-900 truncate max-w-[140px]">
              {selectedPreset ? selectedPreset.name.split(' (')[0] : 'Active Avatar'}
            </div>
            <div className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Selected
            </div>
          </div>
        </div>
      </div>

      {/* Gender Selection Tabs */}
      <div className="space-y-2">
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
          1. Choose Gender Category
        </label>
        <div className="grid grid-cols-3 gap-2 p-1.5 bg-slate-100/80 rounded-xl border border-slate-200/80">
          <button
            type="button"
            onClick={() => {
              setSelectedGender('female');
              const firstFemale = AVATAR_PRESETS.find((p) => p.gender === 'female');
              if (firstFemale) handleSelectAvatar(firstFemale);
            }}
            className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              selectedGender === 'female'
                ? 'bg-white text-blue-700 shadow-sm border border-blue-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-3.5 h-3.5 text-blue-600" />
            <span>Female</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setSelectedGender('male');
              const firstMale = AVATAR_PRESETS.find((p) => p.gender === 'male');
              if (firstMale) handleSelectAvatar(firstMale);
            }}
            className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              selectedGender === 'male'
                ? 'bg-white text-blue-700 shadow-sm border border-blue-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-3.5 h-3.5 text-blue-600" />
            <span>Male</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setSelectedGender('other');
              const firstBot = AVATAR_PRESETS.find((p) => p.gender === 'other');
              if (firstBot) handleSelectAvatar(firstBot);
            }}
            className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              selectedGender === 'other'
                ? 'bg-white text-teal-700 shadow-sm border border-teal-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Cpu className="w-3.5 h-3.5 text-teal-600" />
            <span>Cyber Emblems</span>
          </button>
        </div>
      </div>

      {/* Avatar Presets Grid */}
      <div className="space-y-2">
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
          2. Select Default Vector Graphic
        </label>
        <div className={`grid ${compact ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-2 sm:grid-cols-4'} gap-3`}>
          {filteredAvatars.map((preset) => {
            const isSelected = currentAvatarUrl === preset.url;
            return (
              <div
                key={preset.id}
                onClick={() => handleSelectAvatar(preset)}
                className={`relative p-3 rounded-2xl border-2 cursor-pointer transition-all text-center flex flex-col items-center gap-2 group ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/40 shadow-sm ring-2 ring-blue-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50'
                }`}
              >
                {isSelected && (
                  <span className="absolute top-2 right-2 p-1 bg-blue-600 text-white rounded-full shadow-xs">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </span>
                )}

                <div className="relative">
                  <img
                    src={preset.url}
                    alt={preset.name}
                    className="w-16 h-16 rounded-2xl object-cover shadow-xs group-hover:scale-105 transition-transform"
                  />
                </div>

                <div className="w-full">
                  <div className="text-xs font-bold text-slate-900 truncate">
                    {preset.name.split(' (')[0]}
                  </div>
                  <span className="inline-block mt-1 text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200/60 truncate max-w-full">
                    {preset.roleTag}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Apply / Save Button & Confirmation */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-100">
        <div className="text-xs text-slate-500 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Vector graphics render crisply offline and safeguard identity.</span>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          {savedFeedback && (
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 flex items-center gap-1">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              Avatar Applied!
            </span>
          )}
          <Button
            type="button"
            variant="primary"
            onClick={handleApply}
            className="w-full sm:w-auto shadow-sm"
          >
            Set as Active Avatar
          </Button>
        </div>
      </div>
    </div>
  );
};
