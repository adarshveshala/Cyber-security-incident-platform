import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Bell,
  Search,
  CheckCircle2,
  AlertTriangle,
  Radio,
  ExternalLink,
  ChevronDown,
  UserCheck,
  Shield,
  UserCog,
  Check,
  ShieldCheck,
  ShieldAlert,
  Sparkles,
  Menu,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import { UserRole } from '../../types';
import { getDefaultAvatar } from '../../utils/avatars';

interface HeaderProps {
  portal: 'civilian' | 'investigator';
  onToggleSidebar?: () => void;
  isSidebarOpen?: boolean;
}

export const Header: React.FC<HeaderProps> = ({ portal, onToggleSidebar, isSidebarOpen }) => {
  const { user, switchDemoUser } = useAuth();
  const { notifications, unreadNotificationCount, markNotificationAsRead, markAllNotificationsAsRead, isConnected } = useSocket();
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [roleSwitcherOpen, setRoleSwitcherOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    if (portal === 'civilian') {
      navigate(`/civilian/complaints?q=${encodeURIComponent(searchQuery)}`);
    } else {
      navigate(`/investigator/incidents?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const isCivilian = portal === 'civilian';
  const avatarUrl = user?.avatar_url || getDefaultAvatar(user?.gender, user?.role);

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30 shadow-xs">
      <div className="flex items-center gap-2.5 sm:gap-3">
        {onToggleSidebar && (
          <button
            type="button"
            onClick={onToggleSidebar}
            className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 transition-colors shadow-2xs"
            title={isSidebarOpen ? 'Collapse sidebar' : 'Open sidebar'}
          >
            <Menu className="w-4 h-4" />
          </button>
        )}

        {/* Search Input */}
        <form onSubmit={handleSearch} className="relative w-48 sm:w-72 md:w-80 lg:w-96">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={portal === 'civilian' ? 'Search complaints...' : 'Search IOCs, incidents...'}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all shadow-xs"
          />
        </form>
      </div>

      {/* Right Toolbar */}
      <div className="flex items-center gap-3">
        {/* Live Socket Status Indicator */}
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] font-semibold text-emerald-700">
          <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-red-400'}`}></span>
          <span>{isConnected ? 'Live' : 'Reconnecting'}</span>
        </div>

        {/* Demo Role Switcher Dropdown */}
        <div className="relative">
          <button
            onClick={() => setRoleSwitcherOpen(!roleSwitcherOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 shadow-xs transition-colors"
            title="Switch demo persona"
          >
            <Shield className="w-3.5 h-3.5 text-blue-600" />
            <span className="hidden md:inline">Role:</span>
            <span className="capitalize text-blue-700">{user?.role?.replace('_', ' ') || 'Civilian'}</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {roleSwitcherOpen && (
            <div className="absolute right-0 mt-2 w-60 rounded-2xl bg-white shadow-xl border border-slate-200 py-1.5 z-50">
              <div className="px-3.5 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 flex items-center justify-between">
                <span>Switch Test Persona</span>
                <Sparkles className="w-3 h-3 text-blue-500" />
              </div>
              {[
                { role: 'civilian' as UserRole, label: 'Civilian (Sarah Connor)', desc: 'Victim reporting & tracking' },
                { role: 'investigator' as UserRole, label: 'Investigator (Agent Vance)', desc: 'SOC forensics & triage' },
                { role: 'senior_investigator' as UserRole, label: 'Senior Lead (Det. Rostova)', desc: 'Escalations & oversight' },
                { role: 'admin' as UserRole, label: 'Administrator (Dir. Sterling)', desc: 'System governance & logs' },
              ].map((item) => (
                <button
                  key={item.role}
                  onClick={() => {
                    switchDemoUser(item.role);
                    setRoleSwitcherOpen(false);
                    if (item.role === 'civilian') {
                      navigate('/civilian/dashboard');
                    } else {
                      navigate('/investigator/soc');
                    }
                  }}
                  className={`w-full text-left px-3.5 py-2.5 text-xs hover:bg-slate-50 flex items-center justify-between transition-colors ${
                    user?.role === item.role ? 'bg-blue-50/70 text-blue-700 font-semibold' : 'text-slate-700'
                  }`}
                >
                  <div>
                    <div className="font-semibold text-slate-800">{item.label}</div>
                    <div className="text-[10px] text-slate-400">{item.desc}</div>
                  </div>
                  {user?.role === item.role && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Notifications Popover */}
        <div className="relative">
          <button
            onClick={() => setNotificationOpen(!notificationOpen)}
            className="relative p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors border border-slate-200 bg-white"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationCount > 0 && (
              <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-blue-600 border-2 border-white"></span>
            )}
          </button>

          {notificationOpen && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-white shadow-2xl border border-slate-200 py-2 z-50">
              <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Notifications</h4>
                  {unreadNotificationCount > 0 && (
                    <span className="px-1.5 py-0.5 text-[10px] font-bold bg-blue-100 text-blue-700 rounded-full">
                      {unreadNotificationCount} unread
                    </span>
                  )}
                </div>
                {unreadNotificationCount > 0 && (
                  <button
                    onClick={markAllNotificationsAsRead}
                    className="text-[11px] font-medium text-blue-600 hover:text-blue-800"
                  >
                    Mark all read
                  </button>
                )}
              </div>

              <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-500">No notifications yet.</div>
                ) : (
                  notifications.slice(0, 5).map((n) => (
                    <div
                      key={n.id}
                      onClick={() => markNotificationAsRead(n.id)}
                      className={`p-3 text-xs hover:bg-slate-50 cursor-pointer transition-colors ${
                        !n.is_read ? 'bg-blue-50/40' : ''
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <p className={`font-semibold ${!n.is_read ? 'text-slate-900' : 'text-slate-700'}`}>
                          {n.title}
                        </p>
                        <span className="text-[10px] text-slate-400 whitespace-nowrap">
                          {new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-slate-600 mt-1 line-clamp-2 leading-relaxed">{n.message}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Identity Chip with Photo Avatar */}
        <div className="flex items-center gap-2.5 pl-2 border-l border-slate-200">
          <div className="relative">
            <img
              src={avatarUrl}
              alt={user?.full_name || 'User'}
              className="w-9 h-9 rounded-xl object-cover border border-slate-200 shadow-xs"
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white"></span>
          </div>
          <div className="hidden lg:block text-left">
            <div className="text-xs font-bold text-slate-900 leading-tight">
              {user?.full_name || (isCivilian ? 'Sarah Connor' : 'Marcus Vance')}
            </div>
            <div className="text-[10px] font-semibold text-blue-600 uppercase tracking-wider">
              {user?.role?.replace('_', ' ') || (isCivilian ? 'Civilian' : 'Investigator')}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
