import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import L from 'leaflet';
import {
  Globe2,
  ShieldAlert,
  Search,
  Filter,
  Maximize2,
  Minimize2,
  RotateCcw,
  Layers,
  MapPin,
  Clock,
  UserCheck,
  AlertTriangle,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  Activity,
  ShieldCheck,
  SlidersHorizontal,
  Compass
} from 'lucide-react';
import { Incident, IncidentSeverity, IncidentCategory, IncidentStatus } from '../../types';
import { getDefaultAvatar } from '../../utils/avatars';

interface GeospatialIncidentMapProps {
  incidents: Incident[];
  onSelectIncident?: (incident: Incident) => void;
  className?: string;
}

// Map Tile Layers (100% Free, No Watermark, No API Key Required)
const TILE_LAYERS = {
  osm: {
    name: 'OpenStreetMap Standard',
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 19,
    subdomains: 'abc',
  },
  esri_light: {
    name: 'SOC Clean Canvas',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}',
    attribution: 'Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ',
    maxZoom: 16,
    subdomains: '',
  },
  esri_dark: {
    name: 'SOC Tactical Dark',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}',
    attribution: 'Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ',
    maxZoom: 16,
    subdomains: '',
  },
};

const SEVERITY_COLORS: Record<IncidentSeverity, { bg: string; border: string; glow: string; text: string; pin: string }> = {
  critical: { bg: '#DC2626', border: '#991B1B', glow: 'rgba(220, 38, 38, 0.4)', text: 'text-red-700', pin: '#EF4444' },
  high: { bg: '#F97316', border: '#C2410C', glow: 'rgba(249, 115, 22, 0.35)', text: 'text-orange-700', pin: '#F97316' },
  medium: { bg: '#F59E0B', border: '#B45309', glow: 'rgba(245, 158, 11, 0.3)', text: 'text-amber-700', pin: '#F59E0B' },
  low: { bg: '#10B981', border: '#047857', glow: 'rgba(16, 185, 129, 0.3)', text: 'text-emerald-700', pin: '#10B981' },
};

export const GeospatialIncidentMap: React.FC<GeospatialIncidentMapProps> = ({
  incidents,
  onSelectIncident,
  className = '',
}) => {
  const navigate = useNavigate();
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  // Filter States
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeLayer, setActiveLayer] = useState<keyof typeof TILE_LAYERS>('osm');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [showDrawer, setShowDrawer] = useState<boolean>(true);

  // Filtered incidents with valid coordinates
  const mappedIncidents = useMemo(() => {
    return incidents.filter((inc) => {
      // Check valid coordinates
      const hasCoords = typeof inc.latitude === 'number' && typeof inc.longitude === 'number' &&
        !isNaN(inc.latitude) && !isNaN(inc.longitude);
      if (!hasCoords) return false;

      // Severity filter
      if (severityFilter !== 'all' && inc.severity !== severityFilter) return false;

      // Category filter
      if (categoryFilter !== 'all' && inc.category !== categoryFilter) return false;

      // Status filter
      if (statusFilter !== 'all' && inc.status !== statusFilter) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesId = inc.complaint_id.toLowerCase().includes(q);
        const matchesTitle = inc.title.toLowerCase().includes(q);
        const matchesLoc = (inc.location_name || '').toLowerCase().includes(q);
        const matchesCiv = inc.civilian_name.toLowerCase().includes(q);
        const matchesIp = (inc.reporter_ip || '').toLowerCase().includes(q);
        const matchesCity = (inc.city || '').toLowerCase().includes(q);
        const matchesCountry = (inc.country || '').toLowerCase().includes(q);
        const matchesInvestigator = (inc.assigned_investigator_name || '').toLowerCase().includes(q);
        if (!matchesId && !matchesTitle && !matchesLoc && !matchesCiv && !matchesIp && !matchesCity && !matchesCountry && !matchesInvestigator) {
          return false;
        }
      }

      return true;
    });
  }, [incidents, severityFilter, categoryFilter, statusFilter, searchQuery]);

  // Unmapped incidents
  const unmappedCount = useMemo(() => {
    return incidents.filter(
      (inc) => typeof inc.latitude !== 'number' || typeof inc.longitude !== 'number' || isNaN(inc.latitude) || isNaN(inc.longitude)
    ).length;
  }, [incidents]);

  // Telemetry counts
  const telemetry = useMemo(() => {
    const criticals = mappedIncidents.filter((i) => i.severity === 'critical').length;
    const highs = mappedIncidents.filter((i) => i.severity === 'high').length;
    const active = mappedIncidents.filter(
      (i) => i.status === 'investigation_in_progress' || i.status === 'assigned'
    ).length;

    // Determine highest density region
    const regionCounts: Record<string, number> = {};
    mappedIncidents.forEach((i) => {
      if (i.location_name) {
        const parts = i.location_name.split(',');
        const countryOrRegion = parts[parts.length - 1]?.trim() || i.location_name;
        regionCounts[countryOrRegion] = (regionCounts[countryOrRegion] || 0) + 1;
      }
    });

    let topRegion = 'Global Fleet';
    let maxCount = 0;
    Object.entries(regionCounts).forEach(([reg, cnt]) => {
      if (cnt > maxCount) {
        maxCount = cnt;
        topRegion = reg;
      }
    });

    return {
      totalMapped: mappedIncidents.length,
      criticalCount: criticals,
      highCount: highs,
      activeCount: active,
      topRegion: `${topRegion} (${maxCount})`,
    };
  }, [mappedIncidents]);

  // 1. Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    // Initialize map centered at global view
    const map = L.map(mapContainerRef.current, {
      center: [25, 10],
      zoom: 2.3,
      minZoom: 2,
      maxZoom: 18,
      zoomControl: false,
      worldCopyJump: true,
      attributionControl: true,
    });

    // Add zoom controls at top-right
    L.control.zoom({ position: 'topright' }).addTo(map);

    // Initial tile layer
    const tileConfig = TILE_LAYERS[activeLayer];
    const tiles = L.tileLayer(tileConfig.url, {
      attribution: tileConfig.attribution,
      maxZoom: tileConfig.maxZoom || 19,
      subdomains: tileConfig.subdomains || 'abc',
    }).addTo(map);

    const markersGroup = L.layerGroup().addTo(map);

    tileLayerRef.current = tiles;
    markersLayerRef.current = markersGroup;
    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // 2. Handle Tile Layer Switcher
  useEffect(() => {
    if (!mapInstanceRef.current || !tileLayerRef.current) return;

    const tileConfig = TILE_LAYERS[activeLayer];
    mapInstanceRef.current.removeLayer(tileLayerRef.current);

    const newTiles = L.tileLayer(tileConfig.url, {
      attribution: tileConfig.attribution,
      maxZoom: tileConfig.maxZoom || 19,
      subdomains: tileConfig.subdomains || 'abc',
    }).addTo(mapInstanceRef.current);

    tileLayerRef.current = newTiles;
  }, [activeLayer]);

  // 3. Render Markers & Popups
  useEffect(() => {
    if (!mapInstanceRef.current || !markersLayerRef.current) return;

    markersLayerRef.current.clearLayers();

    mappedIncidents.forEach((inc) => {
      const lat = inc.latitude!;
      const lng = inc.longitude!;
      const conf = SEVERITY_COLORS[inc.severity] || SEVERITY_COLORS.low;

      // Pulse animation for critical/high
      const isUrgent = inc.severity === 'critical' || inc.severity === 'high';
      const pulseHtml = isUrgent
        ? `<span class="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style="background-color: ${conf.bg}"></span>`
        : '';

      const markerHtml = `
        <div class="relative flex items-center justify-center cursor-pointer group" style="width: 36px; height: 36px;">
          ${pulseHtml}
          <div class="relative flex items-center justify-center w-8 h-8 rounded-full shadow-lg border-2 border-white transition-transform duration-200 group-hover:scale-125" style="background: ${conf.bg}; box-shadow: 0 0 14px ${conf.glow}">
            <svg class="w-4 h-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
          </div>
          <span class="absolute -bottom-1 w-2 h-2 rounded-full bg-slate-900 border border-white"></span>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'sentinel-marker-icon',
        html: markerHtml,
        iconSize: [36, 36],
        iconAnchor: [18, 32],
        popupAnchor: [0, -32],
      });

      const marker = L.marker([lat, lng], { icon: customIcon });

      // Severity badge colors
      const sevBadgeStyles: Record<IncidentSeverity, string> = {
        critical: 'background-color: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5;',
        high: 'background-color: #FFEDD5; color: #9A3412; border: 1px solid #FDBA74;',
        medium: 'background-color: #FEF3C7; color: #92400E; border: 1px solid #FCD34D;',
        low: 'background-color: #D1FAE5; color: #065F46; border: 1px solid #6EE7B7;',
      };

      const statusBadgeStyles: Record<string, string> = {
        investigation_in_progress: 'background-color: #E0E7FF; color: #3730A3;',
        assigned: 'background-color: #DBEAFE; color: #1E40AF;',
        submitted: 'background-color: #F1F5F9; color: #475569;',
        under_review: 'background-color: #FEF3C7; color: #92400E;',
        resolved: 'background-color: #D1FAE5; color: #065F46;',
        closed: 'background-color: #F3F4F6; color: #4B5563;',
      };

      const investigatorAvatar = getDefaultAvatar('male', 'investigator');
      const investigatorName = inc.assigned_investigator_name || 'Unassigned (In Triage Queue)';

      // Formatted category name
      const categoryLabel = inc.category.replace(/_/g, ' ').toUpperCase();
      const statusLabel = inc.status.replace(/_/g, ' ').toUpperCase();

      // Premium Popup HTML
      const popupContent = `
        <div style="font-family: inherit; width: 280px; padding: 2px;">
          <!-- Header Bar -->
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; border-bottom: 1px solid #F1F5F9; padding-bottom: 6px;">
            <span style="font-family: monospace; font-size: 11px; font-weight: 700; color: #1D4ED8; background-color: #EFF6FF; padding: 2px 8px; border-radius: 6px; border: 1px solid #BFDBFE;">
              ${inc.complaint_id}
            </span>
            <span style="font-size: 10px; font-weight: 700; padding: 2px 7px; border-radius: 9999px; text-transform: uppercase; ${sevBadgeStyles[inc.severity]}">
              ${inc.severity}
            </span>
          </div>

          <!-- Title -->
          <h4 style="font-size: 13px; font-weight: 800; color: #0F172A; margin: 0 0 6px 0; line-height: 1.3;">
            ${inc.title}
          </h4>

          <!-- Category & Status -->
          <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 10px;">
            <span style="font-size: 10px; font-weight: 600; color: #334155; background-color: #F8FAFC; padding: 2px 6px; border-radius: 4px; border: 1px solid #E2E8F0;">
              ${categoryLabel}
            </span>
            <span style="font-size: 10px; font-weight: 600; padding: 2px 6px; border-radius: 4px; ${statusBadgeStyles[inc.status] || ''}">
              ${statusLabel}
            </span>
          </div>

          <!-- Metadata Grid -->
          <div style="font-size: 11px; color: #64748B; display: grid; gap: 5px; margin-bottom: 12px; background-color: #F8FAFC; padding: 8px 10px; border-radius: 8px; border: 1px solid #E2E8F0;">
            <div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 6px;">
              <span style="color: #94A3B8; shrink-0;">📍 Location:</span>
              <strong style="color: #1E293B; text-align: right; word-break: break-word;">${inc.location_name || 'Coordinates Plotted'}</strong>
            </div>
            ${inc.reporter_ip ? `
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 6px;">
              <span style="color: #94A3B8;">🌐 Device IP:</span>
              <span style="color: #0F172A; font-family: monospace; font-size: 10px; font-weight: 700; background-color: #E2E8F0; padding: 1px 6px; border-radius: 4px;">
                ${inc.reporter_ip}
              </span>
            </div>` : ''}
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 6px;">
              <span style="color: #94A3B8;">🎯 Lat / Lng:</span>
              <span style="color: #475569; font-family: monospace; font-size: 10px;">
                ${inc.latitude !== undefined ? inc.latitude.toFixed(4) : ''}°, ${inc.longitude !== undefined ? inc.longitude.toFixed(4) : ''}°
              </span>
            </div>
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 6px;">
              <span style="color: #94A3B8;">🕒 Reported:</span>
              <span style="color: #1E293B;">${inc.incident_date} ${inc.incident_time || ''}</span>
            </div>
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 6px; border-top: 1px dashed #E2E8F0; padding-top: 4px; margin-top: 2px;">
              <span style="color: #94A3B8;">🕵️ Officer:</span>
              <span style="color: #0F172A; font-weight: 600;">${investigatorName}</span>
            </div>
          </div>

          <!-- Full Case CTA Button -->
          <button 
            id="view-case-btn-${inc.id}"
            style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 6px; background-color: #0F172A; color: #FFFFFF; font-size: 12px; font-weight: 700; padding: 7px 12px; border-radius: 8px; border: none; cursor: pointer; transition: background-color 0.15s ease;"
            onmouseover="this.style.backgroundColor='#1E293B'"
            onmouseout="this.style.backgroundColor='#0F172A'"
          >
            <span>View Full Case</span>
            <svg style="width: 13px; height: 13px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
          </button>
        </div>
      `;

      marker.bindPopup(popupContent, {
        maxWidth: 300,
        className: 'sentinel-popup',
      });

      // Marker click handles
      marker.on('click', () => {
        setSelectedIncident(inc);
        if (onSelectIncident) onSelectIncident(inc);
      });

      marker.on('popupopen', () => {
        // Attach click event for navigation
        const btn = document.getElementById(`view-case-btn-${inc.id}`);
        if (btn) {
          btn.onclick = (e) => {
            e.stopPropagation();
            navigate(`/investigator/incidents/${inc.id}`);
          };
        }
      });

      markersLayerRef.current?.addLayer(marker);
    });
  }, [mappedIncidents, navigate, onSelectIncident]);

  // Reset view to world center
  const handleResetView = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([25, 10], 2.3, { animate: true });
    }
  };

  // Fly to incident marker
  const handleFocusIncident = (inc: Incident) => {
    setSelectedIncident(inc);
    if (inc.latitude && inc.longitude && mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([inc.latitude, inc.longitude], 10, {
        animate: true,
        duration: 1.2,
      });

      // Find marker in layer and open popup
      markersLayerRef.current?.eachLayer((layer: any) => {
        if (layer.getLatLng && layer.getLatLng().lat === inc.latitude && layer.getLatLng().lng === inc.longitude) {
          layer.openPopup();
        }
      });
    }
  };

  // Toggle Fullscreen on map container
  const handleToggleFullscreen = () => {
    const el = mapContainerRef.current?.parentElement;
    if (!el) return;

    if (!document.fullscreenElement) {
      el.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  return (
    <div className={`bg-white rounded-3xl border border-slate-200/90 shadow-md overflow-hidden relative ${className}`}>
      {/* 1. SECTION TITLE & LIVE TELEMETRY BAR */}
      <div className="p-6 pb-4 border-b border-slate-100 flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-white via-slate-50/50 to-white">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase tracking-wider bg-blue-100 text-blue-800 border border-blue-200">
              <Globe2 className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
              GIS Operations Center
            </span>
            <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              Live Threat Ingestion Active
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-[#172554] tracking-tight flex items-center gap-2">
            GEOSPATIAL INCIDENT INTELLIGENCE
          </h2>
          <p className="text-xs text-slate-500">
            Real-time geospatial distribution, threat clusters, and cross-border incident correlation across active jurisdictions.
          </p>
        </div>

        {/* Telemetry Metric Pills */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-slate-900 text-white flex items-center gap-2 shadow-sm">
            <MapPin className="w-4 h-4 text-blue-400" />
            <div>
              <div className="text-[10px] text-slate-400 font-semibold uppercase leading-none">Mapped Cases</div>
              <div className="text-sm font-black leading-tight text-white">{telemetry.totalMapped} Active</div>
            </div>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-red-50 border border-red-200 text-red-800 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-600" />
            <div>
              <div className="text-[10px] text-red-600 font-semibold uppercase leading-none">Critical Hotspots</div>
              <div className="text-sm font-black leading-tight text-red-700">{telemetry.criticalCount} Outbreaks</div>
            </div>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-600" />
            <div>
              <div className="text-[10px] text-amber-600 font-semibold uppercase leading-none">Top Region</div>
              <div className="text-sm font-black leading-tight text-amber-900">{telemetry.topRegion}</div>
            </div>
          </div>

          {unmappedCount > 0 && (
            <div className="px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 flex items-center gap-1.5 text-xs font-medium">
              <span className="w-2 h-2 rounded-full bg-slate-400"></span>
              <span>{unmappedCount} Unmapped (Pending Geo)</span>
            </div>
          )}
        </div>
      </div>

      {/* 2. ADVANCED SOC MAP CONTROL TOOLBAR */}
      <div className="px-6 py-3 bg-slate-50/80 border-b border-slate-200/80 flex flex-wrap items-center justify-between gap-3">
        {/* Severity Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-1 flex items-center gap-1">
            <SlidersHorizontal className="w-3.5 h-3.5" /> Severity:
          </span>
          {[
            { id: 'all', label: 'All Severities', color: 'bg-slate-200 text-slate-800' },
            { id: 'critical', label: 'Critical', color: 'bg-red-500 text-white' },
            { id: 'high', label: 'High', color: 'bg-orange-500 text-white' },
            { id: 'medium', label: 'Medium', color: 'bg-amber-500 text-white' },
            { id: 'low', label: 'Low', color: 'bg-emerald-500 text-white' },
          ].map((sev) => {
            const isSelected = severityFilter === sev.id;
            return (
              <button
                key={sev.id}
                onClick={() => setSeverityFilter(sev.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  isSelected
                    ? `${sev.color} shadow-sm ring-2 ring-offset-1 ring-slate-400`
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {sev.label}
              </button>
            );
          })}
        </div>

        {/* Dropdowns, Search, and Map Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Category Dropdown */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="text-xs font-medium bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer shadow-sm"
          >
            <option value="all">All Categories</option>
            <option value="financial_fraud">Financial Fraud</option>
            <option value="phishing">Phishing & Spoofing</option>
            <option value="account_hacking">Account Takeover</option>
            <option value="malware">Ransomware & Malware</option>
            <option value="identity_theft">Identity Theft</option>
            <option value="impersonation">Impersonation</option>
            <option value="data_breach">Data Breach</option>
            <option value="other">Other / Cyber Attacks</option>
          </select>

          {/* Status Dropdown */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs font-medium bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer shadow-sm"
          >
            <option value="all">All Statuses</option>
            <option value="submitted">Submitted</option>
            <option value="under_review">Under Review</option>
            <option value="assigned">Assigned</option>
            <option value="investigation_in_progress">In Progress</option>
            <option value="resolved">Resolved</option>
          </select>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Filter by city, ID, title..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="text-xs bg-white border border-slate-200 rounded-lg pl-8 pr-2.5 py-1.5 text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 w-44 sm:w-56 shadow-sm"
            />
          </div>

          {/* Map Layer Switcher */}
          <div className="flex items-center rounded-lg border border-slate-200 bg-white p-0.5 shadow-sm">
            {(Object.keys(TILE_LAYERS) as Array<keyof typeof TILE_LAYERS>).map((key) => (
              <button
                key={key}
                onClick={() => setActiveLayer(key)}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-md transition-colors ${
                  activeLayer === key
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title={TILE_LAYERS[key].name}
              >
                {key === 'osm' ? 'OSM Standard' : key === 'esri_light' ? 'SOC Canvas' : 'Tactical Dark'}
              </button>
            ))}
          </div>

          {/* Reset View */}
          <button
            onClick={handleResetView}
            className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 shadow-sm"
            title="Reset Map Center"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={handleToggleFullscreen}
            className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 shadow-sm"
            title="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* 3. MAP CANVAS & INCIDENT DISPATCH DRAWER */}
      <div className="relative grid grid-cols-1 lg:grid-cols-12 h-[520px] sm:h-[600px] w-full bg-slate-100">
        {/* Leaflet Map Canvas */}
        <div
          ref={mapContainerRef}
          className={`${showDrawer ? 'lg:col-span-8' : 'lg:col-span-12'} h-full w-full z-0 transition-all duration-300`}
          style={{ minHeight: '100%' }}
        />

        {/* Toggle Drawer Button (Floating on map edge) */}
        <button
          onClick={() => setShowDrawer(!showDrawer)}
          className="hidden lg:flex absolute right-4 top-4 z-[400] bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-200 shadow-md text-xs font-bold text-slate-800 hover:bg-slate-50 items-center gap-1.5 transition-all"
        >
          <Layers className="w-3.5 h-3.5 text-blue-600" />
          <span>{showDrawer ? 'Hide Incident List' : 'Show Mapped List'}</span>
        </button>

        {/* Right Side: Quick Geo-Targeting Incident Drawer */}
        {showDrawer && (
          <div className="lg:col-span-4 h-full border-t lg:border-t-0 lg:border-l border-slate-200 bg-white flex flex-col z-10 overflow-hidden shadow-inner">
            <div className="p-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <Compass className="w-4 h-4 text-blue-600" />
                  Active Geo Targets ({mappedIncidents.length})
                </h3>
                <p className="text-[11px] text-slate-500">Click to fly and inspect coordinates</p>
              </div>
              <span className="text-[10px] font-mono font-bold bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-200">
                L-RADAR
              </span>
            </div>

            {/* Scrollable Incidents List */}
            <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
              {mappedIncidents.length === 0 ? (
                <div className="p-8 text-center text-slate-400 space-y-2">
                  <AlertTriangle className="w-8 h-8 mx-auto text-amber-400" />
                  <p className="text-xs font-semibold">No incidents match the active filter criteria.</p>
                  <button
                    onClick={() => {
                      setSeverityFilter('all');
                      setCategoryFilter('all');
                      setStatusFilter('all');
                      setSearchQuery('');
                    }}
                    className="text-xs text-blue-600 font-bold hover:underline"
                  >
                    Clear Filters
                  </button>
                </div>
              ) : (
                mappedIncidents.map((inc) => {
                  const conf = SEVERITY_COLORS[inc.severity] || SEVERITY_COLORS.low;
                  const isSelected = selectedIncident?.id === inc.id;

                  return (
                    <div
                      key={inc.id}
                      onClick={() => handleFocusIncident(inc)}
                      className={`p-3.5 cursor-pointer transition-all hover:bg-slate-50 space-y-1.5 ${
                        isSelected ? 'bg-blue-50/70 border-l-4 border-blue-600' : ''
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1.5">
                        <div className="flex items-center gap-1.5">
                          <span
                            className="w-2.5 h-2.5 rounded-full shrink-0"
                            style={{ backgroundColor: conf.bg }}
                          />
                          <span className="font-mono text-xs font-bold text-slate-800">
                            {inc.complaint_id}
                          </span>
                        </div>
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full`}
                          style={{
                            backgroundColor: `${conf.bg}15`,
                            color: conf.bg,
                            border: `1px solid ${conf.bg}30`,
                          }}
                        >
                          {inc.severity}
                        </span>
                      </div>

                      <h4 className="text-xs font-bold text-slate-900 line-clamp-1 hover:text-blue-600">
                        {inc.title}
                      </h4>

                      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5 gap-1.5">
                        <span className="flex items-center gap-1 font-medium truncate max-w-[150px]">
                          <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                          <span className="truncate">{inc.location_name || 'Mapped Node'}</span>
                        </span>
                        {inc.reporter_ip && (
                          <span className="font-mono text-[10px] text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 shrink-0" title="Device IP">
                            {inc.reporter_ip}
                          </span>
                        )}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/investigator/incidents/${inc.id}`);
                          }}
                          className="text-[11px] font-bold text-blue-600 hover:text-blue-800 flex items-center gap-0.5 shrink-0"
                        >
                          <span>Case</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Bottom Target Card if Selected */}
            {selectedIncident && (
              <div className="p-3 bg-slate-900 text-white border-t border-slate-800 flex items-center justify-between gap-3">
                <div className="space-y-0.5 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Focused Coordinate</span>
                    {selectedIncident.reporter_ip && (
                      <span className="font-mono text-[10px] text-emerald-400 font-bold bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">
                        IP: {selectedIncident.reporter_ip}
                      </span>
                    )}
                  </div>
                  <div className="text-xs font-bold text-white truncate">
                    {selectedIncident.complaint_id} - {selectedIncident.location_name || selectedIncident.title}
                  </div>
                </div>
                <button
                  onClick={() => navigate(`/investigator/incidents/${selectedIncident.id}`)}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shrink-0 flex items-center gap-1 shadow-sm"
                >
                  <span>Open</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 4. FOOTER STATUS BAR */}
      <div className="px-6 py-2.5 bg-white border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-3">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
            <strong>Critical</strong>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span>
            <strong>High</strong>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <strong>Medium</strong>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <strong>Low</strong>
          </span>
        </div>
        <div className="text-[11px] text-slate-400">
          Showing <strong className="text-slate-700">{mappedIncidents.length}</strong> of{' '}
          <strong className="text-slate-700">{incidents.length}</strong> total incidents with active coordinates.
        </div>
      </div>
    </div>
  );
};
