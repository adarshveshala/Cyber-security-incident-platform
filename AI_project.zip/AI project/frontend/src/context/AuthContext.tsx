import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { AVATAR_PRESETS, getDefaultAvatar } from '../utils/avatars';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  loginCivilian: (email: string, password: string) => Promise<boolean>;
  loginInvestigator: (email: string, password: string, badgeNumber?: string) => Promise<boolean>;
  registerCivilian: (data: { full_name: string; email: string; phone?: string; password: string; gender?: 'female' | 'male' | 'other'; avatar_url?: string }) => Promise<boolean>;
  logout: () => void;
  switchDemoUser: (role: UserRole) => void;
  updateUserAvatar: (avatarUrl: string, gender?: 'female' | 'male' | 'other') => void;
  updateUserProfile: (data: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEMO_USERS: Record<UserRole, User> = {
  civilian: {
    id: 'usr-civ-001',
    email: 'sarah.connor@example.com',
    full_name: 'Sarah Connor',
    phone: '+1 (555) 234-5678',
    gender: 'female',
    role: 'civilian',
    is_active: true,
    is_verified: true,
    created_at: '2026-01-15T09:00:00Z',
    avatar_url: AVATAR_PRESETS[0].url, // Defender Sarah (Cyber Visor)
  },
  investigator: {
    id: 'usr-inv-101',
    email: 'marcus.vance@sentinelgrid.io',
    full_name: 'Special Agent Marcus Vance',
    gender: 'male',
    role: 'investigator',
    badge_number: 'SG-INV-8492',
    department: 'Cyber Fraud & Ransomware Unit',
    organization_name: 'National Cyber Command Task Force',
    is_active: true,
    is_verified: true,
    created_at: '2025-08-10T08:30:00Z',
    avatar_url: AVATAR_PRESETS[4].url, // Agent Marcus (Tactical)
  },
  senior_investigator: {
    id: 'usr-inv-202',
    email: 'elena.rostova@sentinelgrid.io',
    full_name: 'Lead Detective Elena Rostova',
    gender: 'female',
    role: 'senior_investigator',
    badge_number: 'SG-LEAD-1049',
    department: 'Advanced Threat Triage & Incident Response',
    organization_name: 'National Cyber Command Task Force',
    is_active: true,
    is_verified: true,
    created_at: '2024-03-20T11:00:00Z',
    avatar_url: AVATAR_PRESETS[1].url, // Detective Elena
  },
  admin: {
    id: 'usr-adm-999',
    email: 'admin@sentinelgrid.io',
    full_name: 'Director David Sterling',
    gender: 'male',
    role: 'admin',
    badge_number: 'SG-DIR-0001',
    department: 'Platform Administration & Security Operations',
    organization_name: 'National Cyber Command Task Force',
    is_active: true,
    is_verified: true,
    created_at: '2023-01-01T00:00:00Z',
    avatar_url: AVATAR_PRESETS[5].url, // Director Sterling (Command)
  },
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check localStorage on mount
    try {
      const storedUser = localStorage.getItem('sentinel_user');
      const storedToken = localStorage.getItem('sentinel_token');
      if (storedUser && storedToken) {
        const parsed = JSON.parse(storedUser);
        // Automatically sanitize any legacy cached unsplash human photo to the non-human vector avatar
        if (!parsed.avatar_url || parsed.avatar_url.includes('unsplash.com')) {
          parsed.avatar_url = getDefaultAvatar(parsed.gender, parsed.role);
          localStorage.setItem('sentinel_user', JSON.stringify(parsed));
        }
        setUser(parsed);
        setToken(storedToken);
      }
    } catch (e) {
      console.error('Failed to parse auth token', e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const loginCivilian = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      // 1. Try real backend authentication
      try {
        const res = await fetch('/api/v1/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        });
        if (res.ok) {
          const authData = await res.json();
          const loggedUser: User = {
            id: authData.user_id,
            email: email.toLowerCase(),
            full_name: authData.full_name || email.split('@')[0],
            gender: 'female',
            role: 'civilian',
            is_active: true,
            is_verified: true,
            created_at: new Date().toISOString(),
            avatar_url: getDefaultAvatar('female', 'civilian'),
          };
          setUser(loggedUser);
          setToken(authData.access_token);
          localStorage.setItem('sentinel_user', JSON.stringify(loggedUser));
          localStorage.setItem('sentinel_token', authData.access_token);
          return true;
        }
      } catch (err) {
        console.warn('Backend login unavailable, evaluating demo user mode:', err);
      }

      // 2. Demo User Fallback
      if (email.toLowerCase().includes('sarah') || email.toLowerCase() === 'sarah.connor@example.com') {
        const sarah = DEMO_USERS.civilian;
        const fakeJwt = `demo-civ.${Date.now()}`;
        setUser(sarah);
        setToken(fakeJwt);
        localStorage.setItem('sentinel_user', JSON.stringify(sarah));
        localStorage.setItem('sentinel_token', fakeJwt);
        return true;
      }

      // 3. Unique Civilian User (Ensures new accounts start completely empty!)
      const emailHash = Math.abs(email.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0)).toString(36);
      const uniqueCivId = `usr-civ-${emailHash}`;
      const loggedUser: User = {
        id: uniqueCivId,
        email: email.toLowerCase(),
        full_name: email.split('@')[0].replace('.', ' ').replace(/^./, (str) => str.toUpperCase()),
        gender: 'female',
        role: 'civilian',
        is_active: true,
        is_verified: true,
        created_at: new Date().toISOString(),
        avatar_url: getDefaultAvatar('female', 'civilian'),
      };
      const fakeJwt = `custom-civ.${uniqueCivId}.${Date.now()}`;
      setUser(loggedUser);
      setToken(fakeJwt);
      localStorage.setItem('sentinel_user', JSON.stringify(loggedUser));
      localStorage.setItem('sentinel_token', fakeJwt);
      return true;
    } finally {
      setIsLoading(false);
    }
  };

  const loginInvestigator = async (email: string, password?: string, _badgeNumber?: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      // 1. Try real backend authentication
      try {
        const defaultInvPassword = email.includes('elena')
          ? 'LeadDetective#1049'
          : email.includes('admin')
          ? 'AdminRoot#999'
          : 'SpecialAgent#9042';

        const res = await fetch('/api/v1/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: email.toLowerCase(), password: password || defaultInvPassword }),
        });
        if (res.ok) {
          const authData = await res.json();
          const role = (authData.role as UserRole) || 'investigator';
          const loggedUser: User = {
            id: authData.user_id,
            email: email.toLowerCase(),
            full_name: authData.full_name || email.split('@')[0],
            gender: email.includes('elena') ? 'female' : 'male',
            role,
            is_active: true,
            is_verified: true,
            created_at: new Date().toISOString(),
            avatar_url: getDefaultAvatar(email.includes('elena') ? 'female' : 'male', role),
            badge_number: _badgeNumber || (role === 'admin' ? 'SG-DIR-0001' : role === 'senior_investigator' ? 'SG-LEAD-1049' : 'SG-INV-8492'),
            department: role === 'admin' ? 'Platform Administration & Security Operations' : role === 'senior_investigator' ? 'Advanced Threat Triage & Incident Response' : 'Cyber Fraud & Ransomware Unit',
            organization_name: 'National Cyber Command Task Force',
          };
          setUser(loggedUser);
          setToken(authData.access_token);
          localStorage.setItem('sentinel_user', JSON.stringify(loggedUser));
          localStorage.setItem('sentinel_token', authData.access_token);
          return true;
        }
      } catch (err) {
        console.warn('Backend login unavailable, evaluating demo user mode:', err);
      }

      // 2. Fallback demo user
      let loggedUser: User = DEMO_USERS.investigator;
      if (email.includes('admin')) {
        loggedUser = DEMO_USERS.admin;
      } else if (email.includes('lead') || email.includes('elena') || email.includes('senior')) {
        loggedUser = DEMO_USERS.senior_investigator;
      } else {
        loggedUser = DEMO_USERS.investigator;
      }
      const fakeJwt = `demo-inv.${Date.now()}`;
      setUser(loggedUser);
      setToken(fakeJwt);
      localStorage.setItem('sentinel_user', JSON.stringify(loggedUser));
      localStorage.setItem('sentinel_token', fakeJwt);
      return true;
    } finally {
      setIsLoading(false);
    }
  };

  const registerCivilian = async (data: {
    full_name: string;
    email: string;
    phone?: string;
    password: string;
    gender?: 'female' | 'male' | 'other';
    avatar_url?: string;
  }): Promise<boolean> => {
    setIsLoading(true);
    try {
      const chosenGender = data.gender || 'female';
      const chosenAvatar = data.avatar_url || getDefaultAvatar(chosenGender);

      // 1. Try real backend user registration into SQLite database
      try {
        const res = await fetch('/api/v1/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            full_name: data.full_name,
            email: data.email.toLowerCase(),
            phone: data.phone || '+1 (555) 000-0000',
            password: data.password,
            avatar_url: chosenAvatar,
          }),
        });
        if (res.ok) {
          const authData = await res.json();
          const newUser: User = {
            id: authData.user_id,
            email: data.email.toLowerCase(),
            full_name: data.full_name,
            phone: data.phone,
            gender: chosenGender,
            role: 'civilian',
            is_active: true,
            is_verified: true,
            created_at: new Date().toISOString(),
            avatar_url: chosenAvatar,
          };
          setUser(newUser);
          setToken(authData.access_token);
          localStorage.setItem('sentinel_user', JSON.stringify(newUser));
          localStorage.setItem('sentinel_token', authData.access_token);
          return true;
        } else {
          let errorMsg = 'Registration rejected by backend database.';
          try {
            const errData = await res.json();
            if (typeof errData.detail === 'string') {
              errorMsg = errData.detail;
            } else if (Array.isArray(errData.detail)) {
              errorMsg = errData.detail.map((e: any) => e.msg || e.message).join(' | ');
            } else if (errData.message) {
              errorMsg = errData.message;
            }
          } catch {
            if (res.status === 400 || res.status === 409) {
              errorMsg = 'An account with this email address already exists. Please sign in instead.';
            } else if (res.status === 502 || res.status === 503 || res.status === 504) {
              errorMsg = 'Backend server is temporarily starting up. Please try again in a few seconds.';
            }
          }
          throw new Error(errorMsg);
        }
      } catch (err: any) {
        if (err?.message && !err.message.includes('Failed to fetch') && !err.message.includes('NetworkError')) {
          throw err;
        }
        console.warn('Backend /auth/register unavailable, registering locally:', err);
      }

      // 2. Local fallback with unique non-shared ID
      const emailHash = Math.abs(data.email.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0)).toString(36);
      const uniqueCivId = `usr-civ-${emailHash}`;
      const newUser: User = {
        id: uniqueCivId,
        email: data.email.toLowerCase(),
        full_name: data.full_name,
        phone: data.phone,
        gender: chosenGender,
        role: 'civilian',
        is_active: true,
        is_verified: true,
        created_at: new Date().toISOString(),
        avatar_url: chosenAvatar,
      };
      const fakeJwt = `custom-civ.${uniqueCivId}.${Date.now()}`;
      setUser(newUser);
      setToken(fakeJwt);
      localStorage.setItem('sentinel_user', JSON.stringify(newUser));
      localStorage.setItem('sentinel_token', fakeJwt);
      return true;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('sentinel_user');
    localStorage.removeItem('sentinel_token');
  };

  const switchDemoUser = (role: UserRole) => {
    const demoUser = DEMO_USERS[role];
    const fakeJwt = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.${role}.${Date.now()}`;
    setUser(demoUser);
    setToken(fakeJwt);
    localStorage.setItem('sentinel_user', JSON.stringify(demoUser));
    localStorage.setItem('sentinel_token', fakeJwt);
  };

  const updateUserAvatar = (avatarUrl: string, gender?: 'female' | 'male' | 'other') => {
    if (!user) return;
    const updatedUser: User = {
      ...user,
      avatar_url: avatarUrl,
      ...(gender ? { gender } : {}),
    };
    setUser(updatedUser);
    localStorage.setItem('sentinel_user', JSON.stringify(updatedUser));
  };

  const updateUserProfile = (data: Partial<User>) => {
    if (!user) return;
    const updatedUser: User = {
      ...user,
      ...data,
    };
    setUser(updatedUser);
    localStorage.setItem('sentinel_user', JSON.stringify(updatedUser));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        loginCivilian,
        loginInvestigator,
        registerCivilian,
        logout,
        switchDemoUser,
        updateUserAvatar,
        updateUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
