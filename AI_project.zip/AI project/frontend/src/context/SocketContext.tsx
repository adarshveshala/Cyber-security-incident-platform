import React, { createContext, useContext, useEffect, useState } from 'react';
import { Notification, Message } from '../types';

interface SocketContextType {
  isConnected: boolean;
  notifications: Notification[];
  unreadNotificationCount: number;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  recentMessages: Message[];
  addMessage: (message: Message) => void;
  broadcastNotification: (notification: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;
}

const SocketContext = createContext<SocketContextType | undefined>(undefined);

const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 'notif-1',
    user_id: 'usr-civ-001',
    title: 'Investigation In Progress',
    message: 'Complaint SG-2026-8921 has been reviewed. Forensic triage of submitted wire transaction logs is underway.',
    type: 'incident_status',
    link_url: '/civilian/complaints/inc-001',
    is_read: false,
    created_at: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
  },
  {
    id: 'notif-2',
    user_id: 'usr-civ-001',
    title: 'Investigator Message Received',
    message: 'Special Agent Marcus Vance sent you a clarification message regarding the scammer SMS link.',
    type: 'new_message',
    link_url: '/civilian/messages',
    is_read: false,
    created_at: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
  },
  {
    id: 'notif-3',
    user_id: 'usr-inv-101',
    title: 'High Severity Triage Alert',
    message: 'New incident SG-2026-9042 reported: Unauthorized banking API access attempt with $45,000 potential loss.',
    type: 'security_alert',
    link_url: '/investigator/incidents/inc-002',
    is_read: false,
    created_at: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
  },
  {
    id: 'notif-4',
    user_id: 'usr-inv-101',
    title: 'New Evidence Uploaded',
    message: 'Complainant uploaded 2 packet capture files for SG-2026-8921. SHA-256 integrity verified.',
    type: 'evidence_request',
    link_url: '/investigator/incidents/inc-001',
    is_read: true,
    created_at: new Date(Date.now() - 1000 * 60 * 300).toISOString(),
  },
];

export const SocketProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isConnected, setIsConnected] = useState(true);
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL_NOTIFICATIONS);
  const [recentMessages, setRecentMessages] = useState<Message[]>([]);

  useEffect(() => {
    // Attempt WebSocket connection if available
    let ws: WebSocket | null = null;
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws/events`;
      ws = new WebSocket(wsUrl);

      ws.onopen = () => setIsConnected(true);
      ws.onclose = () => setIsConnected(false);
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'notification') {
            setNotifications((prev) => [data.payload, ...prev]);
          } else if (data.type === 'message') {
            setRecentMessages((prev) => [...prev, data.payload]);
          }
        } catch (e) {
          console.error('Error parsing WS message', e);
        }
      };
    } catch (e) {
      // Graceful fallback to client-side reactive bus
      setIsConnected(true);
    }

    return () => {
      if (ws) ws.close();
    };
  }, []);

  const unreadNotificationCount = notifications.filter((n) => !n.is_read).length;

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, is_read: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
  };

  const addMessage = (message: Message) => {
    setRecentMessages((prev) => [...prev, message]);
  };

  const broadcastNotification = (notification: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => {
    const newNotif: Notification = {
      ...notification,
      id: `notif-${Date.now()}`,
      created_at: new Date().toISOString(),
      is_read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  return (
    <SocketContext.Provider
      value={{
        isConnected,
        notifications,
        unreadNotificationCount,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        recentMessages,
        addMessage,
        broadcastNotification,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
};
