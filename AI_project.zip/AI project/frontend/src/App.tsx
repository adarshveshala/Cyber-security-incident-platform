import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';

// Layouts
import { PublicLayout } from './layouts/PublicLayout';
import { CivilianLayout } from './layouts/CivilianLayout';
import { InvestigatorLayout } from './layouts/InvestigatorLayout';

// Pages - Landing & Auth
import { LandingPage } from './pages/landing/LandingPage';
import { CivilianLogin } from './pages/auth/CivilianLogin';
import { CivilianRegister } from './pages/auth/CivilianRegister';
import { InvestigatorLogin } from './pages/auth/InvestigatorLogin';
import { ForgotPassword } from './pages/auth/ForgotPassword';

// Pages - Civilian Portal
import { CivilianDashboard } from './pages/civilian/CivilianDashboard';
import { ReportIncident } from './pages/civilian/ReportIncident';
import { MyComplaints } from './pages/civilian/MyComplaints';
import { ComplaintDetail } from './pages/civilian/ComplaintDetail';
import { CivilianMessages } from './pages/civilian/CivilianMessages';
import { CivilianNotifications } from './pages/civilian/CivilianNotifications';
import { CivilianAIAssistant } from './pages/civilian/CivilianAIAssistant';
import { CyberSafetyCenter } from './pages/civilian/CyberSafetyCenter';
import { CivilianProfile } from './pages/civilian/CivilianProfile';
import { CivilianSettings } from './pages/civilian/CivilianSettings';

// Pages - Investigator Portal
import { SocOverview } from './pages/investigator/SocOverview';
import { IncidentQueue } from './pages/investigator/IncidentQueue';
import { MyInvestigations } from './pages/investigator/MyInvestigations';
import { AllIncidents } from './pages/investigator/AllIncidents';
import { IncidentWorkspace } from './pages/investigator/IncidentWorkspace';
import { ThreatIntelligence } from './pages/investigator/ThreatIntelligence';
import { AICopilot } from './pages/investigator/AICopilot';
import { EvidenceManagement } from './pages/investigator/EvidenceManagement';
import { InvestigatorMessages } from './pages/investigator/InvestigatorMessages';
import { SecurityAlerts } from './pages/investigator/SecurityAlerts';
import { AnalyticsView } from './pages/investigator/AnalyticsView';
import { ReportsView } from './pages/investigator/ReportsView';
import { TeamManagement } from './pages/investigator/TeamManagement';
import { AuditLogs } from './pages/investigator/AuditLogs';
import { InvestigatorSettings } from './pages/investigator/InvestigatorSettings';

export const App: React.FC = () => {
  return (
    <AuthProvider>
      <SocketProvider>
        <BrowserRouter>
          <Routes>
            {/* Public Landing & Documentation */}
            <Route path="/" element={<PublicLayout />}>
              <Route index element={<LandingPage />} />
            </Route>

            {/* Civilian Authentication */}
            <Route path="/login" element={<CivilianLogin />} />
            <Route path="/auth" element={<CivilianLogin />} />
            <Route path="/civilian/login" element={<CivilianLogin />} />
            <Route path="/civilian/register" element={<CivilianRegister />} />
            <Route path="/auth/forgot-password" element={<ForgotPassword />} />

            {/* Investigator Authentication */}
            <Route path="/investigator/login" element={<InvestigatorLogin />} />

            {/* Civilian Portal */}
            <Route path="/civilian" element={<CivilianLayout />}>
              <Route index element={<Navigate to="/civilian/dashboard" replace />} />
              <Route path="dashboard" element={<CivilianDashboard />} />
              <Route path="report" element={<ReportIncident />} />
              <Route path="complaints" element={<MyComplaints />} />
              <Route path="complaints/:id" element={<ComplaintDetail />} />
              <Route path="messages" element={<CivilianMessages />} />
              <Route path="notifications" element={<CivilianNotifications />} />
              <Route path="ai-assistant" element={<CivilianAIAssistant />} />
              <Route path="safety-center" element={<CyberSafetyCenter />} />
              <Route path="profile" element={<CivilianProfile />} />
              <Route path="settings" element={<CivilianSettings />} />
            </Route>

            {/* Investigator Portal */}
            <Route path="/investigator" element={<InvestigatorLayout />}>
              <Route index element={<Navigate to="/investigator/soc" replace />} />
              <Route path="soc" element={<SocOverview />} />
              <Route path="queue" element={<IncidentQueue />} />
              <Route path="my-cases" element={<MyInvestigations />} />
              <Route path="incidents" element={<AllIncidents />} />
              <Route path="incidents/:id" element={<IncidentWorkspace />} />
              <Route path="threat-intel" element={<ThreatIntelligence />} />
              <Route path="copilot" element={<AICopilot />} />
              <Route path="evidence" element={<EvidenceManagement />} />
              <Route path="messages" element={<InvestigatorMessages />} />
              <Route path="alerts" element={<SecurityAlerts />} />
              <Route path="analytics" element={<AnalyticsView />} />
              <Route path="reports" element={<ReportsView />} />
              <Route path="team" element={<TeamManagement />} />
              <Route path="audit" element={<AuditLogs />} />
              <Route path="settings" element={<InvestigatorSettings />} />
            </Route>

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </SocketProvider>
    </AuthProvider>
  );
};
