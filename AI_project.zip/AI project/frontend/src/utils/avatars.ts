// Non-human default profile avatars categorized by gender & cyber defense personas

export interface AvatarPreset {
  id: string;
  name: string;
  gender: 'female' | 'male' | 'other';
  roleTag: string;
  url: string;
}

// Crisp inline SVG vector data URIs - 100% offline-ready, non-human digital illustrations
const createSvgAvatar = (bgGradStart: string, bgGradEnd: string, accentColor: string, innerSvg: string): string => {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">
    <defs>
      <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${bgGradStart}"/>
        <stop offset="100%" stop-color="${bgGradEnd}"/>
      </linearGradient>
    </defs>
    <rect width="120" height="120" rx="36" fill="url(#bg)"/>
    <circle cx="60" cy="60" r="48" fill="none" stroke="${accentColor}" stroke-width="2" stroke-opacity="0.3"/>
    ${innerSvg}
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

export const AVATAR_PRESETS: AvatarPreset[] = [
  // --- FEMALE DIGITAL CYBER DEFENDERS (Non-Human) ---
  {
    id: 'fem-agent-sarah',
    name: 'Defender Sarah (Cyber Visor)',
    gender: 'female',
    roleTag: 'Citizen Defense',
    url: createSvgAvatar('#1E40AF', '#3B82F6', '#60A5FA', `
      <!-- Head / Hair -->
      <path d="M42 42 C42 26 78 26 78 42 C78 44 82 52 80 62 C78 72 70 82 60 82 C50 82 42 72 40 62 C38 52 42 44 42 42 Z" fill="#93C5FD"/>
      <path d="M38 46 C36 34 50 24 60 24 C72 24 84 34 82 48 C82 50 80 58 78 64 C76 56 74 48 68 44 C62 40 52 42 46 44 C42 46 38 54 38 64 Z" fill="#1D4ED8"/>
      <!-- Cyber Visor / Glasses -->
      <path d="M44 50 L76 50 C78 50 80 52 80 55 L78 60 C77 62 74 64 60 64 C46 64 43 62 42 60 L40 55 C40 52 42 50 44 50 Z" fill="#06B6D4"/>
      <line x1="44" y1="56" x2="76" y2="56" stroke="#FFFFFF" stroke-width="1.5" stroke-linecap="round"/>
      <!-- Shield Torso -->
      <path d="M36 100 C36 84 48 80 60 80 C72 80 84 84 84 100 Z" fill="#2563EB"/>
      <circle cx="60" cy="88" r="4" fill="#38BDF8"/>
    `),
  },
  {
    id: 'fem-detective-elena',
    name: 'Lead Detective Elena',
    gender: 'female',
    roleTag: 'Forensic Lead',
    url: createSvgAvatar('#0F766E', '#14B8A6', '#2DD4BF', `
      <!-- Hair / Silhouette -->
      <path d="M38 48 C36 28 84 28 82 48 C82 58 84 72 80 80 C76 68 76 56 60 56 C44 56 44 68 40 80 C36 72 38 58 38 48 Z" fill="#0D9488"/>
      <!-- Face -->
      <path d="M46 46 C46 38 74 38 74 46 C74 58 70 72 60 72 C50 72 46 58 46 46 Z" fill="#CCFBF1"/>
      <!-- Optical Scanner Monocle -->
      <circle cx="67" cy="50" r="7" fill="none" stroke="#0F766E" stroke-width="2"/>
      <circle cx="67" cy="50" r="3" fill="#14B8A6"/>
      <!-- Uniform Collar -->
      <path d="M38 100 C38 82 50 78 60 78 C70 78 82 82 82 100 Z" fill="#115E59"/>
      <polygon points="60,82 56,92 64,92" fill="#2DD4BF"/>
    `),
  },
  {
    id: 'fem-analyst-maya',
    name: 'Analyst Maya (Intelligence)',
    gender: 'female',
    roleTag: 'Threat Intel',
    url: createSvgAvatar('#4338CA', '#6366F1', '#A5B4FC', `
      <!-- Hair Bob -->
      <path d="M36 50 C36 28 84 28 84 50 C86 66 84 76 80 82 L76 68 C76 50 72 46 60 46 C48 46 44 50 44 68 L40 82 C36 76 34 66 36 50 Z" fill="#312E81"/>
      <!-- Face -->
      <circle cx="60" cy="54" r="16" fill="#E0E7FF"/>
      <!-- Headset -->
      <path d="M40 50 A20 20 0 0 1 80 50" fill="none" stroke="#C7D2FE" stroke-width="3"/>
      <rect x="38" y="48" width="5" height="12" rx="2" fill="#818CF8"/>
      <rect x="77" y="48" width="5" height="12" rx="2" fill="#818CF8"/>
      <!-- Torso -->
      <path d="M38 100 C38 84 48 80 60 80 C72 80 82 84 82 100 Z" fill="#4F46E5"/>
    `),
  },
  {
    id: 'fem-guardian-val',
    name: 'Guardian Valerie (Cipher Unit)',
    gender: 'female',
    roleTag: 'Encryption Vault',
    url: createSvgAvatar('#0369A1', '#0EA5E9', '#38BDF8', `
      <!-- Hex Shield Face -->
      <polygon points="60,30 84,44 84,72 60,86 36,72 36,44" fill="#E0F2FE" stroke="#0284C7" stroke-width="2"/>
      <!-- Eyes / Sensor Bar -->
      <rect x="46" y="52" width="28" height="6" rx="3" fill="#0284C7"/>
      <circle cx="53" cy="55" r="1.5" fill="#FFFFFF"/>
      <circle cx="67" cy="55" r="1.5" fill="#FFFFFF"/>
      <!-- Armor Collar -->
      <path d="M32 100 C32 86 44 82 60 82 C76 82 88 86 88 100 Z" fill="#0369A1"/>
      <polygon points="60,86 54,96 66,96" fill="#38BDF8"/>
    `),
  },

  // --- MALE DIGITAL CYBER DEFENDERS (Non-Human) ---
  {
    id: 'male-agent-marcus',
    name: 'Special Agent Marcus (Tactical)',
    gender: 'male',
    roleTag: 'SOC Operative',
    url: createSvgAvatar('#1E293B', '#334155', '#38BDF8', `
      <!-- Hair Crop -->
      <path d="M44 38 C44 26 76 26 76 38 L76 44 L44 44 Z" fill="#0F172A"/>
      <!-- Face -->
      <path d="M44 40 L76 40 L74 64 C74 74 66 80 60 80 C54 80 46 74 46 64 Z" fill="#CBD5E1"/>
      <!-- Forensic Eye Implant -->
      <circle cx="52" cy="52" r="4" fill="#1E293B"/>
      <circle cx="68" cy="52" r="5" fill="none" stroke="#0284C7" stroke-width="2"/>
      <circle cx="68" cy="52" r="2.5" fill="#38BDF8"/>
      <!-- Body / Armor -->
      <path d="M34 100 C34 82 46 76 60 76 C74 76 86 82 86 100 Z" fill="#1E293B"/>
      <!-- Badge Badge SG-INV -->
      <rect x="54" y="82" width="12" height="14" rx="2" fill="#0284C7"/>
      <line x1="57" y1="88" x2="63" y2="88" stroke="#FFFFFF" stroke-width="1.5"/>
    `),
  },
  {
    id: 'male-director-sterling',
    name: 'Director Sterling (Command)',
    gender: 'male',
    roleTag: 'System Governance',
    url: createSvgAvatar('#0F172A', '#1E3A8A', '#60A5FA', `
      <!-- Hair -->
      <path d="M42 36 C42 24 78 24 78 36 L76 46 L44 46 Z" fill="#475569"/>
      <!-- Face -->
      <path d="M44 42 L76 42 L74 64 C74 74 66 80 60 80 C54 80 46 74 46 64 Z" fill="#E2E8F0"/>
      <!-- Glasses -->
      <rect x="46" y="50" width="11" height="8" rx="2" fill="none" stroke="#1E293B" stroke-width="1.5"/>
      <rect x="63" y="50" width="11" height="8" rx="2" fill="none" stroke="#1E293B" stroke-width="1.5"/>
      <line x1="57" y1="54" x2="63" y2="54" stroke="#1E293B" stroke-width="1.5"/>
      <!-- Suit / Tie -->
      <path d="M34 100 C34 82 46 78 60 78 C74 78 86 82 86 100 Z" fill="#0F172A"/>
      <polygon points="60,82 56,100 64,100" fill="#2563EB"/>
    `),
  },
  {
    id: 'male-detective-alex',
    name: 'Detective Alex (Incident Response)',
    gender: 'male',
    roleTag: 'Digital Forensic',
    url: createSvgAvatar('#047857', '#10B981', '#6EE7B7', `
      <!-- Hair / Cap -->
      <path d="M40 40 C40 26 80 26 80 40 L84 46 L36 46 Z" fill="#065F46"/>
      <!-- Face -->
      <path d="M44 44 L76 44 L74 64 C74 74 66 80 60 80 C54 80 46 74 46 64 Z" fill="#D1FAE5"/>
      <!-- Sensor Specs -->
      <rect x="46" y="50" width="28" height="6" rx="2" fill="#047857"/>
      <circle cx="52" cy="53" r="1.5" fill="#34D399"/>
      <circle cx="68" cy="53" r="1.5" fill="#34D399"/>
      <!-- Coat -->
      <path d="M34 100 C34 82 46 78 60 78 C74 78 86 82 86 100 Z" fill="#064E3B"/>
    `),
  },
  {
    id: 'male-cipher-dave',
    name: 'Analyst David (Malware Lab)',
    gender: 'male',
    roleTag: 'Reverse Engineering',
    url: createSvgAvatar('#9A3412', '#F97316', '#FDBA74', `
      <!-- Hair -->
      <path d="M44 36 C44 26 76 26 76 36 L78 44 L42 44 Z" fill="#7C2D12"/>
      <!-- Face -->
      <circle cx="60" cy="56" r="16" fill="#FFEDD5"/>
      <!-- Lab Visor -->
      <rect x="44" y="50" width="32" height="8" rx="3" fill="#EA580C"/>
      <line x1="46" y1="54" x2="74" y2="54" stroke="#FFFFFF" stroke-width="1"/>
      <!-- Torso -->
      <path d="M34 100 C34 84 46 80 60 80 C74 80 86 84 86 100 Z" fill="#9A3412"/>
    `),
  },

  // --- CYBER EMBLERMS & AGENT INSIGNIAS (Non-Human Neutral) ---
  {
    id: 'bot-sentinel-shield',
    name: 'Sentinel Cyber Shield',
    gender: 'other',
    roleTag: 'Cryptographic Core',
    url: createSvgAvatar('#1E40AF', '#0D9488', '#38BDF8', `
      <!-- Digital Shield -->
      <path d="M60 25 L88 38 C88 65 76 86 60 95 C44 86 32 65 32 38 Z" fill="#FFFFFF" fill-opacity="0.9" stroke="#2563EB" stroke-width="3"/>
      <!-- Inner Padlock -->
      <path d="M52 54 L52 48 A8 8 0 0 1 68 48 L68 54" fill="none" stroke="#0D9488" stroke-width="3"/>
      <rect x="48" y="54" width="24" height="20" rx="4" fill="#0D9488"/>
      <circle cx="60" cy="62" r="2.5" fill="#FFFFFF"/>
      <line x1="60" y1="64.5" x2="60" y2="69" stroke="#FFFFFF" stroke-width="2"/>
    `),
  },
  {
    id: 'bot-radar-core',
    name: 'SOC Telemetry Radar',
    gender: 'other',
    roleTag: 'Sensor Grid',
    url: createSvgAvatar('#0F172A', '#0284C7', '#38BDF8', `
      <!-- Concentric Radar Rings -->
      <circle cx="60" cy="60" r="32" fill="none" stroke="#38BDF8" stroke-width="2" stroke-opacity="0.6"/>
      <circle cx="60" cy="60" r="20" fill="none" stroke="#38BDF8" stroke-width="1.5" stroke-opacity="0.4"/>
      <circle cx="60" cy="60" r="8" fill="#38BDF8"/>
      <!-- Crosshairs -->
      <line x1="20" y1="60" x2="100" y2="60" stroke="#38BDF8" stroke-width="1" stroke-opacity="0.5"/>
      <line x1="60" y1="20" x2="60" y2="100" stroke="#38BDF8" stroke-width="1" stroke-opacity="0.5"/>
      <!-- Blip -->
      <circle cx="72" cy="46" r="4" fill="#10B981"/>
    `),
  },
  {
    id: 'bot-ai-automaton',
    name: 'Sentinel Copilot Bot',
    gender: 'other',
    roleTag: 'Forensic AI',
    url: createSvgAvatar('#312E81', '#4F46E5', '#A5B4FC', `
      <!-- Bot Head -->
      <rect x="36" y="40" width="48" height="40" rx="10" fill="#EEF2FF" stroke="#4338CA" stroke-width="3"/>
      <!-- Antenna -->
      <line x1="60" y1="40" x2="60" y2="28" stroke="#4338CA" stroke-width="3"/>
      <circle cx="60" cy="26" r="4" fill="#06B6D4"/>
      <!-- Screen Visor -->
      <rect x="42" y="48" width="36" height="16" rx="6" fill="#1E1B4B"/>
      <!-- Glowing Eyes -->
      <circle cx="52" cy="56" r="3" fill="#38BDF8"/>
      <circle cx="68" cy="56" r="3" fill="#38BDF8"/>
      <!-- Body Neck -->
      <path d="M48 80 L72 80 L76 96 L44 96 Z" fill="#4F46E5"/>
    `),
  },
  {
    id: 'bot-crypto-key',
    name: 'SHA-256 Vault Seal',
    gender: 'other',
    roleTag: 'Evidence Seal',
    url: createSvgAvatar('#134E4A', '#0D9488', '#5EEAD4', `
      <!-- Seal Hexagon -->
      <polygon points="60,24 90,40 90,80 60,96 30,80 30,40" fill="#F0FDFA" stroke="#0D9488" stroke-width="3"/>
      <circle cx="60" cy="60" r="16" fill="#0F766E"/>
      <path d="M55 58 L59 63 L66 54" fill="none" stroke="#5EEAD4" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    `),
  },
];

export const getDefaultAvatar = (gender?: string, role?: string, id?: string): string => {
  if (id) {
    const found = AVATAR_PRESETS.find(p => p.id === id);
    if (found) return found.url;
  }

  if (gender === 'female') {
    return AVATAR_PRESETS[0].url; // Defender Sarah
  } else if (gender === 'male') {
    return AVATAR_PRESETS[4].url; // Agent Marcus
  } else if (role === 'investigator') {
    return AVATAR_PRESETS[4].url;
  } else if (role === 'senior_investigator') {
    return AVATAR_PRESETS[1].url; // Elena Rostova
  } else if (role === 'admin') {
    return AVATAR_PRESETS[5].url; // Director Sterling
  }

  return AVATAR_PRESETS[0].url;
};
