import React, { useState, useEffect } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import { Sidebar } from '../components/common/Sidebar';
import { Header } from '../components/common/Header';
import { useAuth } from '../context/AuthContext';

export const InvestigatorLayout: React.FC = () => {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // If user signed out, smoothly redirect to investigator login
  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/investigator/login');
    }
  }, [user, isLoading, navigate]);

  return (
    <div className="flex min-h-screen bg-[#F1F5F9] bg-cyber-grid text-[#475569]">
      <Sidebar
        portal="investigator"
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen((prev) => !prev)}
        onClose={() => setIsSidebarOpen(false)}
      />
      <div className="flex-1 flex flex-col min-w-0 transition-all duration-300">
        <Header
          portal="investigator"
          isSidebarOpen={isSidebarOpen}
          onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
        />
        <main className="flex-1 p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
