import React from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from '../components/common/Navbar';

export const PublicLayout: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-[#F7FAFC] text-[#475569]">
      <Navbar />
      <main className="flex-1">
        <Outlet />
      </main>
    </div>
  );
};
