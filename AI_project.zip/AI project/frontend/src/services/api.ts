import {
  Incident,
  IncidentStatus,
  IncidentSeverity,
  EvidenceItem,
  Message,
  ThreatIndicator,
  SecurityAlert,
  SecurityEvent,
  ResponsePlaybook,
  AuditLogEntry,
  AIAnalysisResult,
} from '../types';

const API_BASE = '/api/v1';

// Seed mock database for seamless interactivity & backend parity
let MOCK_INCIDENTS: Incident[] = [
  {
    id: 'inc-001',
    complaint_id: 'SG-2026-8921',
    title: 'Executive Phishing & Wire Redirection Fraud',
    category: 'financial_fraud',
    severity: 'high',
    status: 'investigation_in_progress',
    description: 'Received spoofed spear-phishing email impersonating corporate finance officer requesting urgent vendor routing number update. Approximately $34,500 wire attempted through falsified payment gateway.',
    incident_date: '2026-11-14',
    incident_time: '14:32',
    platform_involved: 'Corporate Outlook / Swift Transfer',
    suspect_info: 'Email sender: admin@pay-secure-corporate.net, Destination IP: 194.26.29.112',
    website_url: 'https://pay-secure-corporate.net/portal/auth',
    financial_loss: 34500,
    currency: 'USD',
    contact_email: 'sarah.connor@example.com',
    contact_phone: '+1 (555) 234-5678',
    latitude: 40.7128,
    longitude: -74.0060,
    location_name: 'New York, USA',
    civilian_id: 'usr-civ-001',
    civilian_name: 'Sarah Connor',
    assigned_investigator_id: 'usr-inv-101',
    assigned_investigator_name: 'Special Agent Marcus Vance',
    created_at: '2026-11-14T14:45:00Z',
    updated_at: '2026-11-15T10:20:00Z',
    evidence_count: 3,
    message_count: 5,
    evidence: [
      {
        id: 'evid-101',
        incident_id: 'inc-001',
        file_name: 'fraudulent_wire_instructions.pdf',
        file_size: 428000,
        file_type: 'application/pdf',
        file_url: '#',
        sha256_hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        uploaded_by_id: 'usr-civ-001',
        uploaded_by_name: 'Sarah Connor',
        uploaded_at: '2026-11-14T14:50:00Z',
        description: 'Falsified wire instructions received via spoofed domain.',
        is_verified: true,
      },
      {
        id: 'evid-102',
        incident_id: 'inc-001',
        file_name: 'email_headers_raw.eml',
        file_size: 15400,
        file_type: 'message/rfc822',
        file_url: '#',
        sha256_hash: 'a9f23904e5d610330541176b66851d7c4937227d86f77340026e63a1e0bcfad6',
        uploaded_by_id: 'usr-civ-001',
        uploaded_by_name: 'Sarah Connor',
        uploaded_at: '2026-11-14T15:02:00Z',
        description: 'Original headers showing SPF/DKIM fail for spoofed sender.',
        is_verified: true,
      },
      {
        id: 'evid-103',
        incident_id: 'inc-001',
        file_name: 'sms_two_factor_interception_screenshot.png',
        file_size: 845000,
        file_type: 'image/png',
        file_url: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=600',
        sha256_hash: '8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4',
        uploaded_by_id: 'usr-civ-001',
        uploaded_by_name: 'Sarah Connor',
        uploaded_at: '2026-11-15T09:15:00Z',
        description: 'Screenshot of rogue SMS verification push.',
        is_verified: true,
      },
    ],
    timeline: [
      {
        id: 'evt-1',
        incident_id: 'inc-001',
        actor_name: 'Sarah Connor',
        actor_role: 'Civilian',
        event_type: 'REPORT_SUBMITTED',
        description: 'Complaint submitted with initial email header evidence.',
        created_at: '2026-11-14T14:45:00Z',
      },
      {
        id: 'evt-2',
        incident_id: 'inc-001',
        actor_name: 'Lead Detective Elena Rostova',
        actor_role: 'Senior Investigator',
        event_type: 'TRIAGE_REVIEW',
        description: 'Triage complete. Priority escalated to HIGH due to ongoing active wire transaction.',
        created_at: '2026-11-14T15:10:00Z',
      },
      {
        id: 'evt-3',
        incident_id: 'inc-001',
        actor_name: 'Special Agent Marcus Vance',
        actor_role: 'Investigator',
        event_type: 'ASSIGNMENT',
        description: 'Assigned to Special Agent Marcus Vance for active forensic review.',
        created_at: '2026-11-14T15:30:00Z',
      },
      {
        id: 'evt-4',
        incident_id: 'inc-001',
        actor_name: 'Special Agent Marcus Vance',
        actor_role: 'Investigator',
        event_type: 'THREAT_INTEL_ENRICHMENT',
        description: 'Enriched IOC: Domain pay-secure-corporate.net flagged malicious (Risk Score 92/100).',
        created_at: '2026-11-15T10:15:00Z',
      },
    ],
  },
  {
    id: 'inc-002',
    complaint_id: 'SG-2026-9042',
    title: 'Credential Stuffing & Cloud Storage Exfiltration',
    category: 'account_hacking',
    severity: 'critical',
    status: 'assigned',
    description: 'Repeated brute-force authentication attempts detected from distributed Russian and Brazilian autonomous systems against employee cloud storage drive. Data archive downloaded.',
    incident_date: '2026-11-15',
    incident_time: '23:14',
    platform_involved: 'AWS S3 / Google Workspace Single Sign-On',
    suspect_info: 'Cluster of 14 IPs rotating via Tor exit nodes',
    website_url: 'https://storage.cloud-vault-access.org',
    financial_loss: 0,
    currency: 'USD',
    contact_email: 'james.miller@enterprisesec.org',
    contact_phone: '+1 (555) 890-1234',
    latitude: 51.5074,
    longitude: -0.1278,
    location_name: 'London, UK',
    civilian_id: 'usr-civ-002',
    civilian_name: 'James Miller',
    assigned_investigator_id: 'usr-inv-101',
    assigned_investigator_name: 'Special Agent Marcus Vance',
    created_at: '2026-11-15T23:45:00Z',
    updated_at: '2026-11-16T08:00:00Z',
    evidence_count: 1,
    message_count: 2,
  },
  {
    id: 'inc-003',
    complaint_id: 'SG-2026-9118',
    title: 'Social Media Impersonation & Extortion Scheme',
    category: 'impersonation',
    severity: 'medium',
    status: 'under_review',
    description: 'Compromised Instagram profile used to extort followers by demanding crypto transfer to release cloned photo archives.',
    incident_date: '2026-11-16',
    incident_time: '11:00',
    platform_involved: 'Instagram / Telegram',
    suspect_info: 'Telegram handler: @fast_cash_crypto_guru',
    website_url: '',
    financial_loss: 1200,
    currency: 'USD',
    latitude: 37.7749,
    longitude: -122.4194,
    location_name: 'San Francisco, USA',
    contact_email: 'maya.patel@example.com',
    civilian_id: 'usr-civ-003',
    civilian_name: 'Maya Patel',
    created_at: '2026-11-16T11:20:00Z',
    updated_at: '2026-11-16T11:20:00Z',
    evidence_count: 4,
    message_count: 0,
  },
  {
    id: 'inc-004',
    complaint_id: 'SG-2026-7840',
    title: 'Ransomware Infection (LockBit Variant Detected)',
    category: 'malware',
    severity: 'critical',
    status: 'resolved',
    description: 'Local medical diagnostic clinic file server encrypted with .lockbit3 extension. Incident resolved via cold backup restoration and perimeter firewall patch.',
    incident_date: '2026-11-10',
    financial_loss: 0,
    latitude: 50.1109,
    longitude: 8.6821,
    location_name: 'Frankfurt, Germany',
    contact_email: 'clinic-admin@metrohealth.net',
    civilian_id: 'usr-civ-004',
    civilian_name: 'Metro Health Admin',
    assigned_investigator_id: 'usr-inv-202',
    assigned_investigator_name: 'Lead Detective Elena Rostova',
    created_at: '2026-11-10T09:12:00Z',
    updated_at: '2026-11-13T17:40:00Z',
    evidence_count: 2,
    message_count: 9,
  },
  {
    id: 'inc-005',
    complaint_id: 'SG-2026-6419',
    title: 'Distributed Denial of Service (DDoS) Against DNS Root',
    category: 'other',
    severity: 'critical',
    status: 'investigation_in_progress',
    description: 'Coordinated NTP/DNS amplification DDoS attack peak at 480 Gbps originating from Mirai botnet nodes targeting regional edge resolver.',
    incident_date: '2026-11-17',
    incident_time: '04:12',
    platform_involved: 'Edge DNS Anycast Node',
    suspect_info: 'Botnet ASN cluster 4134, 4837',
    website_url: 'https://dns-apac-cluster.sentinelgrid.io',
    financial_loss: 0,
    currency: 'USD',
    latitude: 35.6762,
    longitude: 139.6503,
    location_name: 'Tokyo, Japan',
    contact_email: 'noc@tokyotel.jp',
    civilian_id: 'usr-civ-005',
    civilian_name: 'Kenji Sato',
    assigned_investigator_id: 'usr-inv-101',
    assigned_investigator_name: 'Special Agent Marcus Vance',
    created_at: '2026-11-17T04:30:00Z',
    updated_at: '2026-11-17T08:15:00Z',
    evidence_count: 3,
    message_count: 4,
  },
  {
    id: 'inc-006',
    complaint_id: 'SG-2026-5521',
    title: 'SWIFT Interbank API Tampering & Man-in-the-Middle',
    category: 'financial_fraud',
    severity: 'high',
    status: 'investigation_in_progress',
    description: 'Forged OAuth bearer token used in attempt to inject altered payload into interbank clearing queue. Intercepted by HSM gateway.',
    incident_date: '2026-11-18',
    incident_time: '16:45',
    platform_involved: 'Financial Gateway MT103 API',
    suspect_info: 'Proxy IP: 103.253.42.18, User-Agent: Custom-Python-Async',
    website_url: 'https://clearing.sg-finnet.org',
    financial_loss: 85000,
    currency: 'USD',
    latitude: 1.3521,
    longitude: 103.8198,
    location_name: 'Singapore',
    contact_email: 'fraud.ops@sg-finnet.org',
    civilian_id: 'usr-civ-006',
    civilian_name: 'Lim Wei Chen',
    assigned_investigator_id: 'usr-inv-202',
    assigned_investigator_name: 'Lead Detective Elena Rostova',
    created_at: '2026-11-18T17:00:00Z',
    updated_at: '2026-11-19T09:20:00Z',
    evidence_count: 5,
    message_count: 6,
  },
  {
    id: 'inc-007',
    complaint_id: 'SG-2026-4192',
    title: 'Supply Chain Package Poisoning (PyPI / npm Typosquat)',
    category: 'malware',
    severity: 'critical',
    status: 'under_review',
    description: 'Malicious npm dependency with hidden base64 payload published under typosquatted enterprise library name. Captured tokens exfiltrated to webhook.',
    incident_date: '2026-11-19',
    incident_time: '08:30',
    platform_involved: 'npm Registry / GitHub Actions',
    suspect_info: 'Registry maintainer handle: pkg-dev-ghost9',
    website_url: 'https://registry.npmjs.org/secure-auth-tokens-v2',
    financial_loss: 15000,
    currency: 'USD',
    latitude: 48.8566,
    longitude: 2.3522,
    location_name: 'Paris, France',
    contact_email: 'secops@lecloud-paris.fr',
    civilian_id: 'usr-civ-007',
    civilian_name: 'Amélie Laurent',
    assigned_investigator_id: 'usr-inv-202',
    assigned_investigator_name: 'Lead Detective Elena Rostova',
    created_at: '2026-11-19T09:00:00Z',
    updated_at: '2026-11-19T10:00:00Z',
    evidence_count: 2,
    message_count: 1,
  },
  {
    id: 'inc-008',
    complaint_id: 'SG-2026-3841',
    title: 'Healthcare Patient Record Data Breach & Cloud Exfiltration',
    category: 'data_breach',
    severity: 'high',
    status: 'assigned',
    description: 'Misconfigured AWS S3 bucket permissions left 24,000 anonymized patient diagnostic reports indexable by internet scanners.',
    incident_date: '2026-11-19',
    incident_time: '13:10',
    platform_involved: 'AWS S3 Healthcare Diagnostic Vault',
    suspect_info: 'Shodan / Censys automated scrapers logged',
    website_url: 'https://med-diagnostics-ca.s3.amazonaws.com',
    financial_loss: 0,
    currency: 'USD',
    latitude: 43.6532,
    longitude: -79.3832,
    location_name: 'Toronto, Canada',
    contact_email: 'privacy@carehealth-on.ca',
    civilian_id: 'usr-civ-008',
    civilian_name: 'David MacLeod',
    assigned_investigator_id: 'usr-inv-101',
    assigned_investigator_name: 'Special Agent Marcus Vance',
    created_at: '2026-11-19T13:45:00Z',
    updated_at: '2026-11-20T07:30:00Z',
    evidence_count: 2,
    message_count: 3,
  },
  {
    id: 'inc-009',
    complaint_id: 'SG-2026-2715',
    title: 'SIM Swap & Cryptowallet Unauthorized Drain',
    category: 'identity_theft',
    severity: 'medium',
    status: 'under_review',
    description: 'Fraudulent carrier SIM reassignment bypassed 2FA SMS checks, allowing threat actor to drain $9,400 USDT from decentralized exchange account.',
    incident_date: '2026-11-20',
    incident_time: '19:40',
    platform_involved: 'Mobile Carrier & Web3 Wallet',
    suspect_info: 'Transfer Tx: 0x7a2f4e91823901bcae5482...',
    website_url: '',
    financial_loss: 9400,
    currency: 'USD',
    latitude: 19.0760,
    longitude: 72.8777,
    location_name: 'Mumbai, India',
    contact_email: 'aarav.sharma@example.in',
    civilian_id: 'usr-civ-009',
    civilian_name: 'Aarav Sharma',
    assigned_investigator_id: 'usr-inv-101',
    assigned_investigator_name: 'Special Agent Marcus Vance',
    created_at: '2026-11-20T20:10:00Z',
    updated_at: '2026-11-20T20:10:00Z',
    evidence_count: 1,
    message_count: 0,
  },
  {
    id: 'inc-010',
    complaint_id: 'SG-2026-1930',
    title: 'Corporate Messaging Smishing Campaign',
    category: 'phishing',
    severity: 'low',
    status: 'resolved',
    description: 'Bulk SMS messages sent to APAC engineering team claiming urgent MFA policy update. Neutralized within 1 hour via carrier spam blacklist.',
    incident_date: '2026-11-12',
    financial_loss: 0,
    latitude: -33.8688,
    longitude: 151.2093,
    location_name: 'Sydney, Australia',
    contact_email: 'security@pacific-tech.com.au',
    civilian_id: 'usr-civ-010',
    civilian_name: 'Chloe Bennett',
    assigned_investigator_id: 'usr-inv-101',
    assigned_investigator_name: 'Special Agent Marcus Vance',
    created_at: '2026-11-12T11:00:00Z',
    updated_at: '2026-11-13T14:30:00Z',
    evidence_count: 1,
    message_count: 2,
  },
  {
    id: 'inc-011',
    complaint_id: 'SG-2026-1102',
    title: 'Industrial SCADA Sensor Telemetry Spoofing',
    category: 'other',
    severity: 'critical',
    status: 'investigation_in_progress',
    description: 'Unauthorized Modbus TCP command injection detected on municipal water cooling control loop. Failsafe switch engaged.',
    incident_date: '2026-11-21',
    incident_time: '02:15',
    platform_involved: 'Industrial Modbus Gateway / Siemens PLC',
    suspect_info: 'Source IP: 195.201.22.4 (Spoofed Internal Subnet)',
    website_url: '',
    financial_loss: 0,
    currency: 'USD',
    latitude: 52.5200,
    longitude: 13.4050,
    location_name: 'Berlin, Germany',
    contact_email: 'operations@berlin-grid.de',
    civilian_id: 'usr-civ-011',
    civilian_name: 'Hans Weber',
    assigned_investigator_id: 'usr-inv-202',
    assigned_investigator_name: 'Lead Detective Elena Rostova',
    created_at: '2026-11-21T02:40:00Z',
    updated_at: '2026-11-21T06:00:00Z',
    evidence_count: 4,
    message_count: 7,
  },
  {
    id: 'inc-012',
    complaint_id: 'SG-2026-0984',
    title: 'Anonymized Whistleblower Lead (Geo-Resolution Pending)',
    category: 'phishing',
    severity: 'low',
    status: 'submitted',
    description: 'Anonymous leak received through encrypted intake channel without geolocation headers. Pending forensic hop traceroute.',
    incident_date: '2026-11-21',
    financial_loss: 0,
    location_name: 'Unknown / Remote Proxy',
    contact_email: 'whistleblower@protonmail.ch',
    civilian_id: 'usr-civ-012',
    civilian_name: 'Confidential Complainant',
    created_at: '2026-11-21T10:15:00Z',
    updated_at: '2026-11-21T10:15:00Z',
    evidence_count: 1,
    message_count: 0,
  },
  {
    id: 'inc-013',
    complaint_id: 'SG-2026-9524',
    title: 'UPI Payment Gateway QR Code Manipulation & Wire Theft',
    category: 'financial_fraud',
    severity: 'critical',
    status: 'investigation_in_progress',
    description: 'Malicious overlay app intercepted merchant UPI payment flow, swapping dynamic QR code with adversary VPA address. Approximately 1,45,000 INR diverted.',
    incident_date: '2026-11-21',
    incident_time: '14:15',
    platform_involved: 'UPI Gateway / NPCI Protocol',
    suspect_info: 'Beneficiary VPA: tech-support@axisbank-fake.vpa, Suspect IP: 103.112.54.12',
    financial_loss: 1750,
    currency: 'USD',
    latitude: 17.3850,
    longitude: 78.4867,
    location_name: 'Hyderabad, Telangana, India',
    city: 'Hyderabad',
    region: 'Telangana',
    country: 'India',
    reporter_ip: '157.50.140.6',
    contact_email: 'complaint.hyd@sentinelgrid.io',
    civilian_id: 'usr-civ-013',
    civilian_name: 'Adarsh Rao',
    assigned_investigator_id: 'usr-inv-101',
    assigned_investigator_name: 'Special Agent Marcus Vance',
    created_at: '2026-11-21T14:30:00Z',
    updated_at: '2026-11-21T15:00:00Z',
    evidence_count: 3,
    message_count: 4,
  },
];

let MOCK_MESSAGES: Message[] = [
  {
    id: 'msg-1',
    conversation_id: 'conv-inc-001',
    incident_id: 'inc-001',
    sender_id: 'usr-civ-001',
    sender_name: 'Sarah Connor',
    sender_role: 'civilian',
    content: 'Hello Investigator Vance, I have attached the original .eml email header file as requested.',
    attachment_name: 'email_headers_raw.eml',
    created_at: '2026-11-14T15:05:00Z',
  },
  {
    id: 'msg-2',
    conversation_id: 'conv-inc-001',
    incident_id: 'inc-001',
    sender_id: 'usr-inv-101',
    sender_name: 'Special Agent Marcus Vance',
    sender_role: 'investigator',
    content: 'Thank you Sarah. I parsed the email headers. The origin server is hosted on a bulletproof VPS in Western Europe. Have you notified your bank’s wire fraud unit directly yet?',
    created_at: '2026-11-14T15:22:00Z',
  },
  {
    id: 'msg-3',
    conversation_id: 'conv-inc-001',
    incident_id: 'inc-001',
    sender_id: 'usr-civ-001',
    sender_name: 'Sarah Connor',
    sender_role: 'civilian',
    content: 'Yes! They placed a temporary 48-hour hold on the outbound wire clearance. They gave me fraud claim reference #WF-994102.',
    created_at: '2026-11-14T15:35:00Z',
  },
  {
    id: 'msg-4',
    conversation_id: 'conv-inc-001',
    incident_id: 'inc-001',
    sender_id: 'usr-inv-101',
    sender_name: 'Special Agent Marcus Vance',
    sender_role: 'investigator',
    content: 'Excellent response time. That hold drastically improves recovery probability. Could you provide a screenshot of the SMS notification that accompanied the phishing attempt?',
    is_evidence_request: true,
    created_at: '2026-11-15T08:50:00Z',
  },
  {
    id: 'msg-5',
    conversation_id: 'conv-inc-001',
    incident_id: 'inc-001',
    sender_id: 'usr-civ-001',
    sender_name: 'Sarah Connor',
    sender_role: 'civilian',
    content: 'Just uploaded sms_two_factor_interception_screenshot.png to the evidence tab. Hope it helps isolate the SMS gateway.',
    attachment_name: 'sms_two_factor_interception_screenshot.png',
    created_at: '2026-11-15T09:16:00Z',
  },
];

let MOCK_THREAT_INDICATORS: ThreatIndicator[] = [
  {
    id: 'ioc-1',
    indicator: '194.26.29.112',
    type: 'ip',
    reputation: 'malicious',
    risk_score: 94,
    source: 'AbuseIPDB & Sentinel Threat Grid',
    category: 'Phishing Command & Control',
    last_seen: '2026-11-16T12:00:00Z',
    tags: ['phishing', 'bulletproof_vps', 'lockbit_affiliate'],
    details: 'Associated with spoofed banking landing pages and automated credential harvesting kits.',
    last_checked: '2026-11-16T16:00:00Z',
  },
  {
    id: 'ioc-2',
    indicator: 'pay-secure-corporate.net',
    type: 'domain',
    reputation: 'malicious',
    risk_score: 98,
    source: 'VirusTotal & STIX Feed',
    category: 'Typosquatting & Wire Fraud',
    last_seen: '2026-11-15T18:20:00Z',
    tags: ['typosquatting', 'impersonation', 'fast_flux'],
    details: 'Registered 3 days prior to campaign. DNS resolving to fast-flux IP pool.',
    last_checked: '2026-11-16T15:30:00Z',
  },
  {
    id: 'ioc-3',
    indicator: '8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4',
    type: 'file_hash',
    reputation: 'suspicious',
    risk_score: 72,
    source: 'VirusTotal API',
    category: 'Trojan Dropper Payload',
    last_seen: '2026-11-12T04:10:00Z',
    tags: ['dropper', 'powershell_obfuscated'],
    details: 'Obfuscated PowerShell script executing memory-only base64 reflective loader.',
    last_checked: '2026-11-16T14:10:00Z',
  },
  {
    id: 'ioc-4',
    indicator: 'api.enterprise-auth-gateway.com',
    type: 'domain',
    reputation: 'clean',
    risk_score: 4,
    source: 'Cisco Umbrella & Sentinel Validator',
    category: 'Legitimate Infrastructure',
    last_seen: '2026-11-16T20:00:00Z',
    tags: ['verified_cdn', 'enterprise_sso'],
    details: 'Legitimate enterprise SSO authentication endpoint with valid EV SSL certificate.',
    last_checked: '2026-11-16T21:00:00Z',
  },
];

let MOCK_ALERTS: SecurityAlert[] = [
  {
    id: 'alt-1',
    title: 'Multiple Failed Root Login Attempts',
    description: '142 brute force attempts on SSH port 22 from 185.220.101.5 in under 3 minutes.',
    severity: 'high',
    status: 'new',
    source: 'Auth.log Ingestion Pipeline',
    detection_rule_name: 'SOC-RULE-BRUTEFORCE-SSH',
    created_at: '2026-11-16T21:40:00Z',
  },
  {
    id: 'alt-2',
    title: 'Tor Exit Node Connection to Banking API',
    description: 'Inbound TLS session established from known Tor exit relay 185.107.56.211.',
    severity: 'critical',
    status: 'investigating',
    source: 'WAF Gateway Ingestion',
    detection_rule_name: 'SOC-RULE-ANONYMIZER-API',
    created_at: '2026-11-16T21:15:00Z',
    correlated_incident_id: 'inc-002',
  },
  {
    id: 'alt-3',
    title: 'Anomalous Data Egress Volume (>25GB)',
    description: 'Outbound HTTPS transfer to unclassified external IP exceeded baseline by 850%.',
    severity: 'high',
    status: 'correlated',
    source: 'NetFlow Collector',
    detection_rule_name: 'SOC-RULE-DATA-EXFIL-BURST',
    created_at: '2026-11-16T19:30:00Z',
    correlated_incident_id: 'inc-002',
  },
  {
    id: 'alt-4',
    title: 'New Service Installation (Potential Persistence)',
    description: 'Windows Event ID 7045: Service "WinUpdateHelperDrv" created with SYSTEM privileges.',
    severity: 'medium',
    status: 'new',
    source: 'Sysmon / WinEvent Channel',
    detection_rule_name: 'SOC-RULE-SERVICE-PERSISTENCE',
    created_at: '2026-11-16T18:05:00Z',
  },
];

let MOCK_PLAYBOOKS: ResponsePlaybook[] = [
  {
    id: 'pb-1',
    name: 'Executive Wire Fraud & Phishing Containment',
    category: 'financial_fraud',
    description: 'Standard operating procedure for fast-action banking wire recall, domain sinkholing, and credential revocation.',
    steps: [
      { step_number: 1, title: 'Swift Hold Notice to Beneficiary Bank', description: 'Contact receiving institution fraud hotline with MT103 wire reference.', requires_approval: false, status: 'completed' },
      { step_number: 2, title: 'Domain Sinkhole & Registrar Takedown', description: 'Issue abuse ticket to registrar with RFC 2822 email evidence.', requires_approval: true, status: 'in_progress' },
      { step_number: 3, title: 'Universal Session Revocation', description: 'Terminate all active OAuth tokens and invalidate Kerberos tickets for impersonated account.', requires_approval: false, status: 'completed' },
      { step_number: 4, title: 'Civilian Evidence Preservation Packaging', description: 'Export full cryptographic custody package for law enforcement referral.', requires_approval: true, status: 'pending' },
    ],
  },
  {
    id: 'pb-2',
    name: 'Ransomware Triage & Lateral Movement Isolation',
    category: 'malware',
    description: 'Immediate containment playbook for detected encryption activity and active C2 beacons.',
    steps: [
      { step_number: 1, title: 'Network Segment Isolation', description: 'Quarantine VLAN or apply host-level EDR network firewall isolation.', requires_approval: true, status: 'completed' },
      { step_number: 2, title: 'Volatile Memory Snapshot Preservation', description: 'Capture RAM dump prior to host shutdown or reboot.', requires_approval: false, status: 'completed' },
      { step_number: 3, title: 'Shadow Copy & Cold Backup Integrity Audit', description: 'Verify air-gapped backup catalog remains uncompromised.', requires_approval: false, status: 'completed' },
      { step_number: 4, title: 'Decryption Key Feasibility Assessment', description: 'Query NoMoreRansom and threat intelligence repositories for public decryptor keys.', requires_approval: false, status: 'in_progress' },
    ],
  },
  {
    id: 'pb-3',
    name: 'Account Takeover & Credential Stuffing Remediation',
    category: 'account_hacking',
    description: 'Automated workflow for stolen credentials, multi-factor resets, and device authorization audit.',
    steps: [
      { step_number: 1, title: 'Enforce Global Password Reset & Invalidate Tokens', description: 'Require strong passkey/FIDO2 re-registration upon next sign-in.', requires_approval: false, status: 'completed' },
      { step_number: 2, title: 'Audit Forwarding Rules & OAuth Consents', description: 'Inspect inbox forwarding filters and newly granted 3rd party apps.', requires_approval: false, status: 'in_progress' },
      { step_number: 3, title: 'Block Malicious Source Autonomous Systems (ASNs)', description: 'Add offending IP CIDR blocks to perimeter WAF edge.', requires_approval: true, status: 'pending' },
    ],
  },
];

let MOCK_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'aud-1',
    user_id: 'usr-inv-101',
    user_name: 'Special Agent Marcus Vance',
    user_role: 'Investigator',
    action: 'INCIDENT_ASSIGNMENT_ACCEPTED',
    target_resource: 'Incident',
    target_id: 'SG-2026-8921',
    ip_address: '10.240.12.8',
    created_at: '2026-11-14T15:30:12Z',
    details: 'Accepted ownership of complaint SG-2026-8921 from triage queue.',
  },
  {
    id: 'aud-2',
    user_id: 'usr-inv-101',
    user_name: 'Special Agent Marcus Vance',
    user_role: 'Investigator',
    action: 'THREAT_INTEL_QUERY',
    target_resource: 'Indicator',
    target_id: '194.26.29.112',
    ip_address: '10.240.12.8',
    created_at: '2026-11-15T10:14:50Z',
    details: 'Initiated STIX/TAXII automated reputation lookup for suspect server IP.',
  },
  {
    id: 'aud-3',
    user_id: 'usr-civ-001',
    user_name: 'Sarah Connor',
    user_role: 'Civilian',
    action: 'EVIDENCE_FILE_UPLOADED',
    target_resource: 'Evidence',
    target_id: 'evid-103',
    ip_address: '73.189.44.12',
    created_at: '2026-11-15T09:15:33Z',
    details: 'Uploaded screenshot evidence; calculated SHA-256: 8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4',
  },
  {
    id: 'aud-4',
    user_id: 'usr-inv-202',
    user_name: 'Lead Detective Elena Rostova',
    user_role: 'Senior Investigator',
    action: 'PLAYBOOK_STEP_APPROVED',
    target_resource: 'Playbook',
    target_id: 'pb-1 (Step 2)',
    ip_address: '10.240.12.2',
    created_at: '2026-11-15T11:42:00Z',
    details: 'Authorized execution of Domain Sinkhole takedown notice.',
  },
];

function getAuthHeaders(): HeadersInit {
  const token = localStorage.getItem('sentinel_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
  };
}

function normalizeIncident(raw: any): Incident {
  return {
    id: raw.id,
    complaint_id: raw.complaint_id,
    title: raw.title,
    category: raw.category,
    severity: raw.severity,
    status: raw.status,
    description: raw.description,
    incident_date: raw.incident_date,
    incident_time: raw.incident_time,
    platform_involved: raw.platform_involved,
    suspect_info: raw.suspect_info,
    website_url: raw.website_url,
    financial_loss: raw.financial_loss,
    currency: raw.currency || 'USD',
    latitude: raw.latitude,
    longitude: raw.longitude,
    location_name: raw.location_name,
    city: raw.city,
    region: raw.region,
    country: raw.country,
    reporter_ip: raw.reporter_ip,
    contact_email: raw.contact_email,
    contact_phone: raw.contact_phone,
    civilian_id: raw.civilian_id,
    civilian_name: raw.civilian_name,
    assigned_investigator_id: raw.assigned_investigator_id,
    assigned_investigator_name: raw.assigned_investigator_name,
    created_at: raw.created_at ? new Date(raw.created_at).toISOString() : new Date().toISOString(),
    updated_at: raw.updated_at ? new Date(raw.updated_at).toISOString() : new Date().toISOString(),
    evidence_count: raw.evidence ? raw.evidence.length : (raw.evidence_count || 0),
    message_count: raw.message_count || 0,
    evidence: raw.evidence || [],
    timeline: (raw.timeline_events || raw.timeline || []).map((evt: any) => ({
      id: evt.id,
      incident_id: evt.incident_id || raw.id,
      actor_name: evt.actor_name,
      actor_role: evt.actor_role,
      event_type: evt.event_type,
      description: evt.description,
      created_at: evt.created_at ? new Date(evt.created_at).toISOString() : new Date().toISOString(),
    })),
  };
}

export const api = {
  // --- INCIDENTS ---
  async getIncidents(filters?: { status?: string; category?: string; severity?: string; civilianId?: string }): Promise<Incident[]> {
    try {
      const params = new URLSearchParams();
      if (filters?.status && filters.status !== 'all') params.append('status', filters.status);
      if (filters?.category && filters.category !== 'all') params.append('category', filters.category);
      if (filters?.severity && filters.severity !== 'all') params.append('severity', filters.severity);
      if (filters?.civilianId) params.append('civilian_id', filters.civilianId);

      const res = await fetch(`${API_BASE}/incidents/?${params.toString()}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          const normalized = data.map(normalizeIncident);
          // Sync with MOCK_INCIDENTS cache
          for (const item of normalized) {
            const idx = MOCK_INCIDENTS.findIndex(m => m.id === item.id || m.complaint_id === item.complaint_id);
            if (idx >= 0) {
              MOCK_INCIDENTS[idx] = item;
            } else {
              MOCK_INCIDENTS.unshift(item);
            }
          }
          return normalized;
        }
      }
    } catch (err) {
      console.warn('Backend /incidents unavailable, using fallback mock cache:', err);
    }

    let result = [...MOCK_INCIDENTS];
    if (filters?.civilianId) {
      result = result.filter(i => i.civilian_id === filters.civilianId);
    }
    if (filters?.status && filters.status !== 'all') {
      result = result.filter(i => i.status === filters.status);
    }
    if (filters?.category && filters.category !== 'all') {
      result = result.filter(i => i.category === filters.category);
    }
    if (filters?.severity && filters.severity !== 'all') {
      result = result.filter(i => i.severity === filters.severity);
    }
    return result;
  },

  async getIncidentById(id: string): Promise<Incident | null> {
    try {
      const res = await fetch(`${API_BASE}/incidents/${id}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        const normalized = normalizeIncident(data);
        const idx = MOCK_INCIDENTS.findIndex(m => m.id === normalized.id || m.complaint_id === normalized.complaint_id);
        if (idx >= 0) {
          MOCK_INCIDENTS[idx] = normalized;
        } else {
          MOCK_INCIDENTS.unshift(normalized);
        }
        return normalized;
      }
    } catch (err) {
      console.warn(`Backend /incidents/${id} unavailable:`, err);
    }

    const found = MOCK_INCIDENTS.find(i => i.id === id || i.complaint_id === id);
    return found ? { ...found } : null;
  },

  async createIncident(data: Omit<Incident, 'id' | 'complaint_id' | 'created_at' | 'updated_at' | 'status' | 'severity'> & { severity?: IncidentSeverity }): Promise<Incident> {
    try {
      const res = await fetch(`${API_BASE}/incidents/`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          title: data.title,
          category: data.category,
          severity: data.severity || 'medium',
          description: data.description,
          incident_date: data.incident_date,
          incident_time: data.incident_time,
          platform_involved: data.platform_involved,
          suspect_info: data.suspect_info,
          website_url: data.website_url,
          financial_loss: data.financial_loss || 0,
          currency: data.currency || 'USD',
          latitude: data.latitude,
          longitude: data.longitude,
          location_name: data.location_name,
          city: data.city,
          region: data.region,
          country: data.country,
          reporter_ip: data.reporter_ip,
          contact_email: data.contact_email,
          contact_phone: data.contact_phone,
        }),
      });

      if (res.ok) {
        const createdRaw = await res.json();
        const created = normalizeIncident(createdRaw);
        MOCK_INCIDENTS.unshift(created);
        return created;
      }
    } catch (err) {
      console.warn('Backend /incidents/ POST unavailable, using fallback mock create:', err);
    }

    const randomCode = Math.floor(1000 + Math.random() * 9000);
    const complaint_id = `SG-2026-${randomCode}`;
    const newInc: Incident = {
      ...data,
      id: `inc-${Date.now().toString().slice(-4)}`,
      complaint_id,
      status: 'submitted',
      severity: data.severity || 'medium',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      evidence_count: data.evidence ? data.evidence.length : 0,
      message_count: 0,
      timeline: [
        {
          id: `evt-${Date.now()}`,
          incident_id: `inc-${Date.now().toString().slice(-4)}`,
          actor_name: data.civilian_name,
          actor_role: 'Civilian',
          event_type: 'REPORT_SUBMITTED',
          description: `Complaint submitted via civilian reporting wizard. Tracking ID: ${complaint_id}`,
          created_at: new Date().toISOString(),
        }
      ],
      evidence: data.evidence || [],
    };
    MOCK_INCIDENTS.unshift(newInc);
    return newInc;
  },

  async updateIncidentStatus(id: string, status: IncidentStatus, actorName: string, notes?: string): Promise<Incident> {
    try {
      const res = await fetch(`${API_BASE}/incidents/${id}/status`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify({ status, notes }),
      });
      if (res.ok) {
        const updatedRaw = await res.json();
        const updated = normalizeIncident(updatedRaw);
        const idx = MOCK_INCIDENTS.findIndex(m => m.id === updated.id || m.complaint_id === updated.complaint_id);
        if (idx >= 0) MOCK_INCIDENTS[idx] = updated;
        return updated;
      }
    } catch (err) {
      console.warn(`Backend /incidents/${id}/status PATCH unavailable:`, err);
    }

    const inc = MOCK_INCIDENTS.find(i => i.id === id || i.complaint_id === id);
    if (!inc) throw new Error('Incident not found');
    inc.status = status;
    inc.updated_at = new Date().toISOString();
    if (!inc.timeline) inc.timeline = [];
    inc.timeline.push({
      id: `evt-${Date.now()}`,
      incident_id: id,
      actor_name: actorName,
      actor_role: 'Investigator',
      event_type: 'STATUS_UPDATED',
      description: `Status changed to ${status.replace(/_/g, ' ').toUpperCase()}${notes ? `. Notes: ${notes}` : ''}`,
      created_at: new Date().toISOString(),
    });
    return { ...inc };
  },

  async assignIncident(id: string, investigatorId: string, investigatorName: string): Promise<Incident> {
    try {
      const res = await fetch(`${API_BASE}/incidents/${id}/assign`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify({ investigator_id: investigatorId, investigator_name: investigatorName }),
      });
      if (res.ok) {
        const assignedRaw = await res.json();
        const assigned = normalizeIncident(assignedRaw);
        const idx = MOCK_INCIDENTS.findIndex(m => m.id === assigned.id || m.complaint_id === assigned.complaint_id);
        if (idx >= 0) MOCK_INCIDENTS[idx] = assigned;
        return assigned;
      }
    } catch (err) {
      console.warn(`Backend /incidents/${id}/assign PATCH unavailable:`, err);
    }

    const inc = MOCK_INCIDENTS.find(i => i.id === id || i.complaint_id === id);
    if (!inc) throw new Error('Incident not found');
    inc.assigned_investigator_id = investigatorId;
    inc.assigned_investigator_name = investigatorName;
    inc.status = 'investigation_in_progress';
    inc.updated_at = new Date().toISOString();
    if (!inc.timeline) inc.timeline = [];
    inc.timeline.push({
      id: `evt-${Date.now()}`,
      incident_id: id,
      actor_name: investigatorName,
      actor_role: 'Investigator',
      event_type: 'ASSIGNMENT',
      description: `Assigned to investigator ${investigatorName}. Status updated to Investigation in Progress.`,
      created_at: new Date().toISOString(),
    });
    return { ...inc };
  },

  // --- EVIDENCE ---
  async uploadEvidence(incidentId: string, file: File, uploader: { id: string; name: string }, description?: string): Promise<EvidenceItem> {
    // Generate deterministic sha-256 mock hash
    const arrayBuffer = await file.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

    const newEvidence: EvidenceItem = {
      id: `evid-${Date.now().toString().slice(-4)}`,
      incident_id: incidentId,
      file_name: file.name,
      file_size: file.size,
      file_type: file.type || 'application/octet-stream',
      file_url: URL.createObjectURL(file),
      sha256_hash: hashHex,
      uploaded_by_id: uploader.id,
      uploaded_by_name: uploader.name,
      uploaded_at: new Date().toISOString(),
      description: description || 'User submitted evidence document',
      is_verified: true,
    };

    const inc = MOCK_INCIDENTS.find(i => i.id === incidentId);
    if (inc) {
      if (!inc.evidence) inc.evidence = [];
      inc.evidence.push(newEvidence);
      inc.evidence_count = inc.evidence.length;
      if (!inc.timeline) inc.timeline = [];
      inc.timeline.push({
        id: `evt-${Date.now()}`,
        incident_id: incidentId,
        actor_name: uploader.name,
        actor_role: 'Complainant',
        event_type: 'EVIDENCE_UPLOAD',
        description: `Uploaded evidence file ${file.name} (SHA-256: ${hashHex.slice(0, 12)}...)`,
        created_at: new Date().toISOString(),
      });
    }

    return newEvidence;
  },

  // --- MESSAGES ---
  async getMessagesByIncident(incidentId: string): Promise<Message[]> {
    try {
      const res = await fetch(`${API_BASE}/messages/${encodeURIComponent(incidentId)}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          const mapped: Message[] = data.map((m: any) => ({
            id: m.id,
            conversation_id: m.conversation_id || `conv-${incidentId}`,
            incident_id: m.incident_id || incidentId,
            sender_id: m.sender_id,
            sender_name: m.sender_name,
            sender_role: m.sender_role,
            content: m.content,
            attachment_name: m.attachment_name,
            attachment_url: m.attachment_url,
            is_evidence_request: Boolean(m.is_evidence_request),
            created_at: m.created_at ? new Date(m.created_at).toISOString() : new Date().toISOString(),
          }));
          return mapped;
        }
      }
    } catch (err) {
      console.warn(`Backend /messages/${incidentId} unavailable, using fallback mock:`, err);
    }
    return MOCK_MESSAGES.filter(m => m.incident_id === incidentId);
  },

  async sendMessage(
    incidentId: string,
    sender: { id: string; name: string; role: any },
    content: string,
    isEvidenceRequest?: boolean,
    attachmentName?: string
  ): Promise<Message> {
    try {
      const res = await fetch(`${API_BASE}/messages/${encodeURIComponent(incidentId)}`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          content,
          is_evidence_request: Boolean(isEvidenceRequest),
          attachment_name: attachmentName || null,
        }),
      });
      if (res.ok) {
        const m = await res.json();
        const saved: Message = {
          id: m.id,
          conversation_id: m.conversation_id || `conv-${incidentId}`,
          incident_id: m.incident_id || incidentId,
          sender_id: m.sender_id,
          sender_name: m.sender_name,
          sender_role: m.sender_role,
          content: m.content,
          attachment_name: m.attachment_name,
          attachment_url: m.attachment_url,
          is_evidence_request: Boolean(m.is_evidence_request),
          created_at: m.created_at ? new Date(m.created_at).toISOString() : new Date().toISOString(),
        };
        MOCK_MESSAGES.push(saved);
        return saved;
      }
    } catch (err) {
      console.warn(`Backend POST /messages/${incidentId} failed, using local fallback:`, err);
    }

    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      conversation_id: `conv-${incidentId}`,
      incident_id: incidentId,
      sender_id: sender.id,
      sender_name: sender.name,
      sender_role: sender.role,
      content,
      attachment_name: attachmentName,
      is_evidence_request: isEvidenceRequest,
      created_at: new Date().toISOString(),
    };
    MOCK_MESSAGES.push(newMsg);
    const inc = MOCK_INCIDENTS.find(i => i.id === incidentId);
    if (inc) {
      inc.message_count = (inc.message_count || 0) + 1;
    }
    return newMsg;
  },

  // --- THREAT INTELLIGENCE ---
  async queryThreatIntel(indicator: string): Promise<ThreatIndicator | null> {
    // Check known mock dataset first
    const found = MOCK_THREAT_INDICATORS.find(t => t.indicator.toLowerCase() === indicator.toLowerCase());
    if (found) return found;

    // Generate dynamic real-time indicator evaluation
    const isIp = /^(\d{1,3}\.){3}\d{1,3}$/.test(indicator);
    const isHash = /^[a-fA-F0-9]{32,64}$/.test(indicator);
    const isUrl = indicator.startsWith('http://') || indicator.startsWith('https://');
    const isDomain = indicator.includes('.') && !isIp && !isUrl;

    const detectedType = isIp ? 'ip' : isHash ? 'file_hash' : isUrl ? 'url' : isDomain ? 'domain' : 'email';
    const isSuspicious = indicator.includes('phish') || indicator.includes('hack') || indicator.includes('secure-verify') || indicator.includes('mal');

    const newResult: ThreatIndicator = {
      id: `ioc-${Date.now()}`,
      indicator,
      type: detectedType,
      reputation: isSuspicious ? 'malicious' : 'clean',
      risk_score: isSuspicious ? 88 : 12,
      source: 'Sentinel Threat Grid & AbuseDB Adapter',
      category: isSuspicious ? 'Automated Heuristic Anomaly' : 'Standard Infrastructure',
      last_seen: new Date().toISOString(),
      tags: isSuspicious ? ['heuristic_match', 'flagged_indicator'] : ['whitelisted', 'low_entropy'],
      details: isSuspicious 
        ? 'Target matches algorithmic pattern of evasive phishing redirectors and short-lived proxy hosts.'
        : 'No historical threat associations or active spam campaigns detected.',
      last_checked: new Date().toISOString(),
    };
    MOCK_THREAT_INDICATORS.unshift(newResult);
    return newResult;
  },

  async getAllThreatIndicators(): Promise<ThreatIndicator[]> {
    return [...MOCK_THREAT_INDICATORS];
  },

  // --- AI CAPABILITIES ---
  async getCivilianAIAdvice(prompt: string, category?: string): Promise<{ answer: string; tips: string[]; safetyChecklist: string[] }> {
    // Specialized, grounded cyber safety responses without false promises
    const p = prompt.toLowerCase();
    if (p.includes('scam') || p.includes('money') || p.includes('wire') || p.includes('bank') || p.includes('upi')) {
      return {
        answer: 'You may be dealing with a financial social engineering scam. Scammers often create artificial urgency, claiming your account will be frozen or asking you to wire funds or approve unknown payment requests immediately.',
        tips: [
          'Immediately contact your bank or payment app fraud support to place a hold on recent transfers.',
          'Never share one-time passcodes (OTP), UPI PINs, or remote desktop codes (AnyDesk, TeamViewer).',
          'Export your bank transaction statement PDF and keep screenshots of all SMS/WhatsApp messages.',
          'File a formal report on Sentinel Grid so investigators can catalog the suspect banking details.',
        ],
        safetyChecklist: [
          'Changed banking and email passwords',
          'Revoked unfamiliar devices from Google/Apple accounts',
          'Called official bank fraud number (printed on your debit/credit card)',
          'Preserved unmodified screenshots with timestamps visible',
        ]
      };
    } else if (p.includes('hack') || p.includes('password') || p.includes('instagram') || p.includes('facebook') || p.includes('account')) {
      return {
        answer: 'If your account was compromised, attackers typically change the recovery email or phone number first to lock you out. It is crucial to cut off attacker access and secure connected accounts.',
        tips: [
          'Use the official platform account recovery page (e.g., instagram.com/hacked).',
          'Check your email inbox filters and trash folder for unauthorized password reset emails.',
          'Enable Two-Factor Authentication (2FA) using an authenticator app rather than SMS if possible.',
          'Alert your friends or followers via another channel so they do not fall for requests sent from your compromised profile.',
        ],
        safetyChecklist: [
          'Checked for rogue email forwarding rules',
          'Terminated all other active sessions across devices',
          'Created a unique 16+ character password using a password manager',
          'Documented profile link and handle of impersonator',
        ]
      };
    }

    return {
      answer: 'Sentinel Grid AI Security Assistant is here to help you understand cyber threats, preserve digital evidence, and file actionable complaints. Remember: we provide security guidance and evidence preservation assistance, but do not provide legal counsel or replace emergency law enforcement.',
      tips: [
        'Preserve original evidence (full email headers, uncropped screenshots, transaction IDs).',
        'Do not delete scammer chat threads or call logs; investigators need unaltered evidence.',
        'File an incident report under the appropriate category to route it to specialized investigators.',
      ],
      safetyChecklist: [
        'Identified the exact date, time, and platform of the incident',
        'Saved copies of all suspect communications',
        'Verified your own login credentials on critical accounts',
      ]
    };
  },

  async getInvestigatorAICopilot(incidentId: string): Promise<AIAnalysisResult> {
    const inc = MOCK_INCIDENTS.find(i => i.id === incidentId) || MOCK_INCIDENTS[0];
    
    return {
      incident_id: inc.id,
      summary: `Automated Forensic Copilot Analysis for ${inc.complaint_id}: Incident involves reported ${inc.category.replace(/_/g, ' ')} with observed indicators of social engineering, infrastructure impersonation, and unauthorized transaction attempts.`,
      key_findings: [
        `Reported financial exposure: ${inc.financial_loss ? `$${inc.financial_loss.toLocaleString()}` : 'Non-monetary exfiltration'}.`,
        'Evidence artifacts contain RFC 822 email headers indicating SPF/DKIM validation failures.',
        'Suspect infrastructure utilizes fast-flux IP delegation and bulletproof VPS hosting.',
        'Communication telemetry indicates ongoing victim targeting via secondary SMS channel.',
      ],
      indicators_of_compromise: [
        '194.26.29.112 (Target IP - High Risk)',
        'pay-secure-corporate.net (Domain Typosquat)',
        'SHA-256: 8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4',
      ],
      mitre_techniques: [
        {
          id: 'T1566.002',
          name: 'Phishing: Spearphishing Link',
          tactic: 'Initial Access',
          description: 'Adversary transmitted malicious URLs via corporate email mimicking official payment portal.',
        },
        {
          id: 'T1539',
          name: 'Steal Web Session Cookie',
          tactic: 'Credential Access',
          description: 'Fake authentication portal used reverse proxy to capture session tokens and bypass MFA.',
        },
        {
          id: 'T1071.001',
          name: 'Application Layer Protocol: Web Protocols',
          tactic: 'Command and Control',
          description: 'HTTP/HTTPS sessions established against adversary-controlled infrastructure.',
        },
      ],
      suggested_questions: [
        'Did the complainant authorize or accept any push notifications from Microsoft Authenticator or Duo at the specified time?',
        'Can the civilian provide the wire routing number and receiving beneficiary bank account number?',
        'Are other enterprise mailboxes receiving similar emails with the pay-secure-corporate.net domain?',
      ],
      recommended_actions: [
        'Issue immediate domain registrar takedown request to registrar abuse contact.',
        'Request complainant submit full unredacted bank transfer receipt with SWIFT Reference.',
        'Coordinate with corporate SOC to search mail server logs for recipient scope.',
        'Recommend escalating case priority to HIGH based on active wire transaction window.',
      ],
      recommended_severity: inc.severity,
      confidence_score: 91,
      caveat_notes: 'Analysis grounded strictly in uploaded evidence headers and confirmed IOC telemetry. No destructive actions will be executed without investigator authorization.',
    };
  },

  // --- SOC & ALERTS ---
  async getAlerts(filters?: { severity?: string }): Promise<SecurityAlert[]> {
    try {
      const params = new URLSearchParams();
      if (filters?.severity && filters.severity !== 'all') params.append('severity', filters.severity);
      const res = await fetch(`${API_BASE}/alerts/?${params.toString()}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          return data;
        }
      }
    } catch (err) {
      console.warn('Backend /alerts/ unavailable, using fallback alerts:', err);
    }
    let result = [...MOCK_ALERTS];
    if (filters?.severity && filters.severity !== 'all') {
      result = result.filter(a => a.severity === filters.severity);
    }
    return result;
  },

  async getPlaybooks(): Promise<ResponsePlaybook[]> {
    return [...MOCK_PLAYBOOKS];
  },

  async updatePlaybookStepStatus(playbookId: string, stepNumber: number, status: 'pending' | 'in_progress' | 'completed' | 'skipped'): Promise<ResponsePlaybook> {
    const pb = MOCK_PLAYBOOKS.find(p => p.id === playbookId);
    if (!pb) throw new Error('Playbook not found');
    const step = pb.steps.find(s => s.step_number === stepNumber);
    if (step) {
      step.status = status;
    }
    return { ...pb };
  },

  async getAuditLogs(): Promise<AuditLogEntry[]> {
    return [...MOCK_AUDIT_LOGS];
  },

  async logAuditEvent(action: string, targetResource: string, targetId: string, details: string, user: { id: string; name: string; role: string }): Promise<AuditLogEntry> {
    const entry: AuditLogEntry = {
      id: `aud-${Date.now()}`,
      user_id: user.id,
      user_name: user.name,
      user_role: user.role,
      action,
      target_resource: targetResource,
      target_id: targetId,
      ip_address: '127.0.0.1',
      created_at: new Date().toISOString(),
      details,
    };
    MOCK_AUDIT_LOGS.unshift(entry);
    return entry;
  },
};
