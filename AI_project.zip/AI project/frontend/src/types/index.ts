export type UserRole = 'civilian' | 'investigator' | 'senior_investigator' | 'admin';

export interface User {
  id: string;
  email: string;
  full_name: string;
  phone?: string;
  gender?: 'female' | 'male' | 'other';
  role: UserRole;
  organization_id?: string;
  organization_name?: string;
  badge_number?: string;
  department?: string;
  avatar_url?: string;
  is_active: boolean;
  is_verified: boolean;
  created_at: string;
}

export type IncidentCategory = 
  | 'phishing'
  | 'financial_fraud'
  | 'identity_theft'
  | 'account_hacking'
  | 'cyberbullying'
  | 'social_media_fraud'
  | 'malware'
  | 'impersonation'
  | 'data_breach'
  | 'other';

export type IncidentStatus = 
  | 'submitted'
  | 'under_review'
  | 'assigned'
  | 'investigation_in_progress'
  | 'additional_info_required'
  | 'resolved'
  | 'closed';

export type IncidentSeverity = 'low' | 'medium' | 'high' | 'critical';

export interface EvidenceItem {
  id: string;
  incident_id: string;
  file_name: string;
  file_size: number;
  file_type: string;
  file_url: string;
  sha256_hash: string;
  uploaded_by_id: string;
  uploaded_by_name: string;
  uploaded_at: string;
  description?: string;
  is_verified: boolean;
}

export interface IncidentEvent {
  id: string;
  incident_id: string;
  actor_name: string;
  actor_role: string;
  event_type: string;
  description: string;
  metadata?: Record<string, any>;
  created_at: string;
}

export interface IncidentNote {
  id: string;
  incident_id: string;
  author_id: string;
  author_name: string;
  author_role: string;
  content: string;
  is_internal_only: boolean;
  created_at: string;
}

export interface Incident {
  id: string;
  complaint_id: string; // e.g. SG-2026-8921
  title: string;
  category: IncidentCategory;
  severity: IncidentSeverity;
  status: IncidentStatus;
  description: string;
  incident_date: string;
  incident_time?: string;
  platform_involved?: string;
  suspect_info?: string;
  website_url?: string;
  financial_loss?: number;
  currency?: string;
  contact_email: string;
  contact_phone?: string;
  latitude?: number;
  longitude?: number;
  location_name?: string;
  city?: string;
  region?: string;
  country?: string;
  reporter_ip?: string;
  civilian_id: string;
  civilian_name: string;
  assigned_investigator_id?: string;
  assigned_investigator_name?: string;
  organization_id?: string;
  created_at: string;
  updated_at: string;
  evidence_count?: number;
  message_count?: number;
  evidence?: EvidenceItem[];
  timeline?: IncidentEvent[];
  notes?: IncidentNote[];
}

export interface Message {
  id: string;
  conversation_id: string;
  incident_id: string;
  sender_id: string;
  sender_name: string;
  sender_role: UserRole;
  content: string;
  attachment_url?: string;
  attachment_name?: string;
  is_evidence_request?: boolean;
  read_by?: string[];
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: 'incident_status' | 'new_message' | 'assignment' | 'evidence_request' | 'security_alert' | 'escalation';
  link_url?: string;
  is_read: boolean;
  created_at: string;
}

export interface ThreatIndicator {
  id: string;
  indicator: string;
  type: 'ip' | 'domain' | 'url' | 'file_hash' | 'email';
  reputation: 'clean' | 'suspicious' | 'malicious' | 'unknown';
  risk_score: number; // 0-100
  source: string;
  category?: string;
  last_seen?: string;
  tags: string[];
  details: string;
  last_checked: string;
}

export interface SecurityEvent {
  id: string;
  event_time: string;
  source_ip: string;
  destination_ip: string;
  event_type: string;
  severity: IncidentSeverity;
  source_system: string;
  raw_payload?: string;
  normalized_fields: Record<string, any>;
  correlated_incident_id?: string;
}

export interface SecurityAlert {
  id: string;
  title: string;
  description: string;
  severity: IncidentSeverity;
  status: 'new' | 'investigating' | 'correlated' | 'dismissed';
  source: string;
  detection_rule_name: string;
  created_at: string;
  correlated_incident_id?: string;
}

export interface ResponsePlaybook {
  id: string;
  name: string;
  category: IncidentCategory;
  description: string;
  steps: {
    step_number: number;
    title: string;
    description: string;
    requires_approval: boolean;
    status: 'pending' | 'in_progress' | 'completed' | 'skipped';
  }[];
}

export interface AuditLogEntry {
  id: string;
  user_id: string;
  user_name: string;
  user_role: string;
  action: string;
  target_resource: string;
  target_id: string;
  ip_address: string;
  created_at: string;
  details: string;
}

export interface AIAnalysisResult {
  incident_id?: string;
  summary: string;
  key_findings: string[];
  indicators_of_compromise: string[];
  mitre_techniques: {
    id: string;
    name: string;
    tactic: string;
    description: string;
  }[];
  suggested_questions: string[];
  recommended_actions: string[];
  recommended_severity: IncidentSeverity;
  confidence_score: number;
  caveat_notes: string;
}
