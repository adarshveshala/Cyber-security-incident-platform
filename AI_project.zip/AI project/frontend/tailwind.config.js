/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          blue: '#2563EB',
          'blue-hover': '#1D4ED8',
          'blue-light': '#EFF6FF',
          teal: '#0D9488',
          'teal-hover': '#0F766E',
          'teal-light': '#F0FDFA',
          bg: '#F7FAFC',
          surface: '#FFFFFF',
          heading: '#172554',
          body: '#475569',
          border: '#E2E8F0',
          success: '#16A34A',
          'success-light': '#F0FDF4',
          warning: '#F59E0B',
          'warning-light': '#FFFBEB',
          critical: '#DC2626',
          'critical-light': '#FEF2F2',
          info: '#3B82F6',
          'info-light': '#EFF6FF',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      boxShadow: {
        'soft': '0 2px 8px 0 rgba(0, 0, 0, 0.04), 0 1px 2px 0 rgba(0, 0, 0, 0.02)',
        'card': '0 4px 16px -2px rgba(15, 23, 42, 0.05), 0 2px 6px -1px rgba(15, 23, 42, 0.03)',
        'modal': '0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 10px 10px -5px rgba(15, 23, 42, 0.04)',
      }
    },
  },
  plugins: [],
}
