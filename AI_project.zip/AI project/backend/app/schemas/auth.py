from pydantic import BaseModel
from typing import Optional

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    user_id: str
    full_name: str

class TokenPayload(BaseModel):
    sub: Optional[str] = None
    role: Optional[str] = None

class CivilianRegister(BaseModel):
    full_name: str
    email: str
    phone: Optional[str] = None
    password: str
    avatar_url: Optional[str] = None
    gender: Optional[str] = None

class LoginRequest(BaseModel):
    email: str
    password: str
    badge_number: Optional[str] = None
