from pydantic import BaseModel, ConfigDict
from typing import Optional, List, Dict, Any
from datetime import datetime

class EvidenceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    incident_id: str
    file_name: str
    file_size: int
    file_type: str
    sha256_hash: str
    uploaded_by_name: str
    description: Optional[str] = None
    is_verified: bool
    created_at: datetime

class IncidentEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    actor_name: str
    actor_role: str
    event_type: str
    description: str
    created_at: datetime

class IncidentCreate(BaseModel):
    title: str
    category: str
    severity: Optional[str] = "medium"
    description: str
    incident_date: str
    incident_time: Optional[str] = None
    platform_involved: Optional[str] = None
    suspect_info: Optional[str] = None
    website_url: Optional[str] = None
    financial_loss: Optional[float] = 0.0
    currency: Optional[str] = "USD"
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    location_name: Optional[str] = None
    city: Optional[str] = None
    region: Optional[str] = None
    country: Optional[str] = None
    reporter_ip: Optional[str] = None
    contact_email: str
    contact_phone: Optional[str] = None

class IncidentStatusUpdate(BaseModel):
    status: str
    notes: Optional[str] = None

class IncidentAssign(BaseModel):
    investigator_id: str
    investigator_name: str

class IncidentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    complaint_id: str
    title: str
    category: str
    severity: str
    status: str
    description: str
    incident_date: str
    incident_time: Optional[str] = None
    platform_involved: Optional[str] = None
    suspect_info: Optional[str] = None
    website_url: Optional[str] = None
    financial_loss: Optional[float] = 0.0
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    location_name: Optional[str] = None
    city: Optional[str] = None
    region: Optional[str] = None
    country: Optional[str] = None
    reporter_ip: Optional[str] = None
    contact_email: str
    contact_phone: Optional[str] = None
    civilian_id: str
    civilian_name: str
    assigned_investigator_id: Optional[str] = None
    assigned_investigator_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    evidence: List[EvidenceOut] = []
    timeline_events: List[IncidentEventOut] = []
