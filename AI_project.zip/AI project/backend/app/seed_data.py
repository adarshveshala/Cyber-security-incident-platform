from sqlalchemy import select
from app.core.database import SessionLocal
from app.core.security import get_password_hash
from app.models.entities import (
    Role,
    User,
    CivilianProfile,
    InvestigatorProfile,
    Incident,
    IncidentEvent,
    ThreatIndicator,
    Alert,
    AuditLog
)

def seed_initial_data():
    with SessionLocal() as session:
        # Check if roles exist
        res = session.execute(select(Role)).scalars().first()
        if res:
            return # Already seeded

        # 1. Create Roles
        civ_role = Role(name="civilian", description="Civilian Complainant")
        inv_role = Role(name="investigator", description="Digital Forensics & SOC Investigator")
        senior_role = Role(name="senior_investigator", description="Senior Lead Detective")
        adm_role = Role(name="admin", description="Platform Security Administrator")
        session.add_all([civ_role, inv_role, senior_role, adm_role])
        session.flush()

        # 2. Create Users
        civ_user = User(
            email="sarah.connor@example.com",
            hashed_password=get_password_hash("CyberSafe@2026"),
            full_name="Sarah Connor",
            phone="+1 (555) 234-5678",
            avatar_url="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150",
            roles=[civ_role]
        )
        session.add(civ_user)
        session.flush()

        civ_profile = CivilianProfile(
            user_id=civ_user.id,
            emergency_contact_phone="+1 (555) 999-8888",
            preferred_contact_method="email",
            two_factor_enabled=True
        )
        session.add(civ_profile)

        inv_user = User(
            email="marcus.vance@sentinelgrid.io",
            hashed_password=get_password_hash("SpecialAgent#9042"),
            full_name="Special Agent Marcus Vance",
            avatar_url="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150",
            roles=[inv_role]
        )
        session.add(inv_user)
        session.flush()

        inv_profile = InvestigatorProfile(
            user_id=inv_user.id,
            badge_number="SG-INV-8492",
            department="Cyber Fraud & Ransomware Unit",
            security_clearance_level="Level 3 - Secret"
        )
        session.add(inv_profile)

        senior_user = User(
            email="elena.rostova@sentinelgrid.io",
            hashed_password=get_password_hash("LeadDetective#1049"),
            full_name="Lead Detective Elena Rostova",
            avatar_url="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150",
            roles=[senior_role]
        )
        session.add(senior_user)
        session.flush()

        senior_profile = InvestigatorProfile(
            user_id=senior_user.id,
            badge_number="SG-LEAD-1049",
            department="Advanced Threat Triage & Incident Response",
            security_clearance_level="Level 4 - Top Secret"
        )
        session.add(senior_profile)

        # 3. Create Seed Incident
        inc = Incident(
            complaint_id="SG-2026-8921",
            title="Executive Phishing & Wire Redirection Fraud",
            category="financial_fraud",
            severity="high",
            status="investigation_in_progress",
            description="Received spoofed spear-phishing email impersonating corporate finance officer requesting urgent vendor routing number update. Approximately $34,500 wire attempted through falsified payment gateway.",
            incident_date="2026-11-14",
            incident_time="14:32",
            platform_involved="Corporate Outlook / Swift Transfer",
            suspect_info="Email sender: admin@pay-secure-corporate.net, Destination IP: 194.26.29.112",
            website_url="https://pay-secure-corporate.net/portal/auth",
            financial_loss=34500.0,
            currency="USD",
            latitude=40.7128,
            longitude=-74.0060,
            location_name="New York, USA",
            contact_email="sarah.connor@example.com",
            contact_phone="+1 (555) 234-5678",
            civilian_id=civ_user.id,
            civilian_name="Sarah Connor",
            assigned_investigator_id=inv_user.id,
            assigned_investigator_name="Special Agent Marcus Vance"
        )
        session.add(inc)
        session.flush()

        evt = IncidentEvent(
            incident_id=inc.id,
            actor_name="Sarah Connor",
            actor_role="Civilian",
            event_type="REPORT_SUBMITTED",
            description="Complaint registered via civilian portal with RFC 822 email evidence."
        )
        session.add(evt)

        # 4. Threat Indicators
        ioc1 = ThreatIndicator(
            indicator="194.26.29.112",
            indicator_type="ip",
            reputation="malicious",
            risk_score=94,
            source="AbuseIPDB & Sentinel Threat Grid",
            category="Phishing Command & Control",
            tags=["phishing", "bulletproof_vps", "fast_flux"],
            details="Associated with spoofed banking landing pages and automated credential harvesting kits."
        )
        ioc2 = ThreatIndicator(
            indicator="pay-secure-corporate.net",
            indicator_type="domain",
            reputation="malicious",
            risk_score=98,
            source="VirusTotal & STIX Feed",
            category="Typosquatting & Wire Fraud",
            tags=["typosquatting", "impersonation"],
            details="Registered 3 days prior to campaign. DNS resolving to fast-flux IP pool."
        )
        session.add_all([ioc1, ioc2])

        # 5. Security Alerts
        alt1 = Alert(
            detection_rule_name="SOC-RULE-BRUTEFORCE-SSH",
            title="Multiple Failed Root Login Attempts",
            description="142 brute force attempts on SSH port 22 from 185.220.101.5 in under 3 minutes.",
            severity="high",
            status="new",
            source="Auth.log Ingestion Pipeline"
        )
        alt2 = Alert(
            detection_rule_name="SOC-RULE-ANONYMIZER-API",
            title="Tor Exit Node Connection to Banking API",
            description="Inbound TLS session established from known Tor exit relay 185.107.56.211.",
            severity="critical",
            status="investigating",
            source="WAF Gateway Ingestion",
            correlated_incident_id=inc.id
        )
        session.add_all([alt1, alt2])

        # 6. Audit Log
        audit = AuditLog(
            user_id=inv_user.id,
            user_name="Special Agent Marcus Vance",
            user_role="investigator",
            action="INCIDENT_ASSIGNMENT_ACCEPTED",
            target_resource="Incident",
            target_id="SG-2026-8921",
            ip_address="10.240.12.8",
            details="Accepted ownership of complaint SG-2026-8921 from triage queue."
        )
        session.add(audit)

        session.commit()
