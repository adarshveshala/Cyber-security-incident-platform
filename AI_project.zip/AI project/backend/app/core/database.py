import os
import sqlite3
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from app.core.config import settings

# Determine database engine URL
db_url = settings.DATABASE_URL
if db_url.startswith("sqlite+aiosqlite://"):
    db_url = db_url.replace("sqlite+aiosqlite://", "sqlite://")
elif db_url.startswith("postgresql+asyncpg://"):
    db_url = db_url.replace("postgresql+asyncpg://", "postgresql+pg8000://")
elif db_url.startswith("postgresql://"):
    db_url = db_url.replace("postgresql://", "postgresql+pg8000://")
elif db_url.startswith("postgresql+psycopg2://"):
    db_url = db_url.replace("postgresql+psycopg2://", "postgresql+pg8000://")

is_sqlite = "sqlite" in db_url

engine = create_engine(
    db_url,
    echo=False,
    connect_args={"check_same_thread": False} if is_sqlite else {},
    pool_pre_ping=True
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def sync_sqlite_mirrors():
    """Ensures root sentinel_grid.db and backend/sentinel_grid.db are always synchronized."""
    try:
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        root_db = os.path.join(os.path.dirname(base_dir), "sentinel_grid.db")
        backend_db = os.path.join(base_dir, "sentinel_grid.db")
        if os.path.exists(root_db) and root_db != backend_db:
            with sqlite3.connect(root_db) as src, sqlite3.connect(backend_db) as dst:
                src.backup(dst)
    except Exception:
        pass

def get_db():
    db = SessionLocal()
    try:
        yield db
        db.commit()
        if is_sqlite:
            sync_sqlite_mirrors()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
