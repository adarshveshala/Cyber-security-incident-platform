from typing import List
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
import os

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        case_sensitive=True,
        env_file=[
            os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), ".env"),
            os.path.join(os.getcwd(), ".env"),
            os.path.join(os.getcwd(), "backend", ".env"),
            ".env"
        ],
        extra="ignore"
    )

    PROJECT_NAME: str = "SENTINEL GRID"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    
    # Security & JWT
    SECRET_KEY: str = Field(default="sentinel-grid-super-secure-production-jwt-secret-key-2026-x90214")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7 # 7 days
    ALGORITHM: str = "HS256"
    
    # PostgreSQL Database URL
    DATABASE_URL: str = Field(
        default="postgresql+pg8000://postgres:6622@127.0.0.1:5432/sentinelgrid"
    )
    
    # CORS
    BACKEND_CORS_ORIGINS: List[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ]
    
    # Evidence Vault
    EVIDENCE_UPLOAD_DIR: str = os.path.join(os.getcwd(), "evidence_vault")
    MAX_EVIDENCE_FILE_SIZE_MB: int = 50

settings = Settings()

# Ensure evidence vault directory exists
os.makedirs(settings.EVIDENCE_UPLOAD_DIR, exist_ok=True)
