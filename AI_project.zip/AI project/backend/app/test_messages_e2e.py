import urllib.request, json
from app.core.security import create_access_token

token_marcus = create_access_token('4e8cb24d-bcf0-4596-9196-635efd780914', role='investigator')
token_sarah = create_access_token('6cefc9db-0389-4871-894e-1a5fa8278204', role='civilian')
token_adarsh = create_access_token('db9feaea-9c82-46f3-9322-b59d86498612', role='civilian')

print("Fetching messages for Adarsh (SG-2026-2171)...")
req = urllib.request.Request('http://127.0.0.1:8000/api/v1/messages/SG-2026-2171', headers={'Authorization': f'Bearer {token_adarsh}'})
res = urllib.request.urlopen(req)
msgs_adarsh = json.loads(res.read())
print(f"-> Adarsh fetched {len(msgs_adarsh)} messages:")
for m in msgs_adarsh:
    print(f"   [{m['sender_role']}] {m['sender_name']}: {m['content'][:60]}")

print("1. Fetching messages as Marcus Vance for SG-2026-9524...")
req = urllib.request.Request('http://127.0.0.1:8000/api/v1/messages/SG-2026-9524', headers={'Authorization': f'Bearer {token_marcus}'})
res = urllib.request.urlopen(req)
msgs = json.loads(res.read())
print(f"-> Marcus fetched {len(msgs)} messages:")
for m in msgs:
    print(f"   [{m['sender_role']}] {m['sender_name']}: {m['content'][:60]}")

print("\n2. Marcus sending a message...")
post_data = json.dumps({'content': 'Agent Vance: Investigating QR manipulation at payment switch.', 'is_evidence_request': False}).encode()
req = urllib.request.Request('http://127.0.0.1:8000/api/v1/messages/SG-2026-9524', data=post_data, headers={'Authorization': f'Bearer {token_marcus}', 'Content-Type': 'application/json'}, method='POST')
res = urllib.request.urlopen(req)
created = json.loads(res.read())
print(f"-> Marcus sent message: ID={created['id']}")

print("\n3. Sarah fetching messages for SG-2026-9524...")
req = urllib.request.Request('http://127.0.0.1:8000/api/v1/messages/SG-2026-9524', headers={'Authorization': f'Bearer {token_sarah}'})
res = urllib.request.urlopen(req)
msgs_sarah = json.loads(res.read())
print(f"-> Sarah sees {len(msgs_sarah)} messages. Latest message:")
print(f"   {msgs_sarah[-1]['sender_name']}: {msgs_sarah[-1]['content']}")

print("\n4. Sarah sending a reply...")
post_sarah = json.dumps({'content': 'Sarah: Thank you Agent Vance. I have preserved the physical terminal.', 'is_evidence_request': False}).encode()
req = urllib.request.Request('http://127.0.0.1:8000/api/v1/messages/SG-2026-9524', data=post_sarah, headers={'Authorization': f'Bearer {token_sarah}', 'Content-Type': 'application/json'}, method='POST')
res = urllib.request.urlopen(req)
created_sarah = json.loads(res.read())
print(f"-> Sarah sent reply: ID={created_sarah['id']}")

print("\n5. Verification complete! Real-time bidirectional database persistence verified.")
