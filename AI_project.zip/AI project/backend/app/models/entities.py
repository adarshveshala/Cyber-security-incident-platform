import uuid
from datetime import datetime
from sqlalchemy import (
    Column, String, Text, Integer, Float, Boolean, DateTime, ForeignKey, Enum, Table, Index, JSON
)
from sqlalchemy.orm import relationship
from app.core.database import Base

def generate_uuid() -> str:
    return str(uuid.uuid4())

# Many-to-Many Association: user_roles
user_roles = Table(
    "user_roles",
    Base.metadata,
    Column("user_id", String(36), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    Column("role_id", String(36), ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
)

# Many-to-Many Association: role_permissions
role_permissions = Table(
    "role_permissions",
    Base.metadata,
    Column("role_id", String(36), ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
    Column("permission_id", String(36), ForeignKey("permissions.id", ondelete="CASCADE"), primary_key=True),
)

# Many-to-Many Association: conversation_members
conversation_members = Table(
    "conversation_members",
    Base.metadata,
    Column("conversation_id", String(36), ForeignKey("conversations.id", ondelete="CASCADE"), primary_key=True),
    Column("user_id", String(36), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    Column("joined_at", DateTime, default=datetime.utcnow),
)

# 1. ORGANIZATIONS
class Organization(Base):
    __tablename__ = "organizations"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    name = Column(String(255), nullable=False)
    domain = Column(String(255), unique=True, index=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    users = relationship("User", back_populates="organization")
    incidents = relationship("Incident", back_populates="organization")

# 2. PERMISSIONS
class Permission(Base):
    __tablename__ = "permissions"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    code = Column(String(100), unique=True, nullable=False, index=True) # e.g. incident:triage, evidence:export
    description = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)

# 3. ROLES
class Role(Base):
    __tablename__ = "roles"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    name = Column(String(50), unique=True, nullable=False) # civilian, investigator, senior_investigator, admin
    description = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)

    permissions = relationship("Permission", secondary=role_permissions)

# 4. USERS
class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    phone = Column(String(50), nullable=True)
    avatar_url = Column(Text, nullable=True)
    organization_id = Column(String(36), ForeignKey("organizations.id"), nullable=True)
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    organization = relationship("Organization", back_populates="users")
    roles = relationship("Role", secondary=user_roles)
    civilian_profile = relationship("CivilianProfile", back_populates="user", uselist=False)
    investigator_profile = relationship("InvestigatorProfile", back_populates="user", uselist=False)

# 5. CIVILIAN PROFILES
class CivilianProfile(Base):
    __tablename__ = "civilian_profiles"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    emergency_contact_phone = Column(String(50), nullable=True)
    preferred_contact_method = Column(String(50), default="email")
    two_factor_enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="civilian_profile")

# 6. INVESTIGATOR PROFILES
class InvestigatorProfile(Base):
    __tablename__ = "investigator_profiles"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    badge_number = Column(String(50), unique=True, nullable=False, index=True)
    department = Column(String(100), nullable=False)
    security_clearance_level = Column(String(50), default="Level 3 - Secret")
    active_caseload_limit = Column(Integer, default=15)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="investigator_profile")

# 7. INCIDENTS
class Incident(Base):
    __tablename__ = "incidents"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    complaint_id = Column(String(50), unique=True, nullable=False, index=True) # e.g. SG-2026-8921
    title = Column(String(255), nullable=False)
    category = Column(String(50), nullable=False, index=True) # phishing, financial_fraud, malware, etc.
    severity = Column(String(20), default="medium", index=True) # low, medium, high, critical
    status = Column(String(50), default="submitted", index=True) # submitted, under_review, assigned, investigation_in_progress, resolved, closed
    description = Column(Text, nullable=False)
    incident_date = Column(String(20), nullable=False)
    incident_time = Column(String(20), nullable=True)
    platform_involved = Column(String(255), nullable=True)
    suspect_info = Column(String(500), nullable=True)
    website_url = Column(String(500), nullable=True)
    financial_loss = Column(Float, default=0.0)
    currency = Column(String(10), default="USD")
    latitude = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)
    location_name = Column(String(255), nullable=True)
    reporter_ip = Column(String(50), nullable=True)
    contact_email = Column(String(255), nullable=False)
    contact_phone = Column(String(50), nullable=True)
    civilian_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    civilian_name = Column(String(255), nullable=False)
    assigned_investigator_id = Column(String(36), ForeignKey("users.id"), nullable=True)
    assigned_investigator_name = Column(String(255), nullable=True)
    organization_id = Column(String(36), ForeignKey("organizations.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    organization = relationship("Organization", back_populates="incidents")
    evidence = relationship("Evidence", back_populates="incident", cascade="all, delete-orphan")
    timeline_events = relationship("IncidentEvent", back_populates="incident", cascade="all, delete-orphan")
    notes = relationship("IncidentNote", back_populates="incident", cascade="all, delete-orphan")

# 8. INCIDENT ASSIGNMENTS
class IncidentAssignment(Base):
    __tablename__ = "incident_assignments"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    investigator_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    assigned_by_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    assigned_at = Column(DateTime, default=datetime.utcnow)
    unassigned_at = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)

# 9. INCIDENT NOTES
class IncidentNote(Base):
    __tablename__ = "incident_notes"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    author_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    author_name = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    is_internal_only = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    incident = relationship("Incident", back_populates="notes")

# 10. INCIDENT EVENTS (Forensic Audit Timeline)
class IncidentEvent(Base):
    __tablename__ = "incident_events"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    actor_name = Column(String(255), nullable=False)
    actor_role = Column(String(50), nullable=False)
    event_type = Column(String(100), nullable=False)
    description = Column(Text, nullable=False)
    extra_metadata = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    incident = relationship("Incident", back_populates="timeline_events")

# 11. EVIDENCE
class Evidence(Base):
    __tablename__ = "evidence"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    file_name = Column(String(255), nullable=False)
    file_size = Column(Integer, nullable=False)
    file_type = Column(String(100), nullable=False)
    storage_path = Column(String(500), nullable=False)
    sha256_hash = Column(String(64), nullable=False, index=True)
    uploaded_by_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    uploaded_by_name = Column(String(255), nullable=False)
    description = Column(String(500), nullable=True)
    is_verified = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    incident = relationship("Incident", back_populates="evidence")

# 12. CONVERSATIONS
class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), unique=True, nullable=False)
    title = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    members = relationship("User", secondary=conversation_members)
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan")

# 13. MESSAGES
class Message(Base):
    __tablename__ = "messages"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    conversation_id = Column(String(36), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    sender_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    sender_name = Column(String(255), nullable=False)
    sender_role = Column(String(50), nullable=False)
    content = Column(Text, nullable=False)
    attachment_name = Column(String(255), nullable=True)
    is_evidence_request = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    conversation = relationship("Conversation", back_populates="messages")

# 14. NOTIFICATIONS
class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    type = Column(String(50), nullable=False)
    link_url = Column(String(500), nullable=True)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

# 15. LOG SOURCES (SOC)
class LogSource(Base):
    __tablename__ = "log_sources"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    name = Column(String(100), nullable=False)
    source_type = Column(String(50), nullable=False) # syslog, winevent, cloudtrail, waf
    ip_or_hostname = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

# 16. SECURITY EVENTS (Normalized Ingestion)
class SecurityEvent(Base):
    __tablename__ = "security_events"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    log_source_id = Column(String(36), ForeignKey("log_sources.id"), nullable=True)
    event_time = Column(DateTime, default=datetime.utcnow, index=True)
    source_ip = Column(String(45), nullable=True, index=True)
    destination_ip = Column(String(45), nullable=True, index=True)
    event_type = Column(String(100), nullable=False)
    severity = Column(String(20), default="low")
    raw_payload = Column(Text, nullable=True)
    normalized_data = Column(JSON, nullable=True)
    correlated_incident_id = Column(String(36), ForeignKey("incidents.id"), nullable=True)

# 17. DETECTION RULES (SOC)
class DetectionRule(Base):
    __tablename__ = "detection_rules"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    name = Column(String(255), unique=True, nullable=False)
    severity = Column(String(20), default="medium")
    query_condition = Column(Text, nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

# 18. ALERTS (SOC Alert Feed)
class Alert(Base):
    __tablename__ = "alerts"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    detection_rule_id = Column(String(36), ForeignKey("detection_rules.id"), nullable=True)
    detection_rule_name = Column(String(255), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    severity = Column(String(20), default="medium", index=True)
    status = Column(String(50), default="new")
    source = Column(String(100), nullable=False)
    correlated_incident_id = Column(String(36), ForeignKey("incidents.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

# 19. ASSETS
class Asset(Base):
    __tablename__ = "assets"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    name = Column(String(255), nullable=False)
    asset_type = Column(String(50), nullable=False) # server, workstation, firewall, cloud_storage
    ip_address = Column(String(45), nullable=True)
    mac_address = Column(String(50), nullable=True)
    criticality = Column(String(20), default="medium")
    owner_name = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

# 20. THREAT INDICATORS
class ThreatIndicator(Base):
    __tablename__ = "threat_indicators"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    indicator = Column(String(500), unique=True, nullable=False, index=True)
    indicator_type = Column(String(50), nullable=False) # ip, domain, url, file_hash, email
    reputation = Column(String(50), default="unknown") # clean, suspicious, malicious, unknown
    risk_score = Column(Integer, default=0)
    source = Column(String(100), default="Sentinel Threat Grid")
    category = Column(String(100), nullable=True)
    tags = Column(JSON, default=list)
    details = Column(Text, nullable=True)
    last_checked = Column(DateTime, default=datetime.utcnow)

# 21. THREAT INTELLIGENCE RESULTS
class ThreatIntelligenceResult(Base):
    __tablename__ = "threat_intelligence_results"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    indicator_id = Column(String(36), ForeignKey("threat_indicators.id", ondelete="CASCADE"), nullable=False)
    provider_name = Column(String(50), nullable=False) # VirusTotal, AbuseIPDB, STIX_Feed
    raw_response = Column(JSON, nullable=False)
    queried_at = Column(DateTime, default=datetime.utcnow)

# 22. AI ANALYSES
class AIAnalysis(Base):
    __tablename__ = "ai_analyses"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    summary = Column(Text, nullable=False)
    key_findings = Column(JSON, default=list)
    mitre_techniques = Column(JSON, default=list)
    suggested_questions = Column(JSON, default=list)
    recommended_actions = Column(JSON, default=list)
    confidence_score = Column(Integer, default=85)
    model_provider = Column(String(50), default="internal_secure_llm")
    created_at = Column(DateTime, default=datetime.utcnow)

# 23. RESPONSE PLAYBOOKS
class ResponsePlaybook(Base):
    __tablename__ = "response_playbooks"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    name = Column(String(255), nullable=False)
    category = Column(String(50), nullable=False)
    description = Column(Text, nullable=True)
    steps_data = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.utcnow)

# 24. RESPONSE ACTIONS
class ResponseAction(Base):
    __tablename__ = "response_actions"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    playbook_id = Column(String(36), ForeignKey("response_playbooks.id"), nullable=True)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    step_title = Column(String(255), nullable=False)
    executed_by_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    status = Column(String(50), default="completed")
    action_log = Column(Text, nullable=True)
    executed_at = Column(DateTime, default=datetime.utcnow)

# 25. AUDIT LOGS (Immutable Activity Log)
class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), nullable=False, index=True)
    user_name = Column(String(255), nullable=False)
    user_role = Column(String(50), nullable=False)
    action = Column(String(100), nullable=False, index=True)
    target_resource = Column(String(100), nullable=False)
    target_id = Column(String(100), nullable=False)
    ip_address = Column(String(45), nullable=False)
    details = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
