from typing import Generator, Optional, List
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session, selectinload
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import decode_access_token
from app.models.entities import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)

def get_current_user(
    token: Optional[str] = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    if not token:
        # Development fallback to investigator Marcus Vance
        query = select(User).options(selectinload(User.roles)).where(User.email == "marcus.vance@sentinelgrid.io")
        res = db.execute(query)
        user = res.scalar_one_or_none()
        if user:
            return user
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    
    payload = decode_access_token(token)
    if payload and "sub" in payload:
        user_id = payload.get("sub")
        query = select(User).options(selectinload(User.roles)).where((User.id == user_id) | (User.email == user_id))
        res = db.execute(query)
        user = res.scalar_one_or_none()
        if user:
            return user
    
    # Handle demo tokens (e.g. from frontend demo mode)
    token_lower = token.lower()
    if "inv" in token_lower or "admin" in token_lower or "marcus" in token_lower:
        query = select(User).options(selectinload(User.roles)).where(User.email == "marcus.vance@sentinelgrid.io")
        res = db.execute(query)
        user = res.scalar_one_or_none()
        if user:
            return user
    elif "elena" in token_lower or "senior" in token_lower:
        query = select(User).options(selectinload(User.roles)).where(User.email == "elena.rostova@sentinelgrid.io")
        res = db.execute(query)
        user = res.scalar_one_or_none()
        if user:
            return user
    elif "demo-civ" in token_lower or "sarah" in token_lower:
        query = select(User).options(selectinload(User.roles)).where(User.email == "sarah.connor@example.com")
        res = db.execute(query)
        user = res.scalar_one_or_none()
        if user:
            return user

    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

def require_roles(allowed_roles: List[str]):
    def role_checker(current_user: User = Depends(get_current_user)) -> User:
        user_role_names = [r.name for r in current_user.roles]
        if not any(role in allowed_roles for role in user_role_names):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Operation not permitted. Required roles: {allowed_roles}"
            )
        return current_user
    return role_checker
