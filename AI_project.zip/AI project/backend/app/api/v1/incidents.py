import random
from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session, selectinload
from sqlalchemy import select, desc
from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.entities import User, Incident, IncidentEvent, AuditLog
from app.schemas.incident import IncidentCreate, IncidentOut, IncidentStatusUpdate, IncidentAssign

router = APIRouter()

@router.get("/", response_model=List[IncidentOut])
def list_incidents(
    category: Optional[str] = None,
    status: Optional[str] = None,
    severity: Optional[str] = None,
    civilian_id: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = (
        select(Incident)
        .options(
            selectinload(Incident.evidence),
            selectinload(Incident.timeline_events)
        )
        .order_by(desc(Incident.created_at))
    )
    
    user_roles = [r.name for r in current_user.roles]
    if "civilian" in user_roles and not any(r in ["investigator", "senior_investigator", "admin"] for r in user_roles):
        query = query.where(Incident.civilian_id == current_user.id)
    elif civilian_id:
        if civilian_id in ["usr-civ-001", "sarah"]:
            query = query.where((Incident.civilian_name == "Sarah Connor") | (Incident.civilian_id == civilian_id))
        else:
            query = query.where(Incident.civilian_id == civilian_id)
    
    if category and category != "all":
        query = query.where(Incident.category == category)
    if status and status != "all":
        query = query.where(Incident.status == status)
    if severity and severity != "all":
        query = query.where(Incident.severity == severity)
        
    res = db.execute(query)
    return res.scalars().all()

@router.post("/", response_model=IncidentOut)
def create_incident(
    data: IncidentCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    complaint_id = f"SG-2026-{random.randint(1000, 9999)}"
    
    new_inc = Incident(
        complaint_id=complaint_id,
        title=data.title,
        category=data.category,
        severity=data.severity or "medium",
        status="submitted",
        description=data.description,
        incident_date=data.incident_date,
        incident_time=data.incident_time,
        platform_involved=data.platform_involved,
        suspect_info=data.suspect_info,
        website_url=data.website_url,
        financial_loss=data.financial_loss or 0.0,
        currency=data.currency or "USD",
        latitude=data.latitude,
        longitude=data.longitude,
        location_name=data.location_name,
        reporter_ip=data.reporter_ip,
        contact_email=data.contact_email,
        contact_phone=data.contact_phone,
        civilian_id=current_user.id,
        civilian_name=current_user.full_name,
    )
    db.add(new_inc)
    db.flush()

    evt = IncidentEvent(
        incident_id=new_inc.id,
        actor_name=current_user.full_name,
        actor_role="Civilian",
        event_type="REPORT_SUBMITTED",
        description=f"Complaint registered via Sentinel Grid civilian intake wizard. Case Reference: {complaint_id}"
    )
    db.add(evt)

    audit = AuditLog(
        user_id=current_user.id,
        user_name=current_user.full_name,
        user_role="civilian",
        action="COMPLAINT_REGISTERED",
        target_resource="Incident",
        target_id=complaint_id,
        ip_address="127.0.0.1",
        details=f"Complainant registered {data.category} incident: {data.title}"
    )
    db.add(audit)

    db.commit()
    
    query = (
        select(Incident)
        .options(selectinload(Incident.evidence), selectinload(Incident.timeline_events))
        .where(Incident.id == new_inc.id)
    )
    res = db.execute(query)
    return res.scalar_one()

@router.get("/{incident_id}", response_model=IncidentOut)
def get_incident(
    incident_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = (
        select(Incident)
        .options(selectinload(Incident.evidence), selectinload(Incident.timeline_events))
        .where((Incident.id == incident_id) | (Incident.complaint_id == incident_id))
    )
    res = db.execute(query)
    inc = res.scalar_one_or_none()
    if not inc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Incident not found")
    
    user_roles = [r.name for r in current_user.roles]
    if "civilian" in user_roles and not any(r in ["investigator", "senior_investigator", "admin"] for r in user_roles):
        if inc.civilian_id != current_user.id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied to this incident.")
    
    return inc

@router.patch("/{incident_id}/status", response_model=IncidentOut)
def update_status(
    incident_id: str,
    data: IncidentStatusUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = (
        select(Incident)
        .options(selectinload(Incident.evidence), selectinload(Incident.timeline_events))
        .where((Incident.id == incident_id) | (Incident.complaint_id == incident_id))
    )
    res = db.execute(query)
    inc = res.scalar_one_or_none()
    if not inc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Incident not found")
    
    inc.status = data.status
    inc.updated_at = datetime.utcnow()

    evt = IncidentEvent(
        incident_id=inc.id,
        actor_name=current_user.full_name,
        actor_role="Investigator",
        event_type="STATUS_CHANGED",
        description=f"Status transitioned to {data.status.replace('_', ' ').upper()}{f'. Notes: {data.notes}' if data.notes else ''}"
    )
    db.add(evt)

    audit = AuditLog(
        user_id=current_user.id,
        user_name=current_user.full_name,
        user_role="investigator",
        action="INCIDENT_STATUS_UPDATED",
        target_resource="Incident",
        target_id=inc.complaint_id,
        ip_address="127.0.0.1",
        details=f"Updated status to {data.status}. Reason: {data.notes or 'Routine triage'}"
    )
    db.add(audit)

    db.commit()
    return inc

@router.patch("/{incident_id}/assign", response_model=IncidentOut)
def assign_incident(
    incident_id: str,
    data: IncidentAssign,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = (
        select(Incident)
        .options(selectinload(Incident.evidence), selectinload(Incident.timeline_events))
        .where((Incident.id == incident_id) | (Incident.complaint_id == incident_id))
    )
    res = db.execute(query)
    inc = res.scalar_one_or_none()
    if not inc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Incident not found")
    
    inc.assigned_investigator_id = data.investigator_id
    inc.assigned_investigator_name = data.investigator_name
    inc.status = "investigation_in_progress"
    inc.updated_at = datetime.utcnow()

    evt = IncidentEvent(
        incident_id=inc.id,
        actor_name=current_user.full_name,
        actor_role="Investigator",
        event_type="ASSIGNMENT",
        description=f"Assigned to {data.investigator_name}. Status transitioned to Investigation in Progress."
    )
    db.add(evt)

    audit = AuditLog(
        user_id=current_user.id,
        user_name=current_user.full_name,
        user_role="investigator",
        action="INCIDENT_ASSIGNED",
        target_resource="Incident",
        target_id=inc.complaint_id,
        ip_address="127.0.0.1",
        details=f"Assigned incident {inc.complaint_id} to {data.investigator_name}"
    )
    db.add(audit)
    db.commit()
    return inc
