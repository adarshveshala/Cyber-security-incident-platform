from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session, selectinload
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import verify_password, get_password_hash, create_access_token
from app.models.entities import User, Role, CivilianProfile
from app.schemas.auth import Token, CivilianRegister, LoginRequest

router = APIRouter()

@router.post("/login", response_model=Token)
def login(data: LoginRequest, db: Session = Depends(get_db)):
    query = select(User).options(selectinload(User.roles)).where(User.email == data.email.lower())
    res = db.execute(query)
    user = res.scalar_one_or_none()
    
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password credentials."
        )
    
    primary_role = "civilian"
    if user.roles:
        primary_role = user.roles[0].name
    
    token = create_access_token(subject=user.id, role=primary_role)
    return Token(
        access_token=token,
        token_type="bearer",
        role=primary_role,
        user_id=user.id,
        full_name=user.full_name
    )

@router.post("/register", response_model=Token)
def register(data: CivilianRegister, db: Session = Depends(get_db)):
    clean_email = data.email.strip().lower()
    query = select(User).where(User.email == clean_email)
    res = db.execute(query)
    existing = res.scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email address already exists. Please sign in or use another email."
        )
    
    try:
        role_query = select(Role).where(Role.name == "civilian")
        role_res = db.execute(role_query)
        civ_role = role_res.scalar_one_or_none()
        if not civ_role:
            civ_role = Role(name="civilian", description="Public complainant role")
            db.add(civ_role)
            db.flush()
        
        new_user = User(
            email=clean_email,
            hashed_password=get_password_hash(data.password),
            full_name=data.full_name.strip(),
            phone=data.phone,
            avatar_url=data.avatar_url,
            roles=[civ_role]
        )
        db.add(new_user)
        db.flush()

        civ_profile = CivilianProfile(
            user_id=new_user.id,
            preferred_contact_method="email",
            two_factor_enabled=True
        )
        db.add(civ_profile)
        db.commit()

        token = create_access_token(subject=new_user.id, role="civilian")
        return Token(
            access_token=token,
            token_type="bearer",
            role="civilian",
            user_id=new_user.id,
            full_name=new_user.full_name
        )
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Registration failed in PostgreSQL database: {str(e)}"
        )
