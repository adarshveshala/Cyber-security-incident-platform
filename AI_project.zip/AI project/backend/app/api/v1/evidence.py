import os
import hashlib
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.core.config import settings
from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.entities import User, Incident, Evidence, IncidentEvent, AuditLog

router = APIRouter()

@router.post("/{incident_id}/upload")
async def upload_evidence(
    incident_id: str,
    file: UploadFile = File(...),
    description: str = Form("User submitted evidence artifact"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = select(Incident).where((Incident.id == incident_id) | (Incident.complaint_id == incident_id))
    res = db.execute(query)
    inc = res.scalar_one_or_none()
    if not inc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Incident not found")
    
    contents = await file.read()
    if len(contents) > settings.MAX_EVIDENCE_FILE_SIZE_MB * 1024 * 1024:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="File exceeds maximum 50MB size limit.")
    
    sha256 = hashlib.sha256(contents).hexdigest()
    
    safe_filename = f"{inc.complaint_id}_{sha256[:10]}_{file.filename}"
    file_path = os.path.join(settings.EVIDENCE_UPLOAD_DIR, safe_filename)
    with open(file_path, "wb") as f:
        f.write(contents)
    
    new_evidence = Evidence(
        incident_id=inc.id,
        file_name=file.filename,
        file_size=len(contents),
        file_type=file.content_type or "application/octet-stream",
        storage_path=file_path,
        sha256_hash=sha256,
        uploaded_by_id=current_user.id,
        uploaded_by_name=current_user.full_name,
        description=description,
        is_verified=True
    )
    db.add(new_evidence)
    
    evt = IncidentEvent(
        incident_id=inc.id,
        actor_name=current_user.full_name,
        actor_role="Complainant",
        event_type="EVIDENCE_UPLOADED",
        description=f"Evidence file {file.filename} secured in vault. SHA-256: {sha256}"
    )
    db.add(evt)
    
    audit = AuditLog(
        user_id=current_user.id,
        user_name=current_user.full_name,
        user_role="civilian",
        action="EVIDENCE_UPLOADED",
        target_resource="Evidence",
        target_id=new_evidence.id,
        ip_address="127.0.0.1",
        details=f"Uploaded {file.filename} (SHA-256: {sha256}) for incident {inc.complaint_id}"
    )
    db.add(audit)
    
    db.commit()
    
    return {
        "id": new_evidence.id,
        "file_name": new_evidence.file_name,
        "file_size": new_evidence.file_size,
        "file_type": new_evidence.file_type,
        "sha256_hash": new_evidence.sha256_hash,
        "uploaded_by_name": new_evidence.uploaded_by_name,
        "created_at": new_evidence.created_at
    }
