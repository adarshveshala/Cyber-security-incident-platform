from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import select, desc
from pydantic import BaseModel
from app.core.database import get_db
from app.models.entities import Alert

router = APIRouter()

class AlertOut(BaseModel):
    id: str
    detection_rule_name: str
    title: str
    description: str
    severity: str
    status: str
    source: str
    correlated_incident_id: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

@router.get("/", response_model=List[AlertOut])
def list_alerts(
    severity: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = select(Alert).order_by(desc(Alert.created_at))
    if severity and severity != "all":
        query = query.where(Alert.severity == severity)
    res = db.execute(query)
    return res.scalars().all()
