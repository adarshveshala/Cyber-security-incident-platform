from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import select, desc
from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.entities import User, Incident, Conversation, Message, Notification

router = APIRouter()

class MessageIn(BaseModel):
    content: str
    is_evidence_request: bool = False
    attachment_name: Optional[str] = None

class MessageOut(BaseModel):
    id: str
    conversation_id: Optional[str] = None
    incident_id: str
    sender_id: str
    sender_name: str
    sender_role: str
    content: str
    attachment_name: Optional[str] = None
    is_evidence_request: bool = False
    created_at: datetime

    class Config:
        from_attributes = True

@router.get('/{incident_id}', response_model=List[MessageOut])
def list_messages(
    incident_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    inc_query = select(Incident).where((Incident.id == incident_id) | (Incident.complaint_id == incident_id))
    inc = db.execute(inc_query).scalar_one_or_none()
    target_id = inc.id if inc else incident_id

    query = (
        select(Message)
        .where((Message.incident_id == target_id) | (Message.incident_id == incident_id))
        .order_by(Message.created_at)
    )
    res = db.execute(query)
    return res.scalars().all()

@router.post('/{incident_id}', response_model=MessageOut)
def send_message(
    incident_id: str,
    data: MessageIn,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    inc_query = select(Incident).where((Incident.id == incident_id) | (Incident.complaint_id == incident_id))
    inc = db.execute(inc_query).scalar_one_or_none()
    if not inc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Incident not found')
    
    conv_query = select(Conversation).where(Conversation.incident_id == inc.id)
    conv = db.execute(conv_query).scalar_one_or_none()
    if not conv:
        conv = Conversation(incident_id=inc.id, title=f'Case Thread: {inc.complaint_id}')
        db.add(conv)
        db.flush()
    
    sender_role = 'civilian'
    if current_user.roles:
        sender_role = current_user.roles[0].name
        
    new_msg = Message(
        conversation_id=conv.id,
        incident_id=inc.id,
        sender_id=current_user.id,
        sender_name=current_user.full_name,
        sender_role=sender_role,
        content=data.content.strip(),
        attachment_name=data.attachment_name,
        is_evidence_request=data.is_evidence_request
    )
    db.add(new_msg)

    recipient_id = inc.assigned_investigator_id if sender_role == 'civilian' else inc.civilian_id
    if recipient_id:
        notif = Notification(
            user_id=recipient_id,
            title='New Case Message' if not data.is_evidence_request else 'Evidence Request Received',
            message=f'{current_user.full_name} sent a message regarding {inc.complaint_id}: {data.content[:80]}...',
            type='new_message' if not data.is_evidence_request else 'evidence_request',
            link_url='/civilian/messages' if sender_role != 'civilian' else '/investigator/messages'
        )
        db.add(notif)

    db.commit()
    db.refresh(new_msg)
    return new_msg
