from typing import List
from datetime import datetime
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import select, desc
from pydantic import BaseModel
from app.core.database import get_db
from app.models.entities import AuditLog

router = APIRouter()

class AuditLogOut(BaseModel):
    id: str
    user_id: str
    user_name: str
    user_role: str
    action: str
    target_resource: str
    target_id: str
    ip_address: str
    details: str
    created_at: datetime

    class Config:
        from_attributes = True

@router.get("/", response_model=List[AuditLogOut])
def list_audit_logs(db: Session = Depends(get_db)):
    query = select(AuditLog).order_by(desc(AuditLog.created_at)).limit(100)
    res = db.execute(query)
    return res.scalars().all()
