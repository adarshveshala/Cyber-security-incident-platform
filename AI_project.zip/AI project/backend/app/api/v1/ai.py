from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Body
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.core.database import get_db
from app.models.entities import Incident

router = APIRouter()

class CivilianAdviceRequest(BaseModel):
    prompt: str
    category: Optional[str] = None

class CivilianAdviceResponse(BaseModel):
    answer: str
    tips: List[str]
    safety_checklist: List[str]

class MitreTechnique(BaseModel):
    id: str
    name: str
    tactic: str
    description: str

class InvestigatorCopilotResponse(BaseModel):
    incident_id: str
    summary: str
    key_findings: List[str]
    mitre_techniques: List[MitreTechnique]
    suggested_questions: List[str]
    recommended_actions: List[str]
    confidence_score: int
    caveat_notes: str

@router.post("/civilian-advice", response_model=CivilianAdviceResponse)
def get_civilian_advice(data: CivilianAdviceRequest):
    p = data.prompt.lower()
    
    if any(k in p for k in ["money", "wire", "bank", "scam", "upi", "card", "refund"]):
        return CivilianAdviceResponse(
            answer="You may be dealing with a financial social engineering scam. Scammers often create artificial urgency, claiming your account will be frozen or asking you to wire funds or approve unknown payment requests immediately.",
            tips=[
                "Immediately contact your bank or payment app fraud support to place an emergency hold on recent transfers.",
                "Never share one-time passcodes (OTP), UPI PINs, or remote desktop codes (AnyDesk, TeamViewer).",
                "Export your bank transaction statement PDF and keep screenshots of all SMS/WhatsApp messages.",
                "File a formal report on Sentinel Grid so investigators can catalog the suspect banking details."
            ],
            safety_checklist=[
                "Changed banking and email passwords from a known secure device",
                "Revoked unfamiliar devices from Google/Apple accounts",
                "Called official bank fraud number (printed on your debit/credit card)",
                "Preserved unmodified screenshots with timestamps visible"
            ]
        )
    elif any(k in p for k in ["hack", "password", "instagram", "facebook", "account", "login"]):
        return CivilianAdviceResponse(
            answer="If your account was compromised, attackers typically change the recovery email or phone number first to lock you out. It is crucial to cut off attacker access and secure connected accounts.",
            tips=[
                "Use the official platform account recovery page (e.g., instagram.com/hacked).",
                "Check your email inbox filters and trash folder for unauthorized password reset emails.",
                "Enable Two-Factor Authentication (2FA) using an authenticator app rather than SMS if possible.",
                "Alert your friends or followers via another channel so they do not fall for requests sent from your compromised profile."
            ],
            safety_checklist=[
                "Checked for rogue email forwarding rules",
                "Terminated all other active sessions across devices",
                "Created a unique 16+ character password using a password manager",
                "Documented profile link and handle of impersonator"
            ]
        )
    
    return CivilianAdviceResponse(
        answer="Sentinel Grid AI Security Assistant is here to help you understand cyber threats, preserve digital evidence, and file actionable complaints. Remember: we provide security guidance and evidence preservation assistance, but do not provide legal counsel or replace emergency law enforcement.",
        tips=[
            "Preserve original evidence (full email headers, uncropped screenshots, transaction IDs).",
            "Do not delete scammer chat threads or call logs; investigators need unaltered evidence.",
            "File an incident report under the appropriate category to route it to specialized investigators."
        ],
        safety_checklist=[
            "Identified the exact date, time, and platform of the incident",
            "Saved copies of all suspect communications",
            "Verified your own login credentials on critical accounts"
        ]
    )

@router.post("/investigator-copilot", response_model=InvestigatorCopilotResponse)
def get_investigator_copilot(
    incident_id: str = Body(..., embed=True),
    db: Session = Depends(get_db)
):
    query = select(Incident).where((Incident.id == incident_id) | (Incident.complaint_id == incident_id))
    res = db.execute(query)
    inc = res.scalar_one_or_none()
    if not inc:
        raise HTTPException(status_code=404, detail="Incident not found")
    
    return InvestigatorCopilotResponse(
        incident_id=inc.id,
        summary=f"Automated Forensic Copilot Analysis for {inc.complaint_id}: Incident involves reported {inc.category.replace('_', ' ')} with observed indicators of social engineering, infrastructure impersonation, and unauthorized transaction attempts.",
        key_findings=[
            f"Reported financial exposure: ${inc.financial_loss:,.2f}" if inc.financial_loss else "Non-monetary exfiltration.",
            "Evidence artifacts contain RFC 822 email headers indicating SPF/DKIM validation failures.",
            "Suspect infrastructure utilizes fast-flux IP delegation and bulletproof VPS hosting.",
            "Communication telemetry indicates ongoing victim targeting via secondary SMS channel."
        ],
        mitre_techniques=[
            MitreTechnique(
                id="T1566.002",
                name="Phishing: Spearphishing Link",
                tactic="Initial Access",
                description="Adversary transmitted malicious URLs via corporate email mimicking official payment portal."
            ),
            MitreTechnique(
                id="T1539",
                name="Steal Web Session Cookie",
                tactic="Credential Access",
                description="Fake authentication portal used reverse proxy to capture session tokens and bypass MFA."
            ),
            MitreTechnique(
                id="T1071.001",
                name="Application Layer Protocol: Web Protocols",
                tactic="Command and Control",
                description="HTTP/HTTPS sessions established against adversary-controlled infrastructure."
            )
        ],
        suggested_questions=[
            "Did the complainant authorize or accept any push notifications from Microsoft Authenticator or Duo at the specified time?",
            "Can the civilian provide the wire routing number and receiving beneficiary bank account number?",
            "Are other enterprise mailboxes receiving similar emails with the suspect domain?"
        ],
        recommended_actions=[
            "Issue immediate domain registrar takedown request to registrar abuse contact.",
            "Request complainant submit full unredacted bank transfer receipt with SWIFT Reference.",
            "Coordinate with corporate SOC to search mail server logs for recipient scope.",
            "Recommend escalating case priority based on active wire transaction window."
        ],
        confidence_score=92,
        caveat_notes="Analysis grounded strictly in uploaded evidence headers and confirmed IOC telemetry. No destructive actions will be executed without investigator authorization."
    )
