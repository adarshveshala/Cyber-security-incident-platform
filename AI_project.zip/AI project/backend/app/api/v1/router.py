from fastapi import APIRouter
from app.api.v1 import auth, incidents, evidence, messages, threat_intel, ai, alerts, audit

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])
api_router.include_router(incidents.router, prefix="/incidents", tags=["Incidents & Triage"])
api_router.include_router(evidence.router, prefix="/evidence", tags=["Digital Evidence Vault"])
api_router.include_router(messages.router, prefix="/messages", tags=["Case Messages"])
api_router.include_router(threat_intel.router, prefix="/threat-intel", tags=["Threat Intelligence"])
api_router.include_router(ai.router, prefix="/ai", tags=["AI Copilots"])
api_router.include_router(alerts.router, prefix="/alerts", tags=["SOC Alerts"])
api_router.include_router(audit.router, prefix="/audit", tags=["Immutable Audit Trail"])
