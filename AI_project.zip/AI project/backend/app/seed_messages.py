import uuid
from datetime import datetime, timedelta
import psycopg2
from app.core.config import settings

def seed_messages():
    conn = psycopg2.connect("postgresql://postgres:6622@127.0.0.1:5432/sentinelgrid")
    cur = conn.cursor()

    # Find users
    cur.execute("SELECT id, email, full_name FROM users WHERE email IN ('sarah.connor@example.com', 'marcus.vance@sentinelgrid.io', 'adarshveshalaaaaa@gmail.com')")
    users = {r[1]: {'id': r[0], 'name': r[2]} for r in cur.fetchall()}
    
    marcus = users.get('marcus.vance@sentinelgrid.io')
    sarah = users.get('sarah.connor@example.com')
    adarsh = users.get('adarshveshalaaaaa@gmail.com')

    if not marcus:
        print("Marcus Vance not found, aborting seed")
        return

    # Find incidents to populate
    cur.execute("SELECT id, complaint_id, title, civilian_id, civilian_name, assigned_investigator_id, assigned_investigator_name FROM incidents")
    incidents = cur.fetchall()

    now = datetime.utcnow()

    for inc in incidents:
        inc_id, complaint_id, title, civ_id, civ_name, inv_id, inv_name = inc

        # Check if conversation exists
        cur.execute("SELECT id FROM conversations WHERE incident_id = %s", (inc_id,))
        conv_row = cur.fetchone()
        if not conv_row:
            conv_id = str(uuid.uuid4())
            cur.execute(
                "INSERT INTO conversations (id, incident_id, title, created_at) VALUES (%s, %s, %s, %s)",
                (conv_id, inc_id, f"Case Thread: {complaint_id}", now - timedelta(hours=12))
            )
        else:
            conv_id = conv_row[0]

        # Check existing messages count
        cur.execute("SELECT COUNT(*) FROM messages WHERE incident_id = %s", (inc_id,))
        msg_count = cur.fetchone()[0]
        if msg_count > 0:
            print(f"Incident {complaint_id} already has {msg_count} messages, skipping.")
            continue

        # Ensure investigator is assigned if none
        if not inv_id:
            inv_id = marcus['id']
            inv_name = marcus['name']
            cur.execute(
                "UPDATE incidents SET assigned_investigator_id = %s, assigned_investigator_name = %s WHERE id = %s",
                (inv_id, inv_name, inc_id)
            )

        sender_civ_id = civ_id or (sarah['id'] if sarah else 'usr-civ-001')
        sender_civ_name = civ_name or 'Complainant'

        # Seed conversation based on complaint
        if 'UPI' in (title or '') or '9524' in (complaint_id or ''):
            msgs = [
                {
                    'sender_id': sender_civ_id,
                    'sender_name': sender_civ_name,
                    'sender_role': 'civilian',
                    'content': 'Hello Investigator Vance, I discovered that the payment terminal QR code at our retail branch was replaced with a spoofed sticker routing to a rogue VPAY ID. Multiple customer payments were intercepted.',
                    'attachment_name': 'tampered_qr_terminal.jpg',
                    'is_evidence_request': False,
                    'offset_minutes': 180,
                },
                {
                    'sender_id': inv_id,
                    'sender_name': inv_name,
                    'sender_role': 'investigator',
                    'content': 'Thank you for flagging this promptly. I have initiated emergency merchant block protocols with the banking switch. Could you upload the transaction reference numbers and CCTV capture of the cashier counter between 14:00 and 15:30 IST?',
                    'attachment_name': None,
                    'is_evidence_request': True,
                    'offset_minutes': 140,
                },
                {
                    'sender_id': sender_civ_id,
                    'sender_name': sender_civ_name,
                    'sender_role': 'civilian',
                    'content': 'I exported the settlement ledger and CCTV footage clip. The timestamp matches the suspect entry at 14:22 IST. Uploaded as requested.',
                    'attachment_name': 'cctv_suspect_qr_swap.mp4',
                    'is_evidence_request': False,
                    'offset_minutes': 60,
                },
                {
                    'sender_id': inv_id,
                    'sender_name': inv_name,
                    'sender_role': 'investigator',
                    'content': 'Received and verified. SHA-256 hash recorded in the evidence ledger. The rogue UPI merchant has been frozen by the beneficiary bank. I will update you as forensic trace data returns.',
                    'attachment_name': None,
                    'is_evidence_request': False,
                    'offset_minutes': 15,
                }
            ]
        elif 'Deducted' in (title or '') or '7566' in (complaint_id or ''):
            msgs = [
                {
                    'sender_id': sender_civ_id,
                    'sender_name': sender_civ_name,
                    'sender_role': 'civilian',
                    'content': 'I received a fake payment confirmation SMS with a link claiming an urgent refund. When I clicked it, 50,000 INR was debited from my PhonePe linked account.',
                    'attachment_name': 'fake_sms_refund_alert.png',
                    'is_evidence_request': False,
                    'offset_minutes': 120,
                },
                {
                    'sender_id': inv_id,
                    'sender_name': inv_name,
                    'sender_role': 'investigator',
                    'content': 'Understood. We are issuing an immediate fraud notice to NPCI and your beneficiary bank. Please provide the exact 12-digit UTR/RRN number from your bank statement so we can initiate fund-recovery recall.',
                    'attachment_name': None,
                    'is_evidence_request': True,
                    'offset_minutes': 90,
                },
                {
                    'sender_id': sender_civ_id,
                    'sender_name': sender_civ_name,
                    'sender_role': 'civilian',
                    'content': 'Here is the UTR number: 611294820194. It shows debited to account ending in 4102.',
                    'attachment_name': 'bank_statement_debit_utr.pdf',
                    'is_evidence_request': False,
                    'offset_minutes': 45,
                },
                {
                    'sender_id': inv_id,
                    'sender_name': inv_name,
                    'sender_role': 'investigator',
                    'content': 'UTR confirmed and tagged in the cyber fraud registry. The receiving account in Mumbai has been placed under lien.',
                    'attachment_name': None,
                    'is_evidence_request': False,
                    'offset_minutes': 10,
                }
            ]
        elif 'finance' in (title or '').lower() or '2171' in (complaint_id or ''):
            civ_user_id = adarsh['id'] if adarsh else sender_civ_id
            civ_user_name = adarsh['name'] if adarsh else sender_civ_name
            msgs = [
                {
                    'sender_id': civ_user_id,
                    'sender_name': civ_user_name,
                    'sender_role': 'civilian',
                    'content': 'Hi Investigator Vance, I reported unauthorized financial debit transactions on our corporate account. Can you check the IP origin of the unauthorized login?',
                    'attachment_name': 'auth_logs_export.csv',
                    'is_evidence_request': False,
                    'offset_minutes': 90,
                },
                {
                    'sender_id': inv_id,
                    'sender_name': inv_name,
                    'sender_role': 'investigator',
                    'content': 'Hello Adarsh, I examined the session logs. The login originated from a bulletproof proxy node (194.26.29.112) with suspicious user-agent spoofing. Did you have 2FA enabled on the account?',
                    'attachment_name': None,
                    'is_evidence_request': True,
                    'offset_minutes': 50,
                },
                {
                    'sender_id': civ_user_id,
                    'sender_name': civ_user_name,
                    'sender_role': 'civilian',
                    'content': 'We had SMS 2FA enabled, but it looks like a SIM swap happened right before the transfer.',
                    'attachment_name': 'carrier_sim_swap_receipt.png',
                    'is_evidence_request': False,
                    'offset_minutes': 20,
                },
                {
                    'sender_id': inv_id,
                    'sender_name': inv_name,
                    'sender_role': 'investigator',
                    'content': 'That explains the bypass. I am filing the forensic preservation notice with the telecom operator now.',
                    'attachment_name': None,
                    'is_evidence_request': False,
                    'offset_minutes': 5,
                }
            ]
        else:
            msgs = [
                {
                    'sender_id': sender_civ_id,
                    'sender_name': sender_civ_name,
                    'sender_role': 'civilian',
                    'content': f'Incident reported: {title}. We have preserved initial system snapshots and are standing by for investigator triage.',
                    'attachment_name': None,
                    'is_evidence_request': False,
                    'offset_minutes': 120,
                },
                {
                    'sender_id': inv_id,
                    'sender_name': inv_name,
                    'sender_role': 'investigator',
                    'content': f'This is Special Agent Marcus Vance. Case {complaint_id} has been formally logged and assigned to my queue. I am reviewing the preliminary indicator matches.',
                    'attachment_name': None,
                    'is_evidence_request': False,
                    'offset_minutes': 60,
                }
            ]

        for m in msgs:
            msg_id = str(uuid.uuid4())
            msg_time = now - timedelta(minutes=m['offset_minutes'])
            cur.execute(
                """
                INSERT INTO messages (id, conversation_id, incident_id, sender_id, sender_name, sender_role, content, attachment_name, is_evidence_request, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (msg_id, conv_id, inc_id, m['sender_id'], m['sender_name'], m['sender_role'], m['content'], m['attachment_name'], m['is_evidence_request'], msg_time)
            )

        print(f"Seeded {len(msgs)} messages for {complaint_id}")

    conn.commit()
    cur.close()
    conn.close()
    print("Messages seeding complete!")

if __name__ == '__main__':
    seed_messages()
