import sys
import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.core.database import Base
from app.models.entities import User, Role, CivilianProfile, InvestigatorProfile, Incident, IncidentEvent, Evidence, Alert, ThreatIndicator
from app.core.security import get_password_hash
from app.seed_rich_incidents import seed as seed_rich

def init_postgres(password: str = "postgres", host: str = "127.0.0.1", port: int = 5432, db_name: str = "sentinelgrid", user: str = "postgres"):
    admin_url = f"postgresql+pg8000://{user}:{password}@{host}:{port}/postgres"
    print(f"Connecting to PostgreSQL server at {host}:{port} as {user}...")

    # 1. Connect to admin postgres DB to create target DB if not exists
    admin_engine = create_engine(admin_url, isolation_level="AUTOCOMMIT")
    with admin_engine.connect() as conn:
        res = conn.execute(text(f"SELECT 1 FROM pg_database WHERE datname='{db_name}'"))
        if not res.scalar():
            print(f"Creating database '{db_name}'...")
            conn.execute(text(f'CREATE DATABASE "{db_name}"'))
            print(f"Database '{db_name}' created successfully.")
        else:
            print(f"Database '{db_name}' already exists.")

    # 2. Connect to sentinelgrid database
    target_url = f"postgresql+pg8000://{user}:{password}@{host}:{port}/{db_name}"
    engine = create_engine(target_url, echo=False)
    
    print("Rebuilding PostgreSQL schema for dashboard entities...")
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    print("All PostgreSQL tables created successfully.")

    Session = sessionmaker(bind=engine)
    with Session() as db:
        # 3. Create default roles
        roles = {
            "civilian": Role(name="civilian", description="Public citizen filing cyber complaints"),
            "investigator": Role(name="investigator", description="SOC investigator handling triage and casework"),
            "senior_investigator": Role(name="senior_investigator", description="Senior SOC investigator and lead supervisor"),
            "admin": Role(name="admin", description="Platform administrator and SOC director"),
        }
        for r in roles.values():
            db.add(r)
        db.flush()

        # 4. Create default users
        sarah = User(
            email="sarah.connor@example.com",
            hashed_password=get_password_hash("CyberSafe@2026"),
            full_name="Sarah Connor",
            phone="+1 (555) 234-5678",
            avatar_url="https://api.dicebear.com/7.x/bottts/svg?seed=SarahDefender&backgroundColor=b6e3f4",
            roles=[roles["civilian"]]
        )
        marcus = User(
            email="marcus.vance@sentinelgrid.io",
            hashed_password=get_password_hash("SpecialAgent#9042"),
            full_name="Special Agent Marcus Vance",
            phone="+1 (555) 849-2001",
            avatar_url="https://api.dicebear.com/7.x/bottts/svg?seed=AgentMarcus&backgroundColor=c0aede",
            roles=[roles["investigator"]]
        )
        elena = User(
            email="elena.rostova@sentinelgrid.io",
            hashed_password=get_password_hash("LeadDetective#1049"),
            full_name="Lead Detective Elena Rostova",
            phone="+1 (555) 902-1144",
            avatar_url="https://api.dicebear.com/7.x/bottts/svg?seed=DetectiveElena&backgroundColor=ffd5dc",
            roles=[roles["senior_investigator"]]
        )
        admin = User(
            email="admin@sentinelgrid.io",
            hashed_password=get_password_hash("AdminRoot#999"),
            full_name="Director David Sterling",
            phone="+1 (555) 000-0001",
            avatar_url="https://api.dicebear.com/7.x/bottts/svg?seed=DirectorSterling&backgroundColor=d1d4f9",
            roles=[roles["admin"]]
        )
        
        db.add_all([sarah, marcus, elena, admin])
        db.flush()

        # Profiles
        db.add(CivilianProfile(user_id=sarah.id, emergency_contact_phone="+1 (555) 999-8888", preferred_contact_method="email", two_factor_enabled=True))
        db.add(InvestigatorProfile(user_id=marcus.id, badge_number="SG-INV-8492", department="Cyber Fraud & Ransomware Unit", security_clearance_level="Level 3 - Secret"))
        db.add(InvestigatorProfile(user_id=elena.id, badge_number="SG-LEAD-1049", department="Advanced Threat Triage & Incident Response", security_clearance_level="Level 4 - Top Secret"))
        db.add(InvestigatorProfile(user_id=admin.id, badge_number="SG-DIR-0001", department="Platform Administration & Security Operations", security_clearance_level="Level 5 - Director Executive"))
        
        # Threat Indicators (IOCs)
        ioc1 = ThreatIndicator(
            indicator="194.26.29.112",
            indicator_type="ip",
            reputation="malicious",
            risk_score=94,
            source="AbuseIPDB & Sentinel Threat Grid",
            category="Phishing Command & Control",
            tags=["phishing", "bulletproof_vps", "fast_flux"],
            details="Associated with spoofed banking landing pages and automated credential harvesting kits."
        )
        ioc2 = ThreatIndicator(
            indicator="pay-secure-corporate.net",
            indicator_type="domain",
            reputation="malicious",
            risk_score=98,
            source="VirusTotal & STIX Feed",
            category="Typosquatting & Wire Fraud",
            tags=["typosquatting", "impersonation"],
            details="Registered 3 days prior to campaign. DNS resolving to fast-flux IP pool."
        )
        ioc3 = ThreatIndicator(
            indicator="103.112.54.12",
            indicator_type="ip",
            reputation="malicious",
            risk_score=92,
            source="CERT-In & Local SOC Ingestion",
            category="UPI QR Overlay Hijack",
            tags=["upi_overlay", "financial_fraud", "fast_flux"],
            details="Known adversary proxy IP observed altering dynamic QR merchant codes in Hyderabad."
        )
        db.add_all([ioc1, ioc2, ioc3])

        # Security Alerts
        alt1 = Alert(
            detection_rule_name="SOC-RULE-BRUTEFORCE-SSH",
            title="Multiple Failed Root Login Attempts",
            description="142 brute force attempts on SSH port 22 from 185.220.101.5 in under 3 minutes.",
            severity="high",
            status="new",
            source="Auth.log Ingestion Pipeline"
        )
        alt2 = Alert(
            detection_rule_name="SOC-RULE-ANONYMIZER-API",
            title="Tor Exit Node Connection to Banking API",
            description="Inbound TLS session established from known Tor exit relay 185.107.56.211.",
            severity="critical",
            status="investigating",
            source="WAF Gateway Ingestion"
        )
        db.add_all([alt1, alt2])

        db.commit()
        print("Default users, profiles, threat IOCs, and alerts seeded.")

    # 5. Update .env files and environment
    env_content = f"DATABASE_URL=postgresql+pg8000://{user}:{password}@{host}:{port}/{db_name}\n"
    backend_env = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env")
    root_env = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), ".env")
    with open(backend_env, "w") as f:
        f.write(env_content)
    with open(root_env, "w") as f:
        f.write(env_content)
    print("Saved DATABASE_URL to backend/.env and root .env")
    os.environ["DATABASE_URL"] = f"postgresql+pg8000://{user}:{password}@{host}:{port}/{db_name}"

    # 6. Seed rich dashboard incidents
    from app.core import database as app_db
    app_db.engine = engine
    app_db.SessionLocal = Session
    print("Seeding rich geospatial incidents for SOC map...")
    seed_rich()
    print("PostgreSQL initialization and seeding complete!")

if __name__ == "__main__":
    pwd = sys.argv[1] if len(sys.argv) > 1 else "postgres"
    init_postgres(password=pwd)
