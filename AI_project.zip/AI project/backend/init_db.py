import sys
import asyncio

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

from app.core.database import engine, Base
from app.seed_data import seed_initial_data

async def main():
    print("Initializing database tables...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("Tables created. Seeding data...")
    await seed_initial_data()
    print("Database initialization and seeding complete!")

if __name__ == "__main__":
    asyncio.run(main())
