def test_civilian_registration(client):
    response = client.post(
        "/api/v1/auth/register",
        json={
            "full_name": "John Reese",
            "email": "john.reese@example.org",
            "phone": "+1 555-123-4567",
            "password": "StrongSecurityPassword#2026",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["role"] == "civilian"
    assert data["full_name"] == "John Reese"

def test_duplicate_registration_rejected(client):
    response = client.post(
        "/api/v1/auth/register",
        json={
            "full_name": "Duplicate Sarah",
            "email": "sarah.connor@example.com",
            "password": "AnyPassword#123",
        },
    )
    assert response.status_code == 400
    assert "already exists" in response.json()["detail"]

def test_civilian_login_success(client):
    response = client.post(
        "/api/v1/auth/login",
        json={
            "email": "sarah.connor@example.com",
            "password": "CyberSafe@2026",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["role"] == "civilian"
    assert "access_token" in data

def test_investigator_login_success(client):
    response = client.post(
        "/api/v1/auth/login",
        json={
            "email": "marcus.vance@sentinelgrid.io",
            "password": "SpecialAgent#9042",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["role"] == "investigator"
    assert "access_token" in data

def test_invalid_login_rejected(client):
    response = client.post(
        "/api/v1/auth/login",
        json={
            "email": "sarah.connor@example.com",
            "password": "WrongPassword!",
        },
    )
    assert response.status_code == 401
