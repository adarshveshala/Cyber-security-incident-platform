def test_create_and_fetch_incident(client):
    create_res = client.post(
        "/api/v1/incidents/",
        json={
            "title": "Unauthorized Crypto Drainer Signature",
            "category": "financial_fraud",
            "severity": "high",
            "description": "Smart contract approval triggered automated wallet drain of $12,000 via malicious dApp signature request.",
            "incident_date": "2026-11-16",
            "incident_time": "18:00",
            "platform_involved": "MetaMask / Arbitrum",
            "suspect_info": "Contract 0x8a1b2c3d4e5f60718293a4b5c6d7e8f901234567",
            "financial_loss": 12000.0,
            "currency": "USD",
            "contact_email": "sarah.connor@example.com",
        },
    )
    assert create_res.status_code == 200
    created = create_res.json()
    assert created["complaint_id"].startswith("SG-2026-")
    assert created["status"] == "submitted"
    assert created["severity"] == "high"
    assert len(created["timeline_events"]) >= 1

    fetch_res = client.get(f"/api/v1/incidents/{created['id']}")
    assert fetch_res.status_code == 200
    fetched = fetch_res.json()
    assert fetched["title"] == "Unauthorized Crypto Drainer Signature"

def test_update_incident_status(client):
    list_res = client.get("/api/v1/incidents/")
    assert list_res.status_code == 200
    incidents = list_res.json()
    assert len(incidents) > 0
    target = incidents[0]

    update_res = client.patch(
        f"/api/v1/incidents/{target['id']}/status",
        json={
            "status": "resolved",
            "notes": "Bank recalled wire funds; recipient wallet address blacklisted across national exchanges.",
        },
    )
    assert update_res.status_code == 200
    updated = update_res.json()
    assert updated["status"] == "resolved"
