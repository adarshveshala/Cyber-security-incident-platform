import io
import hashlib

def test_evidence_upload_sha256(client):
    list_res = client.get("/api/v1/incidents/")
    incidents = list_res.json()
    assert len(incidents) > 0
    inc_id = incidents[0]["id"]

    test_content = b"Content of email headers with forged DKIM key"
    expected_sha256 = hashlib.sha256(test_content).hexdigest()

    files = {"file": ("email_header_test.eml", io.BytesIO(test_content), "message/rfc822")}
    data = {"description": "Forensic test header"}

    res = client.post(f"/api/v1/evidence/{inc_id}/upload", files=files, data=data)
    assert res.status_code == 200
    evidence = res.json()
    assert evidence["sha256_hash"] == expected_sha256
    assert evidence["file_name"] == "email_header_test.eml"

def test_threat_intelligence_lookup(client):
    res = client.get("/api/v1/threat-intel/lookup?indicator=194.26.29.112")
    assert res.status_code == 200
    data = res.json()
    assert data["indicator"] == "194.26.29.112"
    assert data["indicator_type"] == "ip"
    assert data["risk_score"] >= 80
    assert data["reputation"] == "malicious"

def test_civilian_ai_security_advisor(client):
    res = client.post(
        "/api/v1/ai/civilian-advice",
        json={"prompt": "I got an SMS asking for my UPI pin to receive a lottery reward."},
    )
    assert res.status_code == 200
    data = res.json()
    assert len(data["tips"]) > 0
    assert len(data["safety_checklist"]) > 0
    assert "PIN" in "".join(data["tips"]) or "never" in data["answer"].lower()

def test_investigator_ai_copilot(client):
    list_res = client.get("/api/v1/incidents/")
    inc_id = list_res.json()[0]["id"]

    res = client.post(
        "/api/v1/ai/investigator-copilot",
        json={"incident_id": inc_id},
    )
    assert res.status_code == 200
    data = res.json()
    assert len(data["mitre_techniques"]) >= 1
    assert "T1566.002" in [t["id"] for t in data["mitre_techniques"]]
    assert len(data["key_findings"]) >= 1
    assert data["confidence_score"] > 80
