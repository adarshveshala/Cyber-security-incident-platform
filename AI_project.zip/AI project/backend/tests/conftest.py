import pytest
import os
import sys
import hashlib
from urllib.parse import urlparse, parse_qs
from fastapi import HTTPException
from sqlalchemy import select

backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from app.core.database import SessionLocal, Base, engine
from app.models.entities import User, Role, Incident, Evidence
from app.api.v1.auth import register, login
from app.api.v1.incidents import create_incident, get_incident, list_incidents, update_status
from app.api.v1.threat_intel import lookup_indicator, IndicatorOut
from app.api.v1.ai import get_civilian_advice, get_investigator_copilot, CivilianAdviceRequest
from app.schemas.auth import CivilianRegister, LoginRequest
from app.schemas.incident import IncidentCreate, IncidentStatusUpdate, IncidentOut
from app.seed_data import seed_initial_data

class MockResponse:
    def __init__(self, status_code: int, data: any):
        self.status_code = status_code
        self._data = data

    def json(self):
        return self._data

class DirectClient:
    def __init__(self):
        Base.metadata.create_all(bind=engine)
        seed_initial_data()
        self.db = SessionLocal()
        self._load_users()

    def _load_users(self):
        # Clean up any leftover test registration from previous runs
        from sqlalchemy import delete
        self.db.execute(delete(User).where(User.email == "john.reese@example.org"))
        self.db.commit()
        self.admin = self.db.execute(select(User).where(User.email == "marcus.vance@sentinelgrid.io")).scalar_one()
        self.civilian = self.db.execute(select(User).where(User.email == "sarah.connor@example.com")).scalar_one()

    def post(self, url: str, json: dict = None, files: dict = None, data: dict = None):
        parsed = urlparse(url)
        path = parsed.path
        
        # 1. Auth register
        if path == "/api/v1/auth/register":
            try:
                reg_data = CivilianRegister(**(json or {}))
                res = register(reg_data, self.db)
                return MockResponse(200, res.model_dump())
            except HTTPException as e:
                return MockResponse(e.status_code, {"detail": e.detail})

        # 2. Auth login
        if path == "/api/v1/auth/login":
            try:
                login_data = LoginRequest(**(json or {}))
                res = login(login_data, self.db)
                return MockResponse(200, res.model_dump())
            except HTTPException as e:
                return MockResponse(e.status_code, {"detail": e.detail})

        # 3. Create incident
        if path.rstrip("/") == "/api/v1/incidents":
            try:
                inc_data = IncidentCreate(**(json or {}))
                res = create_incident(inc_data, current_user=self.civilian, db=self.db)
                return MockResponse(200, IncidentOut.model_validate(res).model_dump(mode="json"))
            except HTTPException as e:
                return MockResponse(e.status_code, {"detail": e.detail})

        # 4. Upload evidence: /api/v1/evidence/{inc_id}/upload
        if "/evidence/" in path and path.endswith("/upload"):
            parts = path.strip("/").split("/")
            inc_id = parts[3]
            try:
                file_tuple = files.get("file") if files else None
                filename = file_tuple[0] if file_tuple else "evidence.bin"
                file_obj = file_tuple[1] if file_tuple else None
                contents = file_obj.read() if hasattr(file_obj, "read") else b""
                sha256 = hashlib.sha256(contents).hexdigest()
                desc = (data or {}).get("description", "Forensic evidence")
                
                ev = Evidence(
                    incident_id=inc_id,
                    file_name=filename,
                    file_size=len(contents),
                    file_type="message/rfc822",
                    storage_path="virtual_vault/" + filename,
                    sha256_hash=sha256,
                    uploaded_by_id=self.civilian.id,
                    uploaded_by_name=self.civilian.full_name,
                    description=desc,
                    is_verified=True
                )
                self.db.add(ev)
                self.db.commit()
                return MockResponse(200, {
                    "id": ev.id,
                    "file_name": ev.file_name,
                    "sha256_hash": ev.sha256_hash,
                    "description": ev.description
                })
            except Exception as e:
                return MockResponse(400, {"detail": str(e)})

        # 5. Civilian AI advice
        if path == "/api/v1/ai/civilian-advice":
            try:
                req = CivilianAdviceRequest(**(json or {}))
                res = get_civilian_advice(req)
                return MockResponse(200, res.model_dump())
            except HTTPException as e:
                return MockResponse(e.status_code, {"detail": e.detail})

        # 6. Investigator AI copilot
        if path == "/api/v1/ai/investigator-copilot":
            try:
                inc_id = (json or {}).get("incident_id")
                res = get_investigator_copilot(incident_id=inc_id, db=self.db)
                return MockResponse(200, res.model_dump())
            except HTTPException as e:
                return MockResponse(e.status_code, {"detail": e.detail})

        return MockResponse(404, {"detail": "Endpoint not found"})

    def get(self, url: str):
        parsed = urlparse(url)
        path = parsed.path
        qs = parse_qs(parsed.query)

        # Incidents list or detail
        if path.rstrip("/") == "/api/v1/incidents":
            incs = list_incidents(current_user=self.admin, db=self.db)
            return MockResponse(200, [IncidentOut.model_validate(i).model_dump(mode="json") for i in incs])

        if path.startswith("/api/v1/incidents/"):
            inc_id = path.replace("/api/v1/incidents/", "").strip("/")
            try:
                inc = get_incident(inc_id, current_user=self.admin, db=self.db)
                return MockResponse(200, IncidentOut.model_validate(inc).model_dump(mode="json"))
            except HTTPException as e:
                return MockResponse(e.status_code, {"detail": e.detail})

        # Threat intel lookup
        if path == "/api/v1/threat-intel/lookup":
            ind = qs.get("indicator", [""])[0]
            try:
                res = lookup_indicator(indicator=ind, db=self.db)
                return MockResponse(200, IndicatorOut.model_validate(res).model_dump(mode="json"))
            except HTTPException as e:
                return MockResponse(e.status_code, {"detail": e.detail})

        return MockResponse(404, {"detail": "Endpoint not found"})

    def patch(self, url: str, json: dict = None):
        parsed = urlparse(url)
        path = parsed.path

        if path.startswith("/api/v1/incidents/") and path.endswith("/status"):
            parts = path.strip("/").split("/")
            inc_id = parts[3]
            try:
                status_data = IncidentStatusUpdate(**(json or {}))
                res = update_status(inc_id, status_data, current_user=self.admin, db=self.db)
                return MockResponse(200, IncidentOut.model_validate(res).model_dump(mode="json"))
            except HTTPException as e:
                return MockResponse(e.status_code, {"detail": e.detail})

        return MockResponse(404, {"detail": "Endpoint not found"})

    def close(self):
        self.db.close()

@pytest.fixture(scope="session")
def client():
    c = DirectClient()
    yield c
    c.close()
