import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))

from app.core.database import SessionLocal
from sqlalchemy import text

def inspect_db():
    with SessionLocal() as db:
        tables = db.execute(text("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name;")).fetchall()
        print(f"=== Total PostgreSQL Tables: {len(tables)} ===")
        for t in tables:
            t_name = t[0]
            count = db.execute(text(f'SELECT count(*) FROM "{t_name}"')).scalar()
            print(f"  - {t_name:30} : {count} rows")

if __name__ == "__main__":
    inspect_db()
