# SentinelGrid Backend Launcher
# Bypasses Windows Application Control restrictions on .venv\Scripts\python.exe
$env:PYTHONPATH = (Resolve-Path ".\.venv\Lib\site-packages").Path
$pythonExe = "$env:APPDATA\uv\python\cpython-3.11-windows-x86_64-none\python.exe"

if (-not (Test-Path $pythonExe)) {
    Write-Host "Python executable not found at $pythonExe" -ForegroundColor Red
    exit 1
}

Write-Host "Starting SentinelGrid Backend on http://127.0.0.1:8000 ..." -ForegroundColor Cyan
& $pythonExe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --app-dir backend --reload
