@echo off
set PYTHONPATH=%~dp0.venv\Lib\site-packages
set PYTHON_EXE=%APPDATA%\uv\python\cpython-3.11-windows-x86_64-none\python.exe

if not exist "%PYTHON_EXE%" (
    echo Python executable not found at %PYTHON_EXE%
    exit /b 1
)

echo Starting SentinelGrid Backend with PostgreSQL on http://127.0.0.1:8000 ...
"%PYTHON_EXE%" -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --app-dir backend --reload
