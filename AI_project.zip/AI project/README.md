# SENTINEL GRID
### *Report. Investigate. Protect.*

```bash
# 1. Start Backend (PostgreSQL + FastAPI on http://127.0.0.1:8000)
.\run_backend.bat
# or in PowerShell:
.\run_backend.ps1

# 2. Start Frontend (React + Vite on http://localhost:5173)
cd frontend
npm run dev
```


**Sentinel Grid** is an enterprise-grade, AI-assisted cybersecurity incident response, reporting, and threat intelligence platform. Built from the ground up to connect civilians reporting cybercrime with authorized digital forensics investigators and SOC teams who analyze evidence, investigate incidents, and coordinate mitigation workflows.

---

## 🌟 Key Highlights & Design System

- **Dual-Portal Architecture**: Dedicated interfaces tailored specifically for **Civilians** (complainants) and **Investigators** (SOC analysts & digital forensics specialists).
- **Strict Light-Theme Visual Direction**:
  - Primary Blue: `#2563EB` | Secondary Teal: `#0D9488`
  - Background: `#F7FAFC` | Surface: `#FFFFFF`
  - Deep Navy Headings: `#172554` | Body Slate: `#475569`
  - Human-designed, clean, spacious layouts with high-contrast typography, clear hierarchy, and no dark-mode cliches.
- **26+ Normalized Schema Entities**: Full enterprise data modeling covering users, roles, permissions, incidents, assignments, evidence artifacts, threat indicators, security alerts, MITRE ATT&CK techniques, audit trails, and real-time messaging.
- **Evidence Vault with SHA-256 Verification**: Tamper-evident evidence collection with client-side & server-side cryptographic hashing.
- **Grounded AI Intelligence**:
  - **Civilian AI Security Assistant**: Guides victims through scam identification, digital evidence preservation, and safe reporting without legal or law enforcement overreach.
  - **Investigator AI Copilot**: Performs automated MITRE ATT&CK tactic/technique mapping (e.g., T1566.002 Spearphishing Link, T1539 Cookie Theft), key findings extraction, investigative queries, and containment recommendations.

---

## 🏛️ Dual Portal Breakdown

### 1. Civilian Portal
- **Dashboard**: Incident metrics, active cases, recent activity, and safety recommendations.
- **Report Incident (5-Step Intake Wizard)**:
  - Step 1: Category Selection (Phishing, Online Financial Fraud, Identity Theft, Account Hacking, Ransomware, etc.)
  - Step 2: Incident Details (Title, Narrative, Date/Time, Platform, Suspect info, Financial Loss)
  - Step 3: Digital Evidence Upload with automatic SHA-256 hash calculation and validation
  - Step 4: Complainant Contact & Notification Preferences
  - Step 5: Review & Submission (generates unique `SG-YYYY-XXXX` case identifier)
- **My Complaints**: Live tracking across standard statuses (`Submitted`, `Under Review`, `Assigned`, `Investigation in Progress`, `Additional Info Required`, `Resolved`, `Closed`).
- **Interactive Timeline**: Detailed case chronology showing investigator updates, status changes, and evidence milestones.
- **Civilian-Investigator Messaging**: Complaint-scoped secure messaging with attachment support.
- **AI Security Assistant**: Conversational cybersecurity advisor for threat identification and evidence preservation.
- **Cyber Safety Center**: Comprehensive education modules covering UPI fraud prevention, spearphishing detection, password hygiene, and credential protection.
- **Profile & Settings**: Contact preferences, 2FA settings, and notification channels.

### 2. Investigator Portal
- **SOC Command Center Overview**: Incident severity donut chart, weekly incident cadence, priority triage queue, threat feed counters, and system health status.
- **Incident Queue (Triage)**: Searchable, filterable queue with bulk status actions, severity tags, and instant assignment controls.
- **Active Investigations**: Dedicated caseload tracking assigned directly to the authenticated investigator.
- **Investigation Workspace**:
  - Full complaint metadata & complainant details (governed by RBAC)
  - Evidence Gallery with SHA-256 hash inspection and integrity verification
  - Forensic Timeline with interactive event logging
  - Threaded Investigator Notes & Case Activity
  - Integrated AI Investigation Copilot with MITRE ATT&CK mapping
  - Resolution notes and status lifecycle management
- **Threat Intelligence Hub**: Real-time IP, domain, and file hash reputation lookup engine with risk scoring and threat attribution.
- **AI Forensic Copilot**: Deep automated incident analysis, IOC correlation, confidence scoring, and suggested response actions.
- **Evidence Management**: Central vault of all uploaded artifacts, MIME types, file sizes, and cryptographic signatures.
- **Security Alerts**: Real-time detection rule alerts (e.g., SSH brute force, Tor exit node access) correlated with active incidents.
- **Analytics & Incident Trends**: Historical reporting across crime categories, financial loss metrics, and resolution turnaround times.
- **Team Management & Audit Logs**: Investigator roster, clearance levels, and tamper-proof immutable audit logs recording every action.

---

## 🔐 Pre-Configured Demo Credentials

The platform database comes pre-seeded with sample accounts and cases:

| Role | Name | Email | Password |
| :--- | :--- | :--- | :--- |
| **Civilian** | Sarah Connor | `sarah.connor@example.com` | `CyberSafe@2026` |
| **Lead Investigator** | Special Agent Marcus Vance | `marcus.vance@sentinelgrid.io` | `SpecialAgent#9042` |
| **Senior Detective** | Lead Detective Elena Rostova | `elena.rostova@sentinelgrid.io` | `LeadDetective#1049` |

> *Quick Switcher*: The application navigation bar includes an instant role toggle allowing you to switch between Civilian and Investigator portals in one click.

---

## 🚀 Quickstart Guide

### Prerequisites
- **Node.js**: v18+ or v20+
- **Python**: 3.10+ or 3.11+
- **npm** or **pnpm**

---

### Step 1: Start the Backend API (FastAPI)

```bash
cd backend

# Create and activate virtual environment (if not already active)
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run database setup & initial seed
python -c "from app.core.database import Base, engine; from app.seed_data import seed_initial_data; Base.metadata.create_all(bind=engine); seed_initial_data(); print('Database ready!')"

# Start the development server
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

- **Interactive API Documentation (Swagger)**: `http://127.0.0.1:8000/docs`
- **Alternative Documentation (ReDoc)**: `http://127.0.0.1:8000/redoc`

---

### Step 2: Start the Frontend Application (Vite + React)

```bash
cd frontend

# Install dependencies
npm install

# Start Vite development server
npm run dev
```

- **Civilian & Investigator Web App**: `http://127.0.0.1:5173`

---

### Step 3: Run the Automated Test Suite

The platform includes a test suite covering authentication, duplicate detection, role permissions, incident creation, status lifecycle transitions, cryptographic SHA-256 evidence verification, threat intelligence lookups, and AI copilot response schemas.

```bash
cd backend
pytest tests/ -v
```

Expected output:
```text
backend/tests/test_auth.py::test_civilian_registration PASSED            [  9%]
backend/tests/test_auth.py::test_duplicate_registration_rejected PASSED  [ 18%]
backend/tests/test_auth.py::test_civilian_login_success PASSED           [ 27%]
backend/tests/test_auth.py::test_investigator_login_success PASSED       [ 36%]
backend/tests/test_auth.py::test_invalid_login_rejected PASSED           [ 45%]
backend/tests/test_evidence_and_ai.py::test_evidence_upload_sha256 PASSED [ 54%]
backend/tests/test_evidence_and_ai.py::test_threat_intelligence_lookup PASSED [ 63%]
backend/tests/test_evidence_and_ai.py::test_civilian_ai_security_advisor PASSED [ 72%]
backend/tests/test_evidence_and_ai.py::test_investigator_ai_copilot PASSED [ 81%]
backend/tests/test_incidents.py::test_create_and_fetch_incident PASSED   [ 90%]
backend/tests/test_incidents.py::test_update_incident_status PASSED      [100%]

============================= 11 passed in 0.27s ==============================
```

---

## 📂 Project Structure

```text
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── deps.py              # JWT authentication & RBAC dependencies
│   │   │   └── v1/
│   │   │       ├── ai.py            # AI Security Assistant & Forensic Copilot
│   │   │       ├── alerts.py        # Real-time SOC detection alerts
│   │   │       ├── audit.py         # Immutable audit logging endpoint
│   │   │       ├── auth.py          # Registration, Login & Argon2 hashing
│   │   │       ├── evidence.py      # SHA-256 hashing & vault storage
│   │   │       ├── incidents.py     # Incident lifecycle CRUD & assignments
│   │   │       ├── messages.py      # Case-scoped civilian-investigator chat
│   │   │       ├── router.py        # Central API v1 router
│   │   │       └── threat_intel.py  # Threat indicator reputation lookup
│   │   ├── core/
│   │   │   ├── config.py            # Pydantic v2 application settings
│   │   │   ├── database.py          # SQLAlchemy 2.0 session factory
│   │   │   └── security.py          # Argon2 password hashing & JWT handling
│   │   ├── models/
│   │   │   └── entities.py          # 26+ normalized SQLAlchemy tables
│   │   ├── schemas/                 # Pydantic validation schemas
│   │   ├── main.py                  # FastAPI app & WebSocket event hub
│   │   └── seed_data.py             # Pre-seeded users, cases & alerts
│   ├── tests/                       # 11 integration & unit tests
│   └── requirements.txt
│
├── frontend/
│   ├── src/
│   │   ├── components/              # Badges, Buttons, Cards, Modals, Navbar, Sidebar
│   │   ├── context/
│   │   │   ├── AuthContext.tsx      # Dual-role authentication state
│   │   │   └── IncidentContext.tsx  # Global incident state & filter provider
│   │   ├── layouts/
│   │   │   ├── CivilianLayout.tsx   # Civilian navigation & header
│   │   │   └── InvestigatorLayout.tsx # SOC dark-accented light layout
│   │   ├── pages/
│   │   │   ├── auth/                # Login, Register, Forgot Password
│   │   │   ├── civilian/            # Dashboard, Wizard, Tracking, Chat, AI
│   │   │   ├── investigator/        # SOC Overview, Queue, Intel, Copilot, Audit
│   │   │   └── landing/             # Public landing page with hero & safety guide
│   │   ├── types/                   # TypeScript interfaces
│   │   ├── App.tsx                  # Client-side router & role guards
│   │   └── index.css                # Custom light-theme CSS tokens
│   ├── tailwind.config.js
│   ├── tsconfig.json
│   └── vite.config.ts
│
├── sentinel_grid.db                 # Seeded SQLite database
└── README.md
```

---

## 🔒 Security & AI Safety Guarantees

1. **Role-Based Access Control**:
   - Civilians are strictly restricted to accessing their own reported incidents and conversations.
   - Investigators possess read/write access to assigned incidents and team triage queues.
   - Permissions are enforced on the backend via cryptographic JWT claims and database queries.
2. **Evidence Integrity**:
   - SHA-256 hashes are calculated upon upload and compared against stored signatures to detect any post-incident tampering.
3. **Responsible AI Standards**:
   - The AI Copilot uses strictly authorized case evidence and observed telemetry.
   - It distinguishes confirmed evidence from hypotheses.
   - Never fabricates evidence, declares suspects guilty, or claims official law enforcement dispatch.

---

## 📄 License
This project is licensed under the MIT License. Developed for enterprise cybersecurity incident reporting, investigation, and intelligence operations.
