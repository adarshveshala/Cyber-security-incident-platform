import sys
import os
import sqlite3

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend', 'tests')))

from conftest import DirectClient

def test_isolation():
    client = DirectClient()

    new_email = f"new.citizen.{os.urandom(3).hex()}@sentinelgrid.test"
    print(f"1. Registering new citizen: {new_email}")
    reg_res = client.post(
        "/api/v1/auth/register",
        json={
            "full_name": "Test Citizen Jane",
            "email": new_email,
            "phone": "+1 (555) 019-9944",
            "password": "SecurePassword#2026"
        }
    )
    assert reg_res.status_code == 200, f"Registration failed: {reg_res.text}"
    token_data = reg_res.json()
    new_token = token_data["access_token"]
    new_user_id = token_data["user_id"]
    print(f"  User registered successfully! ID: {new_user_id}")

    print("\n2. Fetching incidents for newly registered citizen:")
    # Using new user's token directly
    from app.core.database import SessionLocal
    from app.models.entities import User
    from app.api.v1.incidents import list_incidents
    from sqlalchemy import select

    with SessionLocal() as db:
        new_user = db.execute(select(User).where(User.id == new_user_id)).scalar_one()
        incidents = list_incidents(current_user=new_user, db=db)
        print(f"  Incident count for brand new citizen: {len(incidents)}")
        assert len(incidents) == 0, f"Expected 0 incidents for brand new citizen, found {len(incidents)}!"
        print("  VERIFIED: Brand new citizen account has exactly 0 incidents!")

    print("\n3. Submitting 1 incident as new citizen:")
    create_res = client.post(
        "/api/v1/incidents/",
        json={
            "title": "Jane's First Phishing Report",
            "category": "phishing",
            "severity": "medium",
            "description": "Received suspicious SMS with bit.ly shortlink claiming bank KYC update.",
            "incident_date": "2026-11-21",
            "incident_time": "19:40",
            "financial_loss": 0,
            "contact_email": new_email,
        }
    )
    # create_incident in conftest used client.civilian (Sarah) if called via mock client, so let's call with new_user directly:
    with SessionLocal() as db:
        from app.schemas.incident import IncidentCreate
        from app.api.v1.incidents import create_incident
        new_inc = create_incident(
            data=IncidentCreate(
                title="Jane's First Phishing Report",
                category="phishing",
                severity="medium",
                description="Received suspicious SMS with bit.ly shortlink claiming bank KYC update.",
                incident_date="2026-11-21",
                contact_email=new_email,
            ),
            current_user=new_user,
            db=db
        )
        print(f"  Created new incident: {new_inc.complaint_id} for user {new_inc.civilian_name}")
        
        # Now re-check Jane's incidents
        jane_incidents = list_incidents(current_user=new_user, db=db)
        print(f"  Incident count for Jane now: {len(jane_incidents)}")
        assert len(jane_incidents) == 1, f"Expected 1 incident, found {len(jane_incidents)}"
        assert jane_incidents[0].complaint_id == new_inc.complaint_id

    print("\n=======================================================")
    print("SUCCESS: NEW ACCOUNT IS ISOLATED AND STARTS AT 0 INCIDENTS!")
    print("=======================================================")

if __name__ == '__main__':
    test_isolation()
