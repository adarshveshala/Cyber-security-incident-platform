import sys
import os
import sqlite3
import json

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))

from fastapi.testclient import TestClient
from app.main import app

def main():
    client = TestClient(app)
    
    print("--- 1. Testing Backend Root Health ---")
    res = client.get("/")
    assert res.status_code == 200, f"Expected 200, got {res.status_code}"
    print("Root health response:", res.json())

    print("\n--- 2. Fetching Real Incidents from SQLite ---")
    res = client.get("/api/v1/incidents/", headers={"Authorization": "Bearer demo-inv"})
    assert res.status_code == 200, f"Failed to list incidents: {res.text}"
    incidents = res.json()
    print(f"Total incidents currently in SQLite: {len(incidents)}")
    for inc in incidents[:3]:
        print(f"  • [{inc['complaint_id']}] {inc['title']} ({inc['severity'].upper()}) - {inc.get('location_name')} - IP: {inc.get('reporter_ip')}")

    print("\n--- 3. Submitting New Incident from Civilian (Sarah Connor) ---")
    payload = {
        "title": "Rogue NetBanking Phishing Portal (Live DB Verification)",
        "category": "financial_fraud",
        "severity": "critical",
        "description": "Victim received rogue SMS spoofing HDFC NetBanking login. Diverted 85,000 INR through mule account.",
        "incident_date": "2026-11-21",
        "incident_time": "19:25",
        "platform_involved": "HDFC Mobile NetBanking / WhatsApp SMS",
        "suspect_info": "Mule VPA: cyber-drain@icici-mule.vpa",
        "financial_loss": 85000.0,
        "currency": "INR",
        "latitude": 17.3850,
        "longitude": 78.4867,
        "location_name": "Hyderabad, Telangana, India",
        "reporter_ip": "157.50.140.6",
        "contact_email": "sarah.connor@example.com",
        "contact_phone": "+91 98480 12345"
    }
    create_res = client.post("/api/v1/incidents/", json=payload, headers={"Authorization": "Bearer demo-civ"})
    assert create_res.status_code == 200, f"Failed to create incident: {create_res.text}"
    created_incident = create_res.json()
    comp_id = created_incident["complaint_id"]
    print(f"Successfully created incident! Assigned Reference ID: {comp_id}")
    print(f"  Status: {created_incident['status']}")
    print(f"  Location: {created_incident['location_name']} [{created_incident['latitude']}, {created_incident['longitude']}]")
    print(f"  Reporter IP: {created_incident['reporter_ip']}")

    print("\n--- 4. Direct SQLite Verification in 'sentinel_grid.db' ---")
    db_path = os.path.join(os.path.dirname(__file__), '..', 'sentinel_grid.db')
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    row = cur.execute(
        "SELECT complaint_id, title, category, severity, status, location_name, reporter_ip, latitude, longitude, created_at FROM incidents WHERE complaint_id = ?",
        (comp_id,)
    ).fetchone()
    conn.close()
    
    assert row is not None, f"Incident {comp_id} NOT found in SQLite file!"
    print(f"Confirmed in SQLite database file '{db_path}':")
    print(f"  ID: {row[0]}")
    print(f"  Title: {row[1]}")
    print(f"  Category: {row[2]}")
    print(f"  Severity: {row[3]}")
    print(f"  Status: {row[4]}")
    print(f"  Location Name: {row[5]}")
    print(f"  Reporter IP: {row[6]}")
    print(f"  Coordinates: [{row[7]}, {row[8]}]")
    print(f"  Created At: {row[9]}")

    print("\n--- 5. Investigator Status Transition in SQLite ---")
    patch_res = client.patch(
        f"/api/v1/incidents/{comp_id}/status",
        json={"status": "investigation_in_progress", "notes": "Special Agent Marcus Vance initiating immediate VPA trace."},
        headers={"Authorization": "Bearer demo-inv"}
    )
    assert patch_res.status_code == 200, f"Failed status patch: {patch_res.text}"
    updated = patch_res.json()
    print(f"Updated status: {updated['status']}")
    print(f"Timeline events count: {len(updated['timeline_events'])}")

    print("\n=== LIVE DATABASE CONNECTION VERIFIED 100% OPERATIONAL ===")

if __name__ == '__main__':
    main()
