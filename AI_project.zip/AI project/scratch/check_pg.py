import asyncio
import asyncpg

async def check():
    passwords = ['postgres', 'admin', 'root', 'password', '123456', '', 'sentinel', 'sentinelgrid', '1234', 'qwerty', 'admin123', 'postgrespw']
    users = ['postgres', 'adarsh']
    for u in users:
        for p in passwords:
            try:
                conn = await asyncpg.connect(host='127.0.0.1', port=5432, user=u, password=p, database='postgres', timeout=2)
                print(f'SUCCESS! User: {u}, Password: {p}')
                rows = await conn.fetch('SELECT datname FROM pg_database')
                print('Databases:', [r['datname'] for r in rows])
                await conn.close()
                return (u, p)
            except Exception as e:
                err_msg = str(e)
                if 'password authentication failed' not in err_msg:
                    print(f'Trying {u}:{p} -> {err_msg}')
    print('No standard password matched.')
    return None

if __name__ == '__main__':
    asyncio.run(check())
