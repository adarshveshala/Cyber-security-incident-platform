import sys
import os
import sqlite3

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend', 'tests')))

from conftest import DirectClient

def verify():
    client = DirectClient()

    print("=== 1. Querying Real Incidents from SQLite database ===")
    list_res = client.get("/api/v1/incidents/")
    assert list_res.status_code == 200
    incidents = list_res.json()
    print(f"Total incidents currently stored in SQLite: {len(incidents)}")
    for inc in incidents[:5]:
        print(f"  • Ref: {inc['complaint_id']} | Title: {inc['title'][:45]}... | Severity: {inc['severity'].upper()} | Status: {inc['status']} | Loc: {inc.get('location_name')} | IP: {inc.get('reporter_ip')}")

    print("\n=== 2. Creating New Incident in SQLite from Civilian Intake ===")
    create_res = client.post(
        "/api/v1/incidents/",
        json={
            "title": "Rogue NetBanking Phishing Portal (Live DB Verification)",
            "category": "financial_fraud",
            "severity": "critical",
            "description": "Victim received rogue SMS spoofing HDFC NetBanking login. Diverted 85,000 INR through mule account.",
            "incident_date": "2026-11-21",
            "incident_time": "19:25",
            "platform_involved": "HDFC Mobile NetBanking / WhatsApp SMS",
            "suspect_info": "Mule VPA: cyber-drain@icici-mule.vpa",
            "financial_loss": 85000.0,
            "currency": "INR",
            "latitude": 17.3850,
            "longitude": 78.4867,
            "location_name": "Hyderabad, Telangana, India",
            "reporter_ip": "157.50.140.6",
            "contact_email": "sarah.connor@example.com",
            "contact_phone": "+91 98480 12345"
        }
    )
    assert create_res.status_code == 200
    created = create_res.json()
    comp_id = created["complaint_id"]
    print(f"Successfully created incident in database!")
    print(f"  Assigned Complaint Reference: {comp_id}")
    print(f"  Database ID: {created['id']}")
    print(f"  Status: {created['status']}")
    print(f"  Severity: {created['severity']}")
    print(f"  Location Name: {created['location_name']}")
    print(f"  Coordinates: [{created['latitude']}, {created['longitude']}]")
    print(f"  Device IP: {created['reporter_ip']}")

    print("\n=== 3. Directly Verifying Raw Disk SQLite File 'sentinel_grid.db' ===")
    db_file = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'sentinel_grid.db'))
    conn = sqlite3.connect(db_file)
    c = conn.cursor()
    row = c.execute(
        "SELECT complaint_id, title, category, severity, status, location_name, reporter_ip, latitude, longitude, created_at FROM incidents WHERE complaint_id = ?",
        (comp_id,)
    ).fetchone()
    conn.close()

    assert row is not None, f"Complaint {comp_id} was not found on disk!"
    print(f"Raw SQLite Row on disk confirmed:")
    print(f"  • Complaint ID: {row[0]}")
    print(f"  • Title: {row[1]}")
    print(f"  • Category: {row[2]}")
    print(f"  • Severity: {row[3]}")
    print(f"  • Status: {row[4]}")
    print(f"  • Location: {row[5]}")
    print(f"  • Reporter IP: {row[6]}")
    print(f"  • Lat/Lng: ({row[7]}, {row[8]})")
    print(f"  • Created At: {row[9]}")

    print("\n=== 4. Updating Incident Status in SQLite ===")
    patch_res = client.patch(
        f"/api/v1/incidents/{comp_id}/status",
        json={"status": "investigation_in_progress", "notes": "Special Agent Marcus Vance initiating immediate VPA freezing order with bank node."}
    )
    assert patch_res.status_code == 200
    updated = patch_res.json()
    print(f"Updated status in SQLite: {updated['status']}")

    conn2 = sqlite3.connect(db_file)
    c2 = conn2.cursor()
    updated_row = c2.execute("SELECT status FROM incidents WHERE complaint_id = ?", (comp_id,)).fetchone()
    audit_count = c2.execute("SELECT COUNT(*) FROM audit_logs WHERE target_id = ?", (comp_id,)).fetchone()[0]
    conn2.close()

    print(f"Direct disk query confirmed updated status: {updated_row[0]}")
    print(f"Audit log trail entries created in database: {audit_count}")
    print("\n=======================================================")
    print("SUCCESS: REAL DATABASE CONNECTED AND UPDATING IN REAL TIME!")
    print("=======================================================")

if __name__ == '__main__':
    verify()
